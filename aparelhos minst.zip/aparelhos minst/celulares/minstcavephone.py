# -*- coding: utf-8 -*-
# minstcaveOS v6.0 - Foco
import sys, io
try:
    if sys.stdout and hasattr(sys.stdout,'buffer'):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
    if sys.stderr and hasattr(sys.stderr,'buffer'):
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace', line_buffering=True)
except: pass

import os, json, math, socket, platform, subprocess, datetime, random, time, traceback
import tkinter as tk
from tkinter import messagebox, simpledialog
try:
    import winsound; HAS_SOUND=True
except: HAS_SOUND=False

V = "6.0"; ADMIN_CODE = "minst2024"
PW, PH, BW, NH = 400, 820, 12, 24
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "mobile_data")
CFG_F = os.path.join(DATA, "config.json")
INST_F = os.path.join(DATA, "installed.json")
CUS_F = os.path.join(DATA, "custom.json")
NOT_F = os.path.join(DATA, "notif.json")

BG = "#0f1419"; DARK = "#080d12"; CARD = "#1a2332"
PRI = "#00d4ff"; OK = "#4caf50"; WARN = "#ff9800"; ERR = "#f44336"
PINK = "#e91e63"; PURP = "#9c27b0"; BLUE = "#2196f3"; TEAL = "#009688"
ORANGE = "#ff6f00"; CYAN = "#00bcd4"
TXT = "#ffffff"; DIM = "#8892b0"

WALLS = [("Oceano","#0d1b2a","#1b263b"),("Floresta","#0d2a1a","#1b3b2a"),
         ("Aurora","#1a0d2a","#2a1b3b"),("Deserto","#2a1a0d","#3b2a1b"),
         ("Vulcao","#2a0d0d","#3b1b1b"),("Meia-noite","#000000","#0d1b2a")]

APPS=[]; ADMIN=[False]

STORE = [("Minecraft","Jogos","MC","#62b47a"),("Among Us","Jogos","AU","#c51111"),
         ("Spotify","Media","SP","#1db954"),("Netflix","Media","NF","#e50914"),
         ("Instagram","Social","IG","#e91e63"),("TikTok","Social","TT","#000000"),
         ("Maps","Ferramentas","GM","#34a853"),("Duolingo","Ferramentas","DU","#58cc02"),
         ("Uber","Ferramentas","UB","#000000"),("Discord","Social","DC","#5865f2")]

def ensure():
    if not os.path.exists(DATA):
        try: os.makedirs(DATA)
        except: pass

def lj(p, d):
    try:
        if os.path.exists(p):
            f=open(p); r=json.load(f); f.close(); return r
    except: pass
    return d

def sj(p, d):
    try:
        f=open(p,"w"); json.dump(d,f); f.close()
    except: pass

def cfg():
    return lj(CFG_F, {"wifi":True,"bt":False,"som":True,"pin":False,"passwd":"1234",
                      "admin":False,"wall":0,"bat":100})

def scfg(c): sj(CFG_F, c)

def wp():
    i = cfg().get("wall",0)
    return WALLS[i] if 0<=i<len(WALLS) else WALLS[0]

def inst():
    s = lj(INST_F, None)
    if s is None:
        s = [a[0] for a in APPS if a[4]]; sj(INST_F, s)
    return s

def is_inst(k): return k in inst()
def install(k):
    l = inst()
    if k not in l: l.append(k); sj(INST_F, l)
def uninstall(k):
    l = inst()
    if k in l: l.remove(k); sj(INST_F, l)

def find(k):
    for a in APPS:
        if a[0]==k: return a
    return None

def store_find(k):
    for s in STORE:
        if s[0]==k: return s
    return None

def customs(): return lj(CUS_F, [])

def notify(title, body):
    l = lj(NOT_F, [])
    l.append({"t":title,"b":body,"time":datetime.datetime.now().strftime("%H:%M")})
    sj(NOT_F, l[-20:])
    snd("notif")

def notifs(): return lj(NOT_F, [])
def clear_notifs(): sj(NOT_F, [])

def snd(k="click"):
    if not HAS_SOUND or not cfg().get("som",True): return
    try:
        freqs = {"click":[(1400,15)],"notif":[(880,60),(1320,100)],
                 "error":[(600,80),(400,120)],"ok":[(880,80),(1174,80),(1568,150)],
                 "boot":[(523,100),(659,100),(784,150),(1047,200)]}
        winsound.Beep(freqs.get(k,[(1000,50)])[0][0], freqs.get(k,[(1000,50)])[0][1])
    except: pass

def net():
    info={"on":False,"ssid":"","ip":""}
    try:
        s=socket.create_connection(("8.8.8.8",53),timeout=2); s.close(); info["on"]=True
    except: pass
    try: info["ip"]=socket.gethostbyname(socket.gethostname())
    except: pass
    try:
        if platform.system()=="Windows":
            o=subprocess.check_output(["netsh","wlan","show","interfaces"],
                                       stderr=subprocess.STDOUT).decode("latin-1","replace")
            for line in o.split("\n"):
                ll=line.strip().lower()
                if ll.startswith("ssid") and "bssid" not in ll and ":" in line:
                    ss=line.split(":",1)[1].strip()
                    if ss and not info["ssid"]: info["ssid"]=ss
    except: pass
    return info

def icon(parent, color, letter, size=72, bg=BG):
    c = tk.Canvas(parent, width=size+6, height=size+6, bg=bg,
                  highlightthickness=0, cursor="hand2")
    c.create_oval(4,4,size+4,size+4, fill="#000")
    c.create_oval(0,0,size,size, fill=color, outline="")
    c.create_text(size//2+2, size//2+2, text=letter, fill="white",
                  font=("Segoe UI", int(size*0.38), "bold"))
    return c

# ============================================================
class OS:
    def __init__(self):
        ensure()
        c = cfg()
        if c.get("admin"): ADMIN[0] = True
        self.r = tk.Tk(); self.r.title("minstcaveOS v"+V)
        self.r.configure(bg="#0a0a0a")
        self.r.geometry("%dx%d" % (PW+BW*2, PH+BW*2))
        self.r.bind("<F11>", lambda e: self.r.attributes("-fullscreen",
            not self.r.attributes("-fullscreen")))
        bz = tk.Frame(self.r, bg="#0a0a0a")
        bz.pack(fill="both", expand=True, padx=2, pady=2)
        self.s = tk.Frame(bz, bg=BG)
        self.s.pack(fill="both", expand=True, padx=BW-2, pady=BW-2)
        self.lock()

    def clear(self):
        for w in self.s.winfo_children():
            try: w.destroy()
            except: pass

    def bar(self, p):
        b = tk.Frame(p, bg="#000", height=30); b.pack(fill="x")
        b.pack_propagate(False)
        t = tk.Label(b, text="", bg="#000", fg=TXT, font=("Segoe UI",9,"bold"))
        t.pack(side="left", padx=12)
        def tk_():
            try:
                if not t.winfo_exists(): return
                t.config(text=datetime.datetime.now().strftime("%H:%M"))
                t.after(15000, tk_)
            except: pass
        tk_()
        n = len(notifs())
        tk.Button(b, text=("%d N"%n) if n>0 else "N", bg="#000",
                  fg=(WARN if n>0 else TXT), font=("Segoe UI",8,"bold"),
                  relief="flat", command=self.notif_panel).pack(side="right", padx=4)
        cf = cfg()
        bat = tk.Canvas(b, width=24, height=11, bg="#000", highlightthickness=0)
        bat.pack(side="right", padx=4)
        pct = cf.get("bat",100); col = OK if pct>30 else ERR
        bat.create_rectangle(0,0,20,11, outline=TXT, fill="")
        bat.create_rectangle(1,1,1+max(1,int(18*pct/100)),10, fill=col, outline="")
        bat.create_rectangle(21,3,23,8, fill=TXT, outline="")
        ni = net()
        tk.Label(b, text="Wi", bg="#000",
                 fg=(OK if ni["on"] else ERR), font=("Segoe UI",7,"bold")).pack(side="right", padx=3)
        if ADMIN[0]:
            tk.Label(b, text="ADM", bg=ERR, fg="white",
                     font=("Segoe UI",6,"bold"), padx=3).pack(side="right", padx=2)
        return b

    def notif_panel(self):
        snd("click")
        p = tk.Frame(self.s, bg=CARD); p.place(x=0, y=30, relwidth=1, height=500)
        h = tk.Frame(p, bg=DARK, height=44); h.pack(fill="x"); h.pack_propagate(False)
        tk.Label(h, text="Notificacoes", bg=DARK, fg=TXT,
                 font=("Segoe UI",12,"bold")).pack(side="left", padx=15, pady=10)
        tk.Button(h, text="X", bg=DARK, fg=ERR, font=("Segoe UI",11,"bold"),
                  relief="flat", command=p.destroy).pack(side="right", padx=10)
        tk.Button(h, text="Limpar", bg=DARK, fg=DIM, font=("Segoe UI",9),
                  relief="flat", command=lambda:(clear_notifs(),p.destroy())).pack(side="right", padx=5)
        cv = tk.Canvas(p, bg=CARD, highlightthickness=0); cv.pack(fill="both", expand=True)
        inn = tk.Frame(cv, bg=CARD)
        cv.create_window((0,0), window=inn, anchor="nw", tags="i")
        cv.bind("<Configure>", lambda e: cv.itemconfig("i", width=e.width))
        ns = notifs()
        if not ns:
            tk.Label(inn, text="Sem notificacoes", bg=CARD, fg=DIM,
                     font=("Segoe UI",11)).pack(pady=40)
        else:
            for n in reversed(ns):
                c = tk.Frame(inn, bg="#233045", pady=8, padx=12)
                c.pack(fill="x", padx=10, pady=4)
                top = tk.Frame(c, bg="#233045"); top.pack(fill="x")
                tk.Label(top, text=n.get("t",""), bg="#233045", fg=TXT,
                         font=("Segoe UI",10,"bold"), anchor="w").pack(side="left")
                tk.Label(top, text=n.get("time",""), bg="#233045", fg=DIM,
                         font=("Segoe UI",8)).pack(side="right")
                tk.Label(c, text=n.get("b",""), bg="#233045", fg=DIM,
                         font=("Segoe UI",9), anchor="w", wraplength=340,
                         justify="left").pack(fill="x", pady=(3,0))
        inn.update_idletasks()
        cv.config(scrollregion=cv.bbox("all"))

    def lock(self):
        self.clear()
        c = cfg(); w = wp()
        bg = tk.Frame(self.s, bg=w[1]); bg.pack(fill="both", expand=True)
        self.bar(bg)
        tk.Frame(bg, bg="#000", height=NH).pack(fill="x")
        ct = tk.Frame(bg, bg=w[1]); ct.pack(fill="both", expand=True)
        clk = tk.Frame(ct, bg=w[1]); clk.pack(pady=(60,0))
        tl = tk.Label(clk, text="", bg=w[1], fg=TXT, font=("Segoe UI",54,"bold"))
        tl.pack()
        dl = tk.Label(clk, text="", bg=w[1], fg=DIM, font=("Segoe UI",11))
        dl.pack(pady=(2,0))
        def tk_():
            try:
                if not tl.winfo_exists(): return
                n=datetime.datetime.now()
                tl.config(text=n.strftime("%H:%M"))
                dl.config(text=n.strftime("%A, %d de %B"))
                tl.after(1000, tk_)
            except: pass
        tk_()
        ns = notifs()
        if ns:
            nf = tk.Frame(ct, bg=CARD, pady=10, padx=15)
            nf.pack(fill="x", padx=30, pady=25)
            last = ns[-1]
            tk.Label(nf, text=last.get("t",""), bg=CARD, fg=TXT,
                     font=("Segoe UI",10,"bold"), anchor="w").pack(fill="x")
            tk.Label(nf, text=last.get("b",""), bg=CARD, fg=DIM,
                     font=("Segoe UI",8), anchor="w").pack(fill="x")
        if c.get("pin"):
            pin=[""]
            dots = tk.Label(ct, text="", bg=w[1], fg=PRI, font=("Segoe UI",24,"bold"))
            dots.pack(pady=(20,10))
            er = tk.Label(ct, text="", bg=w[1], fg=ERR, font=("Segoe UI",9))
            er.pack()
            def rsh(): dots.config(text="* "*len(pin[0]))
            def press(d):
                snd("click"); pin[0]+=d; rsh()
                if len(pin[0])>=len(c.get("passwd","1234")):
                    if pin[0]==c.get("passwd","1234"):
                        snd("ok"); self.home()
                    else:
                        er.config(text="Senha incorreta")
                        pin[0]=""; rsh(); snd("error")
            def bk(): pin[0]=pin[0][:-1]; rsh()
            kp = tk.Frame(ct, bg=w[1]); kp.pack(pady=10)
            for i, k in enumerate(["1","2","3","4","5","6","7","8","9","","0","<"]):
                if not k: continue
                cmd = bk if k=="<" else (lambda x=k: press(x))
                tk.Button(kp, text=k, bg=CARD, fg=TXT, font=("Segoe UI",16,"bold"),
                          width=4, height=2, relief="flat",
                          command=cmd).grid(row=i//3, column=i%3, padx=5, pady=3)
        else:
            b = tk.Frame(bg, bg=w[1]); b.pack(fill="x", pady=30)
            tk.Button(b, text="Deslize para desbloquear >>", bg=CARD, fg=TXT,
                      relief="flat", font=("Segoe UI",12,"bold"),
                      command=lambda:(snd("ok"),self.home()),
                      padx=20, pady=12).pack()

    def home(self):
        self.clear()
        w = wp()
        bg = tk.Frame(self.s, bg=w[1]); bg.pack(fill="both", expand=True)
        self.bar(bg)
        tk.Frame(bg, bg="#000", height=NH).pack(fill="x")
        hd = tk.Frame(bg, bg=w[1], pady=10); hd.pack(fill="x")
        tk.Label(hd, text="Inicio", bg=w[1], fg=TXT,
                 font=("Segoe UI",18,"bold")).pack(side="left", padx=20)
        tk.Button(hd, text="Power", bg=CARD, fg=ERR, font=("Segoe UI",9,"bold"),
                  relief="flat", command=self.power, padx=10, pady=4).pack(side="right", padx=15)
        tk.Button(hd, text="Apps", bg=CARD, fg=PRI, font=("Segoe UI",9,"bold"),
                  relief="flat", command=self.apps_screen, padx=10, pady=4).pack(side="right", padx=5)
        cf = tk.Frame(bg, bg=w[1]); cf.pack(fill="both", expand=True)
        cv = tk.Canvas(cf, bg=w[1], highlightthickness=0); cv.pack(side="left", fill="both", expand=True)
        sb = tk.Scrollbar(cf, orient="vertical", command=cv.yview); sb.pack(side="right", fill="y")
        cv.configure(yscrollcommand=sb.set)
        g = tk.Frame(cv, bg=w[1])
        cv.create_window((0,0), window=g, anchor="nw", tags="g")
        cv.bind("<Configure>", lambda e:(cv.itemconfig("g", width=e.width),
                                          g.update_idletasks(),
                                          cv.config(scrollregion=cv.bbox("all"))))
        cv.bind_all("<MouseWheel>", lambda e: cv.yview_scroll(int(-1*(e.delta/120)),"units"))
        ii = inst()
        ee = []
        for a in APPS:
            if a[0] in ii: ee.append((a[0],a[2],a[3]))
        for c in customs(): ee.append((c.get("k","?"), c.get("col",PRI), c.get("ic","?")))
        for n,cat,ic,cl in STORE:
            if n in ii: ee.append((n,cl,ic))
        for idx,(k,cl,ic) in enumerate(ee):
            cd = tk.Frame(g, bg=w[1]); cd.grid(row=idx//4, column=idx%4, padx=10, pady=12)
            ico = icon(cd, cl, ic, 72, w[1]); ico.pack()
            def ck(e,kk=k): self.open(kk)
            ico.bind("<Button-1>", ck)
            tk.Label(cd, text=k[:9], bg=w[1], fg=TXT, font=("Segoe UI",9)).pack(pady=(6,0))
        dk = tk.Frame(bg, bg=CARD, height=76); dk.pack(fill="x", side="bottom")
        dk.pack_propagate(False)
        for k in ["Telefone","Camera","Loja","Config"]:
            a = find(k)
            if a and is_inst(k):
                df = tk.Frame(dk, bg=CARD); df.pack(side="left", expand=True, padx=6, pady=8)
                ic = icon(df, a[2], a[3], 54, CARD); ic.pack()
                def dck(e,kk=k): self.open(kk)
                ic.bind("<Button-1>", dck)

    def apps_screen(self):
        self.clear(); snd("click"); w=wp()
        bg = tk.Frame(self.s, bg=w[1]); bg.pack(fill="both", expand=True)
        self.bar(bg); tk.Frame(bg, bg="#000", height=NH).pack(fill="x")
        hd = tk.Frame(bg, bg=CARD, height=56); hd.pack(fill="x"); hd.pack_propagate(False)
        tk.Button(hd, text="<", bg=CARD, fg=TXT, font=("Segoe UI",16,"bold"),
                  relief="flat", command=self.home, padx=12).pack(side="left", pady=8)
        tk.Label(hd, text="Todos apps", bg=CARD, fg=TXT,
                 font=("Segoe UI",14,"bold")).pack(side="left", padx=8)
        tk.Button(hd, text="+", bg=PRI, fg="#000", font=("Segoe UI",14,"bold"),
                  relief="flat", command=self.nocode, padx=12, pady=2).pack(side="right", padx=10)
        tbs = tk.Frame(bg, bg=w[1], pady=8); tbs.pack(fill="x")
        cats = ["Todos","Sistema","Social","Jogos","Ferramentas","Media","Custom"]
        cur = [cats[0]]
        def st(t):
            cur[0]=t
            for ww in tbs.winfo_children(): ww.destroy()
            for c in cats:
                act=(c==t)
                tk.Button(tbs, text=c, bg=(PRI if act else CARD),
                          fg=("#000" if act else TXT), font=("Segoe UI",8,"bold" if act else "normal"),
                          relief="flat", command=lambda x=c: st(x)).pack(side="left", padx=2, pady=3, ipadx=4)
            rend()
        cf = tk.Frame(bg, bg=w[1]); cf.pack(fill="both", expand=True)
        cv = tk.Canvas(cf, bg=w[1], highlightthickness=0); cv.pack(side="left", fill="both", expand=True)
        sb = tk.Scrollbar(cf, orient="vertical", command=cv.yview); sb.pack(side="right", fill="y")
        cv.configure(yscrollcommand=sb.set)
        g = tk.Frame(cv, bg=w[1])
        cv.create_window((0,0), window=g, anchor="nw", tags="g")
        cv.bind("<Configure>", lambda e:(cv.itemconfig("g", width=e.width),
                                          g.update_idletasks(),
                                          cv.config(scrollregion=cv.bbox("all"))))
        cv.bind_all("<MouseWheel>", lambda e: cv.yview_scroll(int(-1*(e.delta/120)),"units"))
        def rend():
            for ww in g.winfo_children(): ww.destroy()
            cat = cur[0]; ii=inst(); it=[]
            for a in APPS:
                if a[0] in ii and (cat=="Todos" or a[5]==cat): it.append((a[0],a[2],a[3]))
            if cat in ("Todos","Custom"):
                for c in customs(): it.append((c.get("k","?"),c.get("col",PRI),c.get("ic","?")))
            if cat=="Todos" or cat in [s[1] for s in STORE]:
                for n,sc,ic,cl in STORE:
                    if n in ii and (cat=="Todos" or sc==cat): it.append((n,cl,ic))
            if not it:
                tk.Label(g, text="Nenhum app", bg=w[1], fg=DIM,
                         font=("Segoe UI",11)).pack(pady=50); return
            for idx,(k,cl,ic) in enumerate(it):
                cd = tk.Frame(g, bg=w[1]); cd.grid(row=idx//4, column=idx%4, padx=10, pady=12)
                ico = icon(cd, cl, ic, 72, w[1]); ico.pack()
                def ck(e,kk=k): self.open(kk)
                ico.bind("<Button-1>", ck)
                tk.Label(cd, text=k[:9], bg=w[1], fg=TXT, font=("Segoe UI",9)).pack(pady=(6,0))
        st("Todos")

    def nocode(self):
        snd("click")
        w = tk.Toplevel(self.r); w.title("Criador de Apps"); w.geometry("400x560")
        w.configure(bg=BG)
        tk.Label(w, text="CRIADOR DE APPS", bg=BG, fg=PRI,
                 font=("Segoe UI",16,"bold")).pack(pady=15)
        tk.Label(w, text="Nome:", bg=BG, fg=TXT, font=("Segoe UI",10)).pack(anchor="w", padx=20)
        ne = tk.Entry(w, bg=CARD, fg=TXT, insertbackground=TXT,
                      font=("Segoe UI",12), relief="flat")
        ne.pack(fill="x", padx=20, pady=(3,15), ipady=8)
        tk.Label(w, text="Cor:", bg=BG, fg=TXT, font=("Segoe UI",10)).pack(anchor="w", padx=20)
        cfr = tk.Frame(w, bg=BG); cfr.pack(fill="x", padx=20, pady=(3,15))
        cv = [PRI]
        for c in [PRI,OK,WARN,ERR,PINK,PURP,BLUE,TEAL]:
            def mk(col):
                def cmd(): cv[0]=col
                return cmd
            tk.Button(cfr, bg=c, width=3, relief="flat", command=mk(c)).pack(side="left", padx=3)
        tk.Label(w, text="Modelo:", bg=BG, fg=TXT, font=("Segoe UI",10)).pack(anchor="w", padx=20, pady=(10,5))
        tpls = ["Botao Contador","Texto","Relogio","Frase do Dia","Cronometro"]
        tv = [tpls[0]]
        for t in tpls:
            tk.Radiobutton(w, text=t, variable=tk.StringVar(value=tv[0]), value=t,
                          bg=CARD, fg=TXT, selectcolor=PRI, activebackground=CARD,
                          font=("Segoe UI",10,"bold"),
                          command=lambda x=t: tv.__setitem__(0,x)).pack(fill="x", padx=20, pady=1, ipady=2)
        tk.Label(w, text="Icone:", bg=BG, fg=TXT, font=("Segoe UI",10)).pack(anchor="w", padx=20, pady=(10,3))
        ie = tk.Entry(w, bg=CARD, fg=TXT, insertbackground=TXT,
                      font=("Segoe UI",12), relief="flat", width=5)
        ie.pack(anchor="w", padx=20, ipady=6); ie.insert(0,"A")
        def create():
            n = ne.get().strip()
            if not n: messagebox.showerror("Erro","Digite nome"); return
            ic = (ie.get() or n[0])[:3].upper()
            c = customs(); c.append({"k":n,"ic":ic,"col":cv[0],"tpl":tv[0]})
            sj(CUS_F, c); install(n)
            notify("App criado", n)
            snd("ok"); w.destroy(); self.apps_screen()
        tk.Button(w, text="CRIAR APP", bg=PRI, fg="#000",
                  font=("Segoe UI",13,"bold"), relief="flat",
                  command=create, pady=12).pack(fill="x", padx=20, pady=20)

    def custom_app(self, c):
        tpl = c.get("tpl","Texto"); cl = c.get("col",PRI); n = c.get("k","App")
        body = self.frame(self.s, n, cl)
        if tpl == "Botao Contador":
            cnt=[0]
            l = tk.Label(body, text="0", bg=BG, fg=cl, font=("Segoe UI",60,"bold"))
            l.pack(pady=40)
            def inc(): snd("click"); cnt[0]+=1; l.config(text=str(cnt[0]))
            tk.Button(body, text="Clique!", bg=cl, fg="#000",
                      font=("Segoe UI",14,"bold"), relief="flat",
                      command=inc, padx=40, pady=15).pack()
        elif tpl == "Texto":
            tk.Label(body, text=n, bg=BG, fg=cl, font=("Segoe UI",24,"bold"),
                     wraplength=320).pack(pady=60)
        elif tpl == "Relogio":
            l = tk.Label(body, text="", bg=BG, fg=cl, font=("Consolas",42,"bold"))
            l.pack(pady=60)
            def tk_():
                try:
                    if not l.winfo_exists(): return
                    l.config(text=datetime.datetime.now().strftime("%H:%M:%S"))
                    l.after(1000, tk_)
                except: pass
            tk_()
        elif tpl == "Frase do Dia":
            fr = ["A simplicidade e a ultima sofisticacao.","A pratica leva a perfeicao.",
                  "Todo projeto comecou com uma linha de codigo."]
            l = tk.Label(body, text="", bg=BG, fg=cl, font=("Segoe UI",14,"italic"),
                         wraplength=320, pady=40)
            l.pack(fill="both", expand=True, padx=20)
            def novo(): l.config(text='"%s"' % random.choice(fr))
            novo()
            tk.Button(body, text="Nova", bg=cl, fg="#000",
                      font=("Segoe UI",11,"bold"), relief="flat",
                      command=novo, padx=25, pady=10).pack(pady=10)
        elif tpl == "Cronometro":
            st = {"r":False,"s":0,"e":0}
            l = tk.Label(body, text="00:00.00", bg=BG, fg=cl, font=("Consolas",36,"bold"))
            l.pack(pady=50)
            def tk_():
                try:
                    if not l.winfo_exists(): return
                    if st["r"]:
                        el = st["e"] + (time.time()-st["s"])
                        l.config(text="%02d:%05.2f" % (int(el//60), el%60))
                    l.after(50, tk_)
                except: pass
            def tg():
                if st["r"]: st["e"]+=time.time()-st["s"]; st["r"]=False
                else: st["s"]=time.time(); st["r"]=True
            def rs(): st["r"]=False; st["e"]=0; l.config(text="00:00.00")
            bf = tk.Frame(body, bg=BG); bf.pack()
            tk.Button(bf, text="Iniciar/Parar", bg=cl, fg="#000",
                      font=("Segoe UI",10,"bold"), relief="flat",
                      command=tg, padx=15, pady=6).pack(side="left", padx=3)
            tk.Button(bf, text="Reset", bg=ERR, fg="white",
                      font=("Segoe UI",10,"bold"), relief="flat",
                      command=rs, padx=15, pady=6).pack(side="left", padx=3)
            tk_()
        tk.Button(body, text="Deletar", bg=ERR, fg="white",
                  font=("Segoe UI",10,"bold"), relief="flat",
                  command=lambda: self.del_custom(n), padx=20, pady=8).pack(pady=15)

    def del_custom(self, n):
        if not messagebox.askyesno("Deletar","Deletar "+n+"?"): return
        c = [x for x in customs() if x.get("k") != n]
        sj(CUS_F, c); uninstall(n); self.home()

    def power(self):
        snd("click")
        ov = tk.Frame(self.s, bg="#000")
        ov.place(x=0, y=0, relwidth=1, relheight=1)
        cd = tk.Frame(ov, bg=CARD, padx=30, pady=30)
        cd.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(cd, text="Energia", bg=CARD, fg=TXT,
                 font=("Segoe UI",14,"bold")).pack(pady=(0,20))
        def lk(): ov.destroy(); self.lock()
        def rb(): ov.destroy(); self.lock(); notify("Sistema","Reiniciado")
        def sd(): ov.destroy(); self.r.destroy()
        for lbl,col,cmd in [("Bloquear",PRI,lk),("Reiniciar",WARN,rb),("Desligar",ERR,sd)]:
            tk.Button(cd, text=lbl, bg=col, fg=("#000" if col in (PRI,WARN) else "white"),
                      font=("Segoe UI",11,"bold"), relief="flat", command=cmd,
                      width=12, pady=8).pack(pady=3)
        tk.Button(cd, text="Cancelar", bg="#233045", fg=TXT,
                  font=("Segoe UI",10), relief="flat",
                  command=ov.destroy, width=12, pady=6).pack(pady=(15,0))

    def open(self, k):
        snd("click")
        a = find(k)
        if a:
            try: a[1](self.s, self)
            except Exception as e: messagebox.showerror("Erro", str(e))
            return
        for c in customs():
            if c.get("k")==k: self.custom_app(c); return
        if is_inst(k): self.stub(k); return
        messagebox.showerror("Erro","Nao encontrado")

    def stub(self, n):
        s = store_find(n)
        cl = s[3] if s else PRI
        ic = s[2] if s else n[0]
        body = self.frame(self.s, n, cl)
        ico = icon(body, cl, ic, 120, BG); ico.pack(pady=30)
        tk.Label(body, text=n, bg=BG, fg=TXT, font=("Segoe UI",18,"bold")).pack()
        tk.Label(body, text="App funcionando!", bg=BG, fg=OK,
                 font=("Segoe UI",12,"bold")).pack(pady=10)
        def un():
            if messagebox.askyesno("Desinstalar","Remover?"):
                uninstall(n); self.home()
        tk.Button(body, text="Desinstalar", bg=ERR, fg="white",
                  font=("Segoe UI",10,"bold"), relief="flat",
                  command=un, padx=20, pady=8).pack(pady=20)

    def frame(self, p, title, cl):
        for w in p.winfo_children():
            try: w.destroy()
            except: pass
        self.bar(p)
        tk.Frame(p, bg="#000", height=NH).pack(fill="x")
        h = tk.Frame(p, bg=cl, height=54); h.pack(fill="x"); h.pack_propagate(False)
        tk.Button(h, text="<", bg=cl, fg="white", font=("Segoe UI",16,"bold"),
                  relief="flat", command=self.home, padx=12).pack(side="left", pady=8)
        tk.Label(h, text=title, bg=cl, fg="white",
                 font=("Segoe UI",14,"bold")).pack(side="left", padx=8)
        b = tk.Frame(p, bg=BG); b.pack(fill="both", expand=True)
        return b

    def admin(self):
        body = self.frame(self.s, "ADMIN", ERR)
        tk.Label(body, text="MODO ADMINISTRADOR", bg=BG, fg=ERR,
                 font=("Segoe UI",13,"bold")).pack(pady=10)
        cf = tk.Frame(body, bg=BG); cf.pack(fill="both", expand=True)
        cv = tk.Canvas(cf, bg=BG, highlightthickness=0); cv.pack(side="left", fill="both", expand=True)
        sb = tk.Scrollbar(cf, orient="vertical", command=cv.yview); sb.pack(side="right", fill="y")
        cv.configure(yscrollcommand=sb.set)
        inn = tk.Frame(cv, bg=BG)
        cv.create_window((0,0), window=inn, anchor="nw", tags="i")
        cv.bind("<Configure>", lambda e:(cv.itemconfig("i", width=e.width),
                                          inn.update_idletasks(),
                                          cv.config(scrollregion=cv.bbox("all"))))
        cv.bind_all("<MouseWheel>", lambda e: cv.yview_scroll(int(-1*(e.delta/120)),"units"))
        def sec(t):
            tk.Label(inn, text=t, bg=BG, fg=DIM, font=("Segoe UI",9,"bold"),
                     anchor="w").pack(fill="x", padx=15, pady=(12,5))
        def act(lbl, cmd, cl=PRI):
            r = tk.Frame(inn, bg=CARD, pady=10, padx=12)
            r.pack(fill="x", padx=8, pady=2)
            tk.Label(r, text=lbl, bg=CARD, fg=TXT, font=("Segoe UI",10,"bold"),
                     anchor="w").pack(side="left")
            tk.Button(r, text=">", bg=CARD, fg=cl, font=("Segoe UI",11,"bold"),
                      relief="flat", command=cmd, padx=8).pack(side="right")
        sec("EFEITOS")
        def glitch():
            ov = tk.Toplevel(self.r); ov.overrideredirect(True); ov.attributes("-topmost",True)
            ov.geometry("%dx%d+%d+%d" % (PW,PH,self.r.winfo_rootx()+BW,self.r.winfo_rooty()+BW))
            c2 = tk.Canvas(ov, bg="#000", highlightthickness=0); c2.pack(fill="both", expand=True)
            cols=[PRI,OK,ERR,WARN,PINK,PURP]
            def fr(n):
                if not ov.winfo_exists() or n<=0:
                    try: ov.destroy()
                    except: pass
                    return
                c2.delete("all")
                for _ in range(30):
                    c2.create_rectangle(random.randint(0,PW), random.randint(0,PH),
                                         random.randint(20,150)+random.randint(0,PW),
                                         random.randint(2,15),
                                         fill=random.choice(cols), outline="")
                ov.after(50, lambda: fr(n-1))
            fr(30)
        act("Efeito Glitch", glitch, ERR)
        def matrix():
            ov = tk.Toplevel(self.r); ov.overrideredirect(True); ov.attributes("-topmost",True)
            ov.geometry("%dx%d+%d+%d" % (PW,PH,self.r.winfo_rootx()+BW,self.r.winfo_rooty()+BW))
            c2 = tk.Canvas(ov, bg="#000", highlightthickness=0); c2.pack(fill="both", expand=True)
            chars="01ABCDEFGHIJ"
            cols=PW//12; drops=[random.randint(0,60) for _ in range(cols)]
            def fr(n):
                if not ov.winfo_exists() or n<=0:
                    try: ov.destroy()
                    except: pass
                    return
                c2.delete("all")
                for i in range(cols):
                    for j in range(drops[i]%60, min((drops[i]%60)+5,60)):
                        c2.create_text(i*12,j*14,text=random.choice(chars),
                                       fill=OK,font=("Consolas",10,"bold"))
                    drops[i]+=1
                ov.after(80, lambda: fr(n-1))
            fr(60)
        act("Matrix Rain", matrix, OK)
        def invert():
            ov = tk.Toplevel(self.r); ov.overrideredirect(True); ov.attributes("-topmost",True)
            ov.geometry("%dx%d+%d+%d" % (PW,PH,self.r.winfo_rootx()+BW,self.r.winfo_rooty()+BW))
            c2 = tk.Canvas(ov, bg="#fff", highlightthickness=0); c2.pack(fill="both", expand=True)
            c2.create_rectangle(0,0,PW,PH, fill="#fff", outline="")
            c2.create_text(PW//2,PH//2, text="INVERTIDO", fill="#000",
                           font=("Segoe UI",30,"bold"))
            ov.after(1500, ov.destroy)
        act("Inverter Cores (1.5s)", invert, TXT)
        def rainbow():
            ov = tk.Toplevel(self.r); ov.overrideredirect(True); ov.attributes("-topmost",True)
            ov.geometry("%dx%d+%d+%d" % (PW,PH,self.r.winfo_rootx()+BW,self.r.winfo_rooty()+BW))
            c2 = tk.Canvas(ov, bg="#000", highlightthickness=0); c2.pack(fill="both", expand=True)
            def fr(n):
                if not ov.winfo_exists() or n<=0:
                    try: ov.destroy()
                    except: pass
                    return
                c2.delete("all")
                for i in range(PH//4):
                    hue=int((n*10+i*5)%360)
                    r=int(127+127*math.cos(math.radians(hue)))
                    g=int(127+127*math.cos(math.radians(hue-120)))
                    b=int(127+127*math.cos(math.radians(hue+120)))
                    c2.create_rectangle(0,i*4,PW,i*4+4,
                                         fill="#%02x%02x%02x"%(r,g,b), outline="")
                ov.after(50, lambda: fr(n-1))
            fr(60)
        act("Arco-iris (3s)", rainbow, PINK)
        sec("SISTEMA")
        def console():
            w = tk.Toplevel(self.r); w.title("Console"); w.geometry("500x400")
            w.configure(bg="#000")
            o = tk.Text(w, bg="#000", fg=OK, font=("Consolas",10), relief="flat", padx=10, pady=10)
            o.pack(fill="both", expand=True); o.insert("end",">>> Console\n"); o.config(state="disabled")
            inf = tk.Frame(w, bg="#000"); inf.pack(fill="x", padx=10, pady=5)
            tk.Label(inf, text=">>>", bg="#000", fg=OK,
                     font=("Consolas",10,"bold")).pack(side="left")
            e = tk.Entry(inf, bg="#000", fg=OK, insertbackground=OK,
                         font=("Consolas",10), relief="flat")
            e.pack(side="left", fill="x", expand=True, ipady=4); e.focus_set()
            def run(ev=None):
                code = e.get(); e.delete(0,"end")
                o.config(state="normal"); o.insert("end", ">>> "+code+"\n")
                try:
                    try: r = eval(code); o.insert("end", str(r)+"\n")
                    except: exec(code, {}); o.insert("end", "[OK]\n")
                except Exception as ex: o.insert("end", "Erro: "+str(ex)+"\n")
                o.see("end"); o.config(state="disabled")
            e.bind("<Return>", run)
        act("Console Python", console, OK)
        def reset():
            if not messagebox.askyesno("RESET","Apagar tudo?"): return
            for f in [INST_F,CFG_F,CUS_F,NOT_F]:
                try:
                    if os.path.exists(f): os.remove(f)
                except: pass
            messagebox.showinfo("OK","Resetado"); self.lock()
        act("Factory Reset", reset, ERR)
        sec("DISPOSITIVO")
        def bat():
            c = cfg()
            p = simpledialog.askinteger("Bateria","Nivel (0-100):", initialvalue=c.get("bat",100),
                                          minvalue=0, maxvalue=100, parent=self.r)
            if p is not None: c["bat"]=p; scfg(c); messagebox.showinfo("OK",str(p)+"%")
        act("Nivel da bateria", bat, OK)
        def rpin():
            c=cfg(); c["passwd"]="1234"; c["pin"]=False; scfg(c)
            messagebox.showinfo("OK","PIN resetado (1234)")
        act("Reset PIN", rpin, WARN)
        def dispin():
            c=cfg(); c["pin"]=False; scfg(c); messagebox.showinfo("OK","PIN off"); self.home()
        act("Bypass PIN", dispin, ERR)
        sec("SAIR")
        def disable():
            c=cfg(); c["admin"]=False; scfg(c); ADMIN[0]=False
            messagebox.showinfo("OK","Admin off"); self.home()
        act("Desativar Admin", disable, DIM)

    def settings(self):
        body = self.frame(self.s, "Configuracoes", DIM)
        c = cfg()
        tbs = tk.Frame(body, bg=BG); tbs.pack(fill="x", padx=5, pady=5)
        ct = tk.Frame(body, bg=BG); ct.pack(fill="both", expand=True)
        cats = ["Geral","Rede","Som","Seguranca","Wallpaper","Sobre"]
        if ADMIN[0]: cats.append("Admin")
        def st(ch):
            for w in tbs.winfo_children(): w.destroy()
            for w in ct.winfo_children(): w.destroy()
            for cat in cats:
                a = (cat==ch)
                tk.Button(tbs, text=cat, bg=(PRI if a else CARD), fg=("#000" if a else TXT),
                          font=("Segoe UI",8,"bold" if a else "normal"),
                          relief="flat", command=lambda x=cat: st(x)).pack(
                          side="left", padx=2, ipadx=5)
            if ch=="Geral":
                tk.Button(ct, text="Tela cheia (F11)", bg=PRI, fg="#000",
                          font=("Segoe UI",11,"bold"), relief="flat",
                          command=lambda: self.r.attributes("-fullscreen",
                              not self.r.attributes("-fullscreen")),
                          pady=10).pack(fill="x", padx=20, pady=10)
                tk.Button(ct, text="Power Menu", bg=ERR, fg="white",
                          font=("Segoe UI",11,"bold"), relief="flat",
                          command=self.power, pady=10).pack(fill="x", padx=20, pady=5)
            elif ch=="Rede":
                for lbl,key,cl in [("Wi-Fi","wifi",OK),("Bluetooth","bt",BLUE)]:
                    r = tk.Frame(ct, bg=CARD, pady=12, padx=15)
                    r.pack(fill="x", padx=10, pady=3)
                    tk.Label(r, text=lbl, bg=CARD, fg=TXT,
                             font=("Segoe UI",11,"bold"), anchor="w").pack(side="left")
                    s = c.get(key,False)
                    l = tk.Label(r, text=("Ligado" if s else "Desligado"),
                                 bg=(cl if s else ERR), fg="white",
                                 font=("Segoe UI",9,"bold"), padx=12, pady=4, cursor="hand2")
                    l.pack(side="right")
                    def mk(k=key,ll=l,cc=cl):
                        def tog(e=None):
                            snd("click")
                            nv = not c.get(k,False); c[k]=nv; scfg(c)
                            ll.config(text=("Ligado" if nv else "Desligado"),
                                      bg=(cc if nv else ERR))
                        return tog
                    l.bind("<Button-1>", mk())
                ni = net()
                tk.Label(ct, text="SSID: "+(ni.get("ssid") or "N/A"), bg=BG, fg=DIM,
                         font=("Segoe UI",9)).pack(pady=5)
                tk.Label(ct, text="IP: "+(ni.get("ip") or "N/A"), bg=BG, fg=DIM,
                         font=("Segoe UI",9)).pack()
            elif ch=="Som":
                for lbl,key,cl in [("Som do sistema","som",PINK),("Notif","som",WARN)]:
                    r = tk.Frame(ct, bg=CARD, pady=12, padx=15)
                    r.pack(fill="x", padx=10, pady=3)
                    tk.Label(r, text=lbl, bg=CARD, fg=TXT,
                             font=("Segoe UI",11,"bold"), anchor="w").pack(side="left")
                    s = c.get(key,False)
                    l = tk.Label(r, text=("Ligado" if s else "Desligado"),
                                 bg=(cl if s else ERR), fg="white",
                                 font=("Segoe UI",9,"bold"), padx=12, pady=4, cursor="hand2")
                    l.pack(side="right")
                    def mk(k=key,ll=l,cc=cl):
                        def tog(e=None):
                            snd("click")
                            nv = not c.get(k,False); c[k]=nv; scfg(c)
                            ll.config(text=("Ligado" if nv else "Desligado"),
                                      bg=(cc if nv else ERR))
                        return tog
                    l.bind("<Button-1>", mk())
                for n,k in [("Click","click"),("Notif","notif"),("Erro","error"),("Ok","ok")]:
                    r = tk.Frame(ct, bg=CARD, pady=8, padx=15)
                    r.pack(fill="x", padx=10, pady=2)
                    tk.Label(r, text=n, bg=CARD, fg=TXT, font=("Segoe UI",10)).pack(side="left")
                    tk.Button(r, text="Tocar", bg=PINK, fg="white",
                              font=("Segoe UI",8,"bold"), relief="flat",
                              command=lambda kk=k: snd(kk), padx=10, pady=3).pack(side="right")
            elif ch=="Seguranca":
                r = tk.Frame(ct, bg=CARD, pady=12, padx=15)
                r.pack(fill="x", padx=10, pady=3)
                tk.Label(r, text="Senha", bg=CARD, fg=TXT,
                         font=("Segoe UI",11,"bold"), anchor="w").pack(side="left")
                s = c.get("pin",False)
                l = tk.Label(r, text=("Ligada" if s else "Desligada"),
                             bg=(OK if s else ERR), fg="white",
                             font=("Segoe UI",9,"bold"), padx=12, pady=4, cursor="hand2")
                l.pack(side="right")
                def tog(e=None):
                    snd("click")
                    nv = not c.get("pin",False); c["pin"]=nv; scfg(c)
                    l.config(text=("Ligada" if nv else "Desligada"),
                             bg=(OK if nv else ERR))
                l.bind("<Button-1>", tog)
                def chg():
                    nv = simpledialog.askstring("Nova senha","4+ chars:", parent=self.r)
                    if nv and len(nv)>=4: c["passwd"]=nv; scfg(c); messagebox.showinfo("OK","Mudou")
                tk.Button(ct, text="Mudar senha", bg=PRI, fg="#000",
                          font=("Segoe UI",10,"bold"), relief="flat",
                          command=chg, pady=8).pack(fill="x", padx=20, pady=10)
            elif ch=="Wallpaper":
                tk.Label(ct, text="Escolha:", bg=BG, fg=TXT,
                         font=("Segoe UI",11,"bold")).pack(pady=10)
                for i,(n,c1,c2) in enumerate(WALLS):
                    r = tk.Frame(ct, bg=CARD, pady=8, padx=15)
                    r.pack(fill="x", padx=10, pady=2)
                    prev = tk.Canvas(r, width=40, height=40, bg=c1, highlightthickness=0)
                    prev.pack(side="left")
                    prev.create_rectangle(20,0,40,40, fill=c2, outline="")
                    tk.Label(r, text=n, bg=CARD, fg=TXT,
                             font=("Segoe UI",10,"bold")).pack(side="left", padx=10)
                    def mk(idx=i):
                        def ap():
                            c["wall"]=idx; scfg(c); self.settings()
                        return ap
                    tk.Button(r, text="Aplicar", bg=PRI, fg="#000",
                              font=("Segoe UI",8,"bold"), relief="flat",
                              command=mk(), padx=10, pady=3).pack(side="right")
            elif ch=="Sobre":
                tk.Label(ct, text="minstcaveOS", bg=BG, fg=PRI,
                         font=("Segoe UI",18,"bold")).pack(pady=(30,5))
                tk.Label(ct, text="v"+V, bg=BG, fg=TXT, font=("Segoe UI",11)).pack()
                tk.Label(ct, text="Sistema para estudantes", bg=BG, fg=WARN,
                         font=("Segoe UI",10,"bold")).pack(pady=15)
                tk.Label(ct, text="CODIGO DE ATIVACAO", bg=BG, fg=DIM,
                         font=("Segoe UI",9,"bold")).pack(pady=(20,5))
                e = tk.Entry(ct, bg=CARD, fg=PRI, insertbackground=PRI,
                             font=("Consolas",12), relief="flat", justify="center", width=20)
                e.pack(ipady=8)
                stt = tk.Label(ct, text="", bg=BG, fg=DIM, font=("Segoe UI",9))
                stt.pack(pady=5)
                def check(ev=None):
                    if e.get().strip()==ADMIN_CODE:
                        c["admin"]=True; scfg(c); ADMIN[0]=True
                        stt.config(text="Admin ativado!", fg=OK); snd("ok"); self.settings()
                    elif ADMIN[0]: stt.config(text="Ja ativo", fg=WARN)
                    else: stt.config(text="Incorreto", fg=ERR); snd("error")
                e.bind("<Return>", check)
                tk.Button(ct, text="Ativar", bg=PRI, fg="#000",
                          font=("Segoe UI",10,"bold"), relief="flat",
                          command=check, padx=20, pady=6).pack(pady=10)
            elif ch=="Admin":
                tk.Label(ct, text="MODO ADMIN", bg=BG, fg=ERR,
                         font=("Segoe UI",13,"bold")).pack(pady=20)
                tk.Button(ct, text="Abrir Painel", bg=ERR, fg="white",
                          font=("Segoe UI",12,"bold"), relief="flat",
                          command=self.admin, padx=30, pady=12).pack(pady=10)
        st(cats[0])

    def store(self):
        body = self.frame(self.s, "Play Store", OK)
        tk.Label(body, text="Apps para instalar", bg=BG, fg=TXT,
                 font=("Segoe UI",12,"bold")).pack(pady=10)
        cf = tk.Frame(body, bg=BG); cf.pack(fill="both", expand=True)
        cv = tk.Canvas(cf, bg=BG, highlightthickness=0); cv.pack(side="left", fill="both", expand=True)
        sb = tk.Scrollbar(cf, orient="vertical", command=cv.yview); sb.pack(side="right", fill="y")
        cv.configure(yscrollcommand=sb.set)
        inn = tk.Frame(cv, bg=BG)
        cv.create_window((0,0), window=inn, anchor="nw", tags="i")
        cv.bind("<Configure>", lambda e:(cv.itemconfig("i", width=e.width),
                                          inn.update_idletasks(),
                                          cv.config(scrollregion=cv.bbox("all"))))
        cv.bind_all("<MouseWheel>", lambda e: cv.yview_scroll(int(-1*(e.delta/120)),"units"))
        def rend():
            for w in inn.winfo_children(): w.destroy()
            cats = {}
            for n,cat,ic,cl in STORE: cats.setdefault(cat,[]).append((n,ic,cl))
            for cat in sorted(cats.keys()):
                tk.Label(inn, text=cat.upper(), bg=BG, fg=DIM,
                         font=("Segoe UI",9,"bold"), anchor="w").pack(fill="x", padx=15, pady=(10,5))
                for n,ic,cl in cats[cat]:
                    r = tk.Frame(inn, bg=CARD, pady=10, padx=10)
                    r.pack(fill="x", padx=8, pady=3)
                    ico = icon(r, cl, ic, 50, CARD); ico.pack(side="left", padx=5)
                    inf = tk.Frame(r, bg=CARD); inf.pack(side="left", fill="x", expand=True, padx=10)
                    tk.Label(inf, text=n, bg=CARD, fg=TXT,
                             font=("Segoe UI",10,"bold"), anchor="w").pack(fill="x")
                    tk.Label(inf, text=cat, bg=CARD, fg=DIM,
                             font=("Segoe UI",8), anchor="w").pack(fill="x")
                    if is_inst(n):
                        tk.Button(r, text="Instalado", bg=CARD, fg=OK,
                                  font=("Segoe UI",8,"bold"), relief="flat",
                                  padx=10, pady=4, state="disabled").pack(side="right", padx=5)
                    else:
                        def inst_(nm=n):
                            install(nm); notify("Play", nm+" instalado")
                            snd("ok"); rend()
                        tk.Button(r, text="Instalar", bg=OK, fg="white",
                                  font=("Segoe UI",8,"bold"), relief="flat",
                                  command=inst_, padx=10, pady=4).pack(side="right", padx=5)
        rend()

# ============================================================
# GAMES (FUNCIONAM DE VERDADE!)
# ============================================================
def app_snake(p, os):
    b = os.frame(p, "Snake", OK)
    cv = tk.Canvas(b, bg="#0a0a0f", highlightthickness=0, width=340, height=340)
    cv.pack(pady=10)
    st = {"s":[(8,8)],"d":(1,0),"f":(4,4),"sc":0,"alive":True}
    cell = 17
    def draw():
        cv.delete("all")
        for x,y in st["s"]:
            cv.create_rectangle(x*cell,y*cell,(x+1)*cell,(y+1)*cell, fill=OK, outline="")
        fx,fy = st["f"]
        cv.create_rectangle(fx*cell,fy*cell,(fx+1)*cell,(fy+1)*cell, fill=ERR, outline="")
        cv.create_text(10,10,anchor="nw", text="Score: %d" % st["sc"],
                       fill="white", font=("Consolas",10,"bold"))
    def step():
        try:
            if not cv.winfo_exists() or not st["alive"]: return
            hx,hy = st["s"][0]; dx,dy = st["d"]
            nx,ny = hx+dx, hy+dy
            if nx<0 or nx>=20 or ny<0 or ny>=20 or (nx,ny) in st["s"]:
                st["alive"]=False
                cv.create_text(170,170, text="GAME OVER\n%d" % st["sc"],
                               fill=ERR, font=("Segoe UI",18,"bold"), justify="center")
                return
            st["s"].insert(0,(nx,ny))
            if (nx,ny)==st["f"]:
                st["sc"]+=1
                while True:
                    nf=(random.randint(0,19),random.randint(0,19))
                    if nf not in st["s"]: break
                st["f"]=nf
            else: st["s"].pop()
            draw(); cv.after(120, step)
        except: pass
    def rst():
        st["s"]=[(8,8)]; st["d"]=(1,0); st["f"]=(4,4); st["sc"]=0; st["alive"]=True
        draw(); step()
    def key(e):
        k=e.keysym; d=st["d"]
        if k=="Up" and d!=(0,1): st["d"]=(0,-1)
        elif k=="Down" and d!=(0,-1): st["d"]=(0,1)
        elif k=="Left" and d!=(1,0): st["d"]=(-1,0)
        elif k=="Right" and d!=(-1,0): st["d"]=(1,0)
    cv.bind("<Button-1>", lambda e: cv.focus_set())
    cv.focus_set(); cv.bind("<Key>", key)
    tk.Button(b, text="Reiniciar", bg=OK, fg="white",
              font=("Segoe UI",10,"bold"), relief="flat", command=rst, pady=6).pack(pady=5)
    tk.Label(b, text="Use as setas", bg=BG, fg=DIM, font=("Segoe UI",8)).pack()
    step()

def app_2048(p, os):
    b = os.frame(p, "2048", WARN)
    cv = tk.Canvas(b, bg=CARD, highlightthickness=0, width=340, height=340)
    cv.pack(pady=10)
    colors = {2:"#eee4da",4:"#ede0c8",8:"#f2b179",16:"#f59563",32:"#f67c5f",
              64:"#f65e3b",128:"#edcf72",256:"#edcc61",512:"#edc850",
              1024:"#edc53f",2048:"#edc22e"}
    g = [[0]*4 for _ in range(4)]
    def add():
        em = [(r,c) for r in range(4) for c in range(4) if g[r][c]==0]
        if em:
            r,c = random.choice(em)
            g[r][c] = 2 if random.random()<0.9 else 4
    def draw():
        cv.delete("all")
        for r in range(4):
            for c in range(4):
                x=c*80+5; y=r*80+5; v=g[r][c]
                if v==0:
                    cv.create_rectangle(x,y,x+70,y+70, fill="#3a3a3a", outline="")
                else:
                    cv.create_rectangle(x,y,x+70,y+70, fill=colors.get(v,"#3c3a32"), outline="")
                    fs = 22 if v<100 else (18 if v<1000 else 14)
                    cv.create_text(x+35,y+35, text=str(v), fill="#776e65",
                                   font=("Segoe UI",fs,"bold"))
    def move(d):
        mv = False
        if d=="left":
            for r in range(4):
                row = [x for x in g[r] if x!=0]; new=[]; i=0
                while i<len(row):
                    if i+1<len(row) and row[i]==row[i+1]: new.append(row[i]*2); i+=2
                    else: new.append(row[i]); i+=1
                new += [0]*(4-len(new))
                if new != g[r]: mv=True; g[r]=new
        elif d=="right":
            for r in range(4):
                row = [x for x in g[r] if x!=0]; new=[]; i=len(row)-1
                while i>=0:
                    if i-1>=0 and row[i]==row[i-1]: new.insert(0,row[i]*2); i-=2
                    else: new.insert(0,row[i]); i-=1
                new = [0]*(4-len(new))+new
                if new != g[r]: mv=True; g[r]=new
        elif d=="up":
            for c in range(4):
                col = [g[r][c] for r in range(4) if g[r][c]!=0]; new=[]; i=0
                while i<len(col):
                    if i+1<len(col) and col[i]==col[i+1]: new.append(col[i]*2); i+=2
                    else: new.append(col[i]); i+=1
                new += [0]*(4-len(new))
                for r in range(4):
                    if g[r][c] != new[r]: mv=True
                    g[r][c] = new[r]
        elif d=="down":
            for c in range(4):
                col = [g[r][c] for r in range(4) if g[r][c]!=0]; new=[]; i=len(col)-1
                while i>=0:
                    if i-1>=0 and col[i]==col[i-1]: new.insert(0,col[i]*2); i-=2
                    else: new.insert(0,col[i]); i-=1
                new = [0]*(4-len(new))+new
                for r in range(4):
                    if g[r][c] != new[r]: mv=True
                    g[r][c] = new[r]
        if mv: add(); draw()
    def rst():
        for r in range(4):
            for c in range(4): g[r][c]=0
        add(); add(); draw()
    def key(e):
        k = e.keysym
        if k=="Up": move("up")
        elif k=="Down": move("down")
        elif k=="Left": move("left")
        elif k=="Right": move("right")
    cv.bind("<Button-1>", lambda e: cv.focus_set())
    cv.focus_set(); cv.bind("<Key>", key)
    tk.Button(b, text="Reiniciar", bg=WARN, fg="#000",
              font=("Segoe UI",10,"bold"), relief="flat", command=rst, pady=6).pack(pady=5)
    tk.Label(b, text="Use as setas", bg=BG, fg=DIM, font=("Segoe UI",8)).pack()
    add(); add(); draw()

def app_velha(p, os):
    b = os.frame(p, "Jogo da Velha", ORANGE)
    board = [""]*9; player=["X"]; btns=[]
    st = tk.Label(b, text="Vez de X", bg=BG, fg=TXT, font=("Segoe UI",12,"bold"))
    st.pack(pady=10)
    g = tk.Frame(b, bg=BG); g.pack()
    def chk():
        w = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
        for a,bb,c in w:
            if board[a] and board[a]==board[bb]==board[c]: return board[a]
        return "Empate" if "" not in board else None
    def click(i):
        if board[i] or chk(): return
        snd("click"); board[i]=player[0]
        btns[i].config(text=player[0], fg=(PRI if player[0]=="X" else ORANGE))
        w = chk()
        if w:
            st.config(text=("Empate!" if w=="Empate" else "Vencedor: "+w))
            snd("ok"); return
        player[0] = "O" if player[0]=="X" else "X"
        st.config(text="Vez de "+player[0])
    for i in range(9):
        bt = tk.Button(g, text="", bg=CARD, fg=TXT, font=("Segoe UI",22,"bold"),
                       width=4, height=2, relief="flat", command=lambda i=i: click(i))
        bt.grid(row=i//3, column=i%3, padx=2, pady=2)
        btns.append(bt)
    def rst():
        for i in range(9): board[i]=""; btns[i].config(text="")
        player[0]="X"; st.config(text="Vez de X")
    tk.Button(b, text="Reiniciar", bg=ORANGE, fg="#000",
              font=("Segoe UI",10,"bold"), relief="flat", command=rst, pady=6).pack(pady=10)

# ============================================================
# OUTROS APPS
# ============================================================
def app_tel(p, os):
    b = os.frame(p, "Telefone", OK)
    d = tk.Label(b, text="", bg=BG, fg=TXT, font=("Segoe UI",26,"bold"), pady=20)
    d.pack(fill="x")
    num = [""]
    def add(x): snd("click"); num[0]+=x; d.config(text=num[0])
    def clr(): num[0]=""; d.config(text="")
    def call():
        if num[0]: messagebox.showinfo("Chamando","Discando "+num[0]); notify("Chamada",num[0])
        else: messagebox.showerror("Erro","Digite")
    kp = tk.Frame(b, bg=BG); kp.pack(pady=10)
    for i,(k,sub) in enumerate([("1",""),("2","ABC"),("3","DEF"),("4","GHI"),("5","JKL"),
                                  ("6","MNO"),("7","PQRS"),("8","TUV"),("9","WXYZ"),("*",""),("0","+"),("#","")]):
        f = tk.Frame(kp, bg=BG); f.grid(row=i//3, column=i%3, padx=12, pady=4)
        tk.Button(f, text=k, bg=CARD, fg=TXT, font=("Segoe UI",18,"bold"),
                  width=3, height=1, relief="flat", command=lambda k=k: add(k)).pack()
        if sub: tk.Label(f, text=sub, bg=BG, fg=DIM, font=("Segoe UI",7)).pack()
    bf = tk.Frame(b, bg=BG); bf.pack(pady=15)
    tk.Button(bf, text="LIGAR", bg=OK, fg="white", font=("Segoe UI",11,"bold"),
              width=7, relief="flat", command=call, pady=10).pack(side="left", padx=8)
    tk.Button(bf, text="LIMPAR", bg=ERR, fg="white", font=("Segoe UI",11,"bold"),
              width=7, relief="flat", command=clr, pady=10).pack(side="left", padx=8)

def app_cam(p, os):
    b = os.frame(p, "Camera", PURP)
    prev = tk.Frame(b, bg="#000", relief="solid", bd=2)
    prev.pack(fill="both", expand=True, padx=10, pady=10)
    cv = tk.Canvas(prev, bg="#000", highlightthickness=0); cv.pack(fill="both", expand=True)
    def draw():
        cv.delete("all")
        w = cv.winfo_width() or 360; h = cv.winfo_height() or 380
        cv.create_rectangle(0,0,w,h//2, fill="#2a3a4a", outline="")
        cv.create_rectangle(0,h//2,w,h, fill="#1a2a1a", outline="")
        for i in range(6):
            x = i*w//6; bh = random.randint(40,100)
            cv.create_rectangle(x+5,h//2-bh,x+w//6-5,h//2, fill="#3a4a5a", outline="")
        for i in range(1,3):
            cv.create_line(w*i/3,0,w*i/3,h, fill="#555", dash=(2,4))
            cv.create_line(0,h*i/3,w,h*i/3, fill="#555", dash=(2,4))
        cw,ch = w//2, h//2
        cv.create_oval(cw-40,ch-40,cw+40,ch+40, outline="#0f0", width=2)
        cv.create_text(10,10,anchor="nw", text="AUTO", fill="#0f0", font=("Consolas",9,"bold"))
    cv.bind("<Configure>", lambda e: draw())
    draw()
    def snap():
        snd("notif"); cv.create_rectangle(0,0,500,500, fill="white", outline="")
        cv.after(100, draw); notify("Camera","Foto tirada"); messagebox.showinfo("Camera","Foto!")
    tk.Button(b, text="TIRAR FOTO", bg=PURP, fg="white", font=("Segoe UI",11,"bold"),
              relief="flat", command=snap, padx=20, pady=8).pack(pady=10)

def app_gal(p, os):
    b = os.frame(p, "Galeria", PINK)
    cv = tk.Canvas(b, bg=BG, highlightthickness=0); cv.pack(fill="both", expand=True, padx=10, pady=10)
    for i,c in enumerate([PRI,OK,WARN,ERR,PURP,PINK,BLUE,TEAL,CYAN,ORANGE,"#8bc34a","#9c27b0"]):
        col=i%3; row=i//3; x=col*118+15; y=row*118+15
        cv.create_rectangle(x,y,x+108,y+108, fill=c, outline="")
        cv.create_text(x+54,y+54,text=str(i+1), fill="white", font=("Segoe UI",22,"bold"))

def app_calc(p, os):
    b = os.frame(p, "Calculadora", WARN)
    d = tk.Entry(b, bg="#000", fg=TXT, insertbackground=TXT,
                 font=("Consolas",22), justify="right", relief="flat")
    d.pack(fill="x", padx=15, pady=15, ipady=12)
    def press(v):
        snd("click")
        if v=="C": d.delete(0,"end")
        elif v=="=":
            try:
                ex = d.get()
                if all(c in "0123456789+-*/(). " for c in ex):
                    r = eval(ex); d.delete(0,"end"); d.insert(0,str(r))
            except: d.delete(0,"end"); d.insert(0,"Erro")
        else: d.insert("end",v)
    btns = [["C","(",")","/"],["7","8","9","*"],["4","5","6","-"],["1","2","3","+"],["0",".","=",""]]
    g = tk.Frame(b, bg=BG); g.pack(fill="both", expand=True, padx=10, pady=10)
    for r,row in enumerate(btns):
        for c,lbl in enumerate(row):
            if not lbl: continue
            bg = CARD; fg = TXT
            if lbl in "=+-*/": bg=WARN; fg="#000"
            elif lbl=="C": bg=ERR
            tk.Button(g, text=lbl, bg=bg, fg=fg, font=("Segoe UI",16,"bold"),
                      relief="flat", command=lambda l=lbl: press(l)).grid(
                      row=r, column=c, sticky="nsew", padx=3, pady=3, ipady=12)
        g.rowconfigure(r, weight=1)
    for c in range(4): g.columnconfigure(c, weight=1)

def app_notas(p, os):
    b = os.frame(p, "Notas", PRI)
    t = tk.Text(b, bg=DARK, fg=TXT, insertbackground=PRI, font=("Segoe UI",11),
                relief="flat", padx=12, pady=12, wrap="word")
    t.pack(fill="both", expand=True, padx=10, pady=10)
    path = os.path.join(DATA,"notes.txt")
    if os.path.exists(path):
        try:
            f=open(path); t.insert("1.0",f.read()); f.close()
        except: pass
    st = tk.Label(b, text="", bg=BG, fg=OK, font=("Segoe UI",9)); st.pack()
    def save():
        try:
            f=open(path,"w"); f.write(t.get("1.0","end-1c")); f.close()
            st.config(text="Salvo!"); notify("Notas","Salvo")
        except Exception as e: st.config(text="Erro: "+str(e))
    tk.Button(b, text="SALVAR", bg=PRI, fg="#000", font=("Segoe UI",11,"bold"),
              relief="flat", command=save, padx=30, pady=10).pack(pady=8)

def app_cfg(p, os): os.settings()
def app_loja(p, os): os.store()
def app_adm(p, os): os.admin()

def app_net(p, os):
    b = os.frame(p, "Internet", CYAN)
    ni = net()
    sf = tk.Frame(b, bg=BG, pady=20); sf.pack(fill="x")
    tk.Label(sf, text=("CONECTADO" if ni["on"] else "OFF"),
             bg=BG, fg=(OK if ni["on"] else ERR), font=("Segoe UI",16,"bold")).pack()
    for lbl,val in [("SSID",ni.get("ssid") or "N/A"),("IP",ni.get("ip") or "N/A")]:
        r = tk.Frame(b, bg=CARD, pady=10, padx=15); r.pack(fill="x", padx=15, pady=3)
        tk.Label(r, text=lbl, bg=CARD, fg=DIM, font=("Segoe UI",10), anchor="w").pack(side="left")
        tk.Label(r, text=val, bg=CARD, fg=TXT, font=("Segoe UI",10,"bold")).pack(side="right")

def app_bt(p, os):
    b = os.frame(p, "Bluetooth", BLUE)
    c = cfg(); en = c.get("bt",False)
    tk.Label(b, text=("Ligado" if en else "Desligado"), bg=BG, fg=(OK if en else ERR),
             font=("Segoe UI",14,"bold")).pack(pady=15)
    if not en:
        tk.Label(b, text="Ative nas configs", bg=BG, fg=DIM, font=("Segoe UI",10)).pack(pady=40)
    else:
        for n,kind,sig in [("Fone BT","Audio",90),("Caixa Som","Audio",65),
                            ("Mouse","Input",45),("Watch","Wearable",55)]:
            r = tk.Frame(b, bg=CARD, pady=10, padx=15); r.pack(fill="x", padx=15, pady=3)
            tk.Label(r, text=n, bg=CARD, fg=TXT, font=("Segoe UI",10,"bold"), anchor="w").pack(side="left")
            tk.Label(r, text=str(sig)+"%", bg=CARD, fg=DIM, font=("Segoe UI",9)).pack(side="right")

def app_notif(p, os):
    b = os.frame(p, "Notificacoes", WARN)
    ns = notifs()
    if not ns:
        tk.Label(b, text="Sem notificacoes", bg=BG, fg=DIM, font=("Segoe UI",12)).pack(pady=60)
        return
    for n in reversed(ns):
        c = tk.Frame(b, bg=CARD, pady=10, padx=15); c.pack(fill="x", padx=10, pady=4)
        top = tk.Frame(c, bg=CARD); top.pack(fill="x")
        tk.Label(top, text=n.get("t",""), bg=CARD, fg=TXT, font=("Segoe UI",10,"bold"), anchor="w").pack(side="left")
        tk.Label(top, text=n.get("time",""), bg=CARD, fg=DIM, font=("Segoe UI",8)).pack(side="right")
        tk.Label(c, text=n.get("b",""), bg=CARD, fg=DIM, font=("Segoe UI",9), anchor="w",
                 wraplength=340, justify="left").pack(fill="x", pady=(3,0))
    tk.Button(b, text="Limpar", bg=ERR, fg="white", font=("Segoe UI",10,"bold"),
              relief="flat", command=lambda:(clear_notifs(),os.home()), padx=20, pady=8).pack(pady=15)

# ============================================================
def reg():
    APPS.extend([
        ("Telefone", app_tel, OK, "TEL", True, "Ferramentas"),
        ("Camera", app_cam, PURP, "CAM", True, "Ferramentas"),
        ("Galeria", app_gal, PINK, "GAL", True, "Media"),
        ("Calculadora", app_calc, WARN, "123", True, "Ferramentas"),
        ("Notas", app_notas, PRI, "NOT", True, "Ferramentas"),
        ("Config", app_cfg, DIM, "CFG", True, "Sistema"),
        ("Loja", app_loja, OK, "LOJ", True, "Sistema"),
        ("Internet", app_net, CYAN, "NET", True, "Sistema"),
        ("Bluetooth", app_bt, BLUE, "BT", True, "Sistema"),
        ("Notificacoes", app_notif, WARN, "NTS", True, "Sistema"),
        ("Snake", app_snake, OK, "SNK", True, "Jogos"),
        ("2048", app_2048, WARN, "2K", True, "Jogos"),
        ("Velha", app_velha, ORANGE, "XXX", True, "Jogos"),
    ])

if __name__ == "__main__":
    reg()
    try:
        os.system("cls" if os.name=="nt" else "clear")
        try:
            sys.stdout.write("minstcaveOS v"+V+"\n")
            sys.stdout.write("Encoding: "+str(getattr(sys.stdout,'encoding','?'))+"\n")
            sys.stdout.flush()
        except: pass
        time.sleep(0.5)
        snd("boot")
        app = OS()
        app.r.mainloop()
    except Exception as e:
        try:
            msg = "ERRO: "+type(e).__name__+"\n"+str(e)+"\n\n"+traceback.format_exc()
        except: msg = "ERRO desconhecido"
        try:
            f=open(os.path.join(BASE,"mobile_erro.log"),"w"); f.write(msg); f.close()
        except: pass
        try:
            sys.stdout.write(msg+"\n")
            sys.stdout.flush()
        except: pass
        try: input("ENTER...")
        except: pass