# -*- coding: utf-8 -*-
# minstcaveStation v7.0
import sys, io
try:
    if sys.stdout and hasattr(sys.stdout,'buffer'):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
    if sys.stderr and hasattr(sys.stderr,'buffer'):
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace', line_buffering=True)
except: pass

import os, json, math, datetime, random, time, traceback
import tkinter as tk
from tkinter import messagebox, simpledialog

try:
    import winsound; HAS_SOUND = True
except: HAS_SOUND = False

V = "7.0"
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "station_data")
CDS_DIR = os.path.join(DATA, "cds")
CFG_F = os.path.join(DATA, "config.json")
USERS_F = os.path.join(DATA, "users.json")

BG = "#0a0a0f"; CARD = "#1e1e2a"; CARD_HOVER = "#2a2a3a"
BORDER = "#2a2a3a"; ACCENT = "#0070e0"; ACCENT2 = "#00d4ff"
GOLD = "#ffc107"; SUCCESS = "#4caf50"; DANGER = "#f44336"
PURPLE = "#9c27b0"; PINK = "#e91e63"
TXT = "#ffffff"; TXT_DIM = "#7a7a8a"; TXT_MUTED = "#4a4a5a"

TABS = ["HOME", "JOGOS", "LOJA", "CONFIG"]
AVATAR_COLORS = ["#0070e0", "#e91e63", "#4caf50", "#ff9800",
                 "#9c27b0", "#00bcd4", "#ffc107", "#f44336"]
MAX_ACCOUNTS = 5

# 25 JOGOS da loja (todos com pre�o)
STORE_GAMES = [
    {"id":"zumbi","name":"Zumbi Shooter","desc":"Sobreviva as hordas","icon":"ZS","color":"#c51111","price":10},
    {"id":"snake","name":"Snake","desc":"Cobrinha classica","icon":"SN","color":"#4caf50","price":10},
    {"id":"coin","name":"Coin Flip","desc":"Cara ou coroa","icon":"CF","color":"#ffc107","price":5},
    {"id":"dice","name":"Dado","desc":"Role o dado","icon":"DD","color":"#9c27b0","price":5},
    {"id":"rps","name":"Jokenpo","desc":"Pedra papel tesoura","icon":"JP","color":"#2196f3","price":5},
    {"id":"reaction","name":"Reaction","desc":"Clique no verde","icon":"RT","color":"#00bcd4","price":10},
    {"id":"pong","name":"Pong","desc":"Raquete vs CPU","icon":"PG","color":"#e91e63","price":15},
    {"id":"flappy","name":"Flappy","desc":"Passaro voador","icon":"FL","color":"#4caf50","price":15},
    {"id":"math","name":"Math Quiz","desc":"Contas rapidas","icon":"MQ","color":"#ff9800","price":15},
    {"id":"scramble","name":"Scramble","desc":"Palavras embaralhadas","icon":"SC","color":"#8bc34a","price":20},
    {"id":"memory","name":"Memory","desc":"Ache os pares","icon":"MM","color":"#9c27b0","price":20},
    {"id":"hangman","name":"Hangman","desc":"Adivinhe a palavra","icon":"HG","color":"#e91e63","price":20},
    {"id":"whack","name":"Whack-a-Mole","desc":"Bata nas toupeiras","icon":"WM","color":"#795548","price":20},
    {"id":"simon","name":"Simon","desc":"Sequencia de cores","icon":"SM","color":"#ff5722","price":25},
    {"id":"tictac","name":"Tic Tac Toe","desc":"Vs CPU","icon":"TT","color":"#607d8b","price":25},
    {"id":"2048","name":"2048","desc":"Junte numeros","icon":"2K","color":"#ff9800","price":30},
    {"id":"stack","name":"Stack","desc":"Empilhe blocos","icon":"ST","color":"#ff5722","price":30},
    {"id":"dino","name":"Dino Run","desc":"Desvie dos cactos","icon":"DR","color":"#607d8b","price":30},
    {"id":"breakout","name":"Breakout","desc":"Quebre blocos","icon":"BK","color":"#009688","price":40},
    {"id":"asteroids","name":"Asteroids","desc":"Destrua asteroides","icon":"AS","color":"#455a64","price":40},
    {"id":"maze","name":"Maze","desc":"Labirinto","icon":"MZ","color":"#4caf50","price":40},
    {"id":"invaders","name":"Invaders","desc":"Espaciais invasores","icon":"IN","color":"#673ab7","price":50},
    {"id":"connect4","name":"Connect 4","desc":"4 em linha vs CPU","icon":"C4","color":"#2196f3","price":50},
    {"id":"tetris","name":"Tetris","desc":"Encaixe as pecas","icon":"TS","color":"#3f51b5","price":60},
    {"id":"minesweeper","name":"Minesweeper","desc":"Campo minado","icon":"MS","color":"#9e9e9e","price":60},
]

# 25 JOGOS em CD (todos s�o jogos, control�veis por teclado)
CD_GAMES = [
    ("cd_guess", "Guess Number", "Adivinhe 1-100", "GN", "#4caf50"),
    ("cd_quiz", "Quiz Game", "Perguntas e respostas", "QZ", "#9c27b0"),
    ("cd_hangman2", "Hangman 2", "Outro hangman", "H2", "#e91e63"),
    ("cd_typing", "Typing Race", "Digite rapido", "TY", "#2196f3"),
    ("cd_math2", "Math 2", "Contas faceis", "M2", "#ff9800"),
    ("cd_words", "Word Scramble", "Embaralhe palavras", "WS", "#8bc34a"),
    ("cd_memory2", "Memory 2", "Mais pares", "M3", "#9c27b0"),
    ("cd_react2", "Reaction 2", "Clique no tempo", "R2", "#00bcd4"),
    ("cd_pong2", "Pong 2", "Raquete dupla", "P2", "#e91e63"),
    ("cd_dice2", "Dice Battle", "Batalha de dados", "DB", "#ffc107"),
    ("cd_coin2", "Coin War", "Moeda vs CPU", "CW", "#ff9800"),
    ("cd_tictac2", "Tic Tac Toe 2", "Com mais IA", "T2", "#607d8b"),
    ("cd_2048b", "2048 Small", "2048 simplificado", "24", "#ff9800"),
    ("cd_snake2", "Snake 2", "Cobrinha com velocidade", "S2", "#4caf50"),
    ("cd_flappy2", "Flappy 2", "Passaro com obstaculos", "F2", "#4caf50"),
    ("cd_dino2", "Dino 2", "Corrida longa", "D2", "#607d8b"),
    ("cd_brick", "Brick Breaker", "Quebre os tijolos", "BB", "#009688"),
    ("cd_pong3", "Pong 3", "Modo dificil", "P3", "#e91e63"),
    ("cd_guess2", "Number Guess 2", "1-1000", "NG", "#4caf50"),
    ("cd_quiz2", "Quiz 2", "Perguntas 2", "Q2", "#9c27b0"),
    ("cd_count", "Count Game", "Contagem rapida", "CG", "#ff5722"),
    ("cd_sequence", "Sequence", "Repita a sequencia", "SQ", "#673ab7"),
    ("cd_aim", "Aim Trainer", "Mire e atire", "AT", "#f44336"),
    ("cd_boss", "Boss Fight", "Derrote o boss", "BF", "#c51111"),
    ("cd_final", "Final Challenge", "O desafio final", "FC", "#ffc107"),
]

def create_cd_games():
    for gid, name, desc, icon, color in CD_GAMES:
        path = os.path.join(CDS_DIR, gid + ".py")
        if os.path.exists(path):
            continue
        try:
            if gid == "cd_guess":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="GUESS 1-100", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 20, "bold")).pack(pady=20)
num = [random.randint(1, 100)]
tries = [0]
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 18), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
fb = tk.Label(frame, text="Digite um numero e ENTER", bg="#0a0a0f", fg="#ffc107", font=("Segoe UI", 14, "bold"))
fb.pack(pady=20)
def check(ev=None):
    try:
        g = int(e.get()); tries[0] += 1; e.delete(0, "end")
        if g < num[0]: fb.config(text="MAIOR! Tentativa %d" % tries[0], fg="#ffc107")
        elif g > num[0]: fb.config(text="MENOR! Tentativa %d" % tries[0], fg="#ffc107")
        else:
            fb.config(text="ACERTOU em %d tentativas! ENTER para novo" % tries[0], fg="#4caf50")
            num[0] = random.randint(1, 100); tries[0] = 0
    except: pass
e.bind("<Return>", check)
tk.Label(frame, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack()
'''
            elif gid == "cd_quiz":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
qs = [("2+2?", ["3","4","5"], 1, ["1","2","3"]), ("Cor do ceu?", ["Azul","Verde","Roxo"], 0, ["1","2","3"]), ("Capital do Brasil?", ["SP","RJ","Brasilia"], 2, ["1","2","3"])]
idx = [0]; score = [0]
q = tk.Label(frame, text="", bg="#0a0a0f", fg="#9c27b0", font=("Segoe UI", 16, "bold"))
q.pack(pady=20)
fb = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 12))
fb.pack(pady=10)
def show():
    if idx[0] >= len(qs):
        q.config(text="FIM! Score: %d/%d" % (score[0], len(qs))); fb.config(text="ENTER para jogar de novo")
        return
    qq, opts, _, _ = qs[idx[0]]
    q.config(text=qq)
    fb.config(text="\\n".join(["%d) %s" % (i+1, o) for i, o in enumerate(opts)]))
def key(ev):
    if ev.keysym == "Escape": return
    if idx[0] >= len(qs) and ev.keysym == "Return":
        idx[0] = 0; score[0] = 0; show(); return
    try:
        a = int(ev.char)
        if 1 <= a <= len(qs[idx[0]][1]):
            if a-1 == qs[idx[0]][2]: score[0] += 1
            idx[0] += 1; show()
    except: pass
frame.bind("<KeyPress>", key)
frame.focus_set()
show()
tk.Label(frame, text="Digite 1, 2 ou 3 | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            elif gid == "cd_hangman2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
words = ["PYTHON", "JOGO", "MOUSE", "TECLADO", "CODIGO", "JANELA", "ARQUIVO", "MUSICA", "ESTRELA", "MONTANHA"]
S = {"w": random.choice(words), "g": set(), "e": 0}
lbl = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 28, "bold"))
lbl.pack(pady=20)
st = tk.Label(frame, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 12))
st.pack()
def upd():
    d = " ".join([c if c in S["g"] else "_" for c in S["w"]])
    lbl.config(text=d)
    st.config(text="Erros: %d/6  Letras: %s" % (S["e"], " ".join(sorted(S["g"]))))
    if "_" not in d: lbl.config(text="VITORIA! " + S["w"], fg="#4caf50")
    elif S["e"] >= 6: lbl.config(text="PERDEU! " + S["w"], fg="#f44336")
def key(ev):
    if ev.keysym == "Escape": return
    k = ev.keysym.upper()
    if len(k) == 1 and k.isalpha() and k not in S["g"]:
        S["g"].add(k)
        if k not in S["w"]: S["e"] += 1
        upd()
frame.bind("<KeyPress>", key)
frame.focus_set(); upd()
tk.Label(frame, text="Digite letras | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            elif gid == "cd_typing":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
words = ["python", "jogo", "programa", "teclado", "mouse", "tela", "codigo"]
target = [random.choice(words)]; score = [0]
lbl = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 32, "bold"))
lbl.pack(pady=20)
lbl.config(text=target[0])
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 16), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
st = tk.Label(frame, text="Acertos: 0", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 12, "bold"))
st.pack()
def check(ev=None):
    if e.get().strip() == target[0]:
        score[0] += 1; target[0] = random.choice(words)
        lbl.config(text=target[0]); e.delete(0, "end")
        st.config(text="Acertos: %d" % score[0])
e.bind("<Return>", check)
tk.Label(frame, text="Digite a palavra + ENTER | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            elif gid == "cd_math2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"a": random.randint(1,10), "b": random.randint(1,10), "score": 0}
q = tk.Label(frame, text="", bg="#0a0a0f", fg="#ff9800", font=("Segoe UI", 40, "bold"))
q.pack(pady=30)
def newq():
    S["a"] = random.randint(1,10); S["b"] = random.randint(1,10)
    q.config(text="%d + %d = ?" % (S["a"], S["b"]))
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 20), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
st = tk.Label(frame, text="Score: 0", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 12, "bold"))
st.pack()
def check(ev=None):
    try:
        if int(e.get()) == S["a"]+S["b"]: S["score"] += 1; st.config(text="Score: %d" % S["score"])
        e.delete(0, "end"); newq()
    except: e.delete(0, "end")
e.bind("<Return>", check)
newq()
tk.Label(frame, text="Resposta + ENTER | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            elif gid == "cd_words":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
words = ["PYTHON","JOGO","MOUSE","TECLADO","CODIGO","MUSICA","ESTRELA"]
S = {"w": "", "score": 0}
def neww():
    w = random.choice(words)
    S["w"] = w
    sc = "".join(random.sample(w, len(w)))
    while sc == w: sc = "".join(random.sample(w, len(w)))
    q.config(text=sc)
q = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 30, "bold"))
q.pack(pady=20)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 16), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
st = tk.Label(frame, text="Score: 0", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 12, "bold"))
st.pack()
def check(ev=None):
    if e.get().upper().strip() == S["w"]:
        S["score"] += 1; st.config(text="Score: %d" % S["score"]); neww()
    e.delete(0, "end")
e.bind("<Return>", check)
neww()
tk.Label(frame, text="Digite a palavra + ENTER | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            elif gid == "cd_memory2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
syms = ["A","B","C","D"] * 2
random.shuffle(syms)
S = {"rev": [], "mat": set(), "btns": []}
st = tk.Label(frame, text="Ache os pares!", bg="#0a0a0f", fg="white", font=("Segoe UI", 14, "bold"))
st.pack(pady=10)
g = tk.Frame(frame, bg="#0a0a0f"); g.pack()
def unres():
    for i in S["rev"]: S["btns"][i].config(text="?", bg="#1e1e2a")
    S["rev"] = []
def flip(i):
    if i in S["mat"] or i in S["rev"]: return
    S["rev"].append(i); S["btns"][i].config(text=syms[i], bg="#9c27b0")
    if len(S["rev"]) == 2:
        a, b = S["rev"][0], S["rev"][1]
        if syms[a] == syms[b]:
            S["mat"].add(a); S["mat"].add(b); S["rev"] = []
            st.config(text="Par! %d/4" % (len(S["mat"])//2))
            if len(S["mat"]) == 8: st.config(text="VITORIA!")
        else: frame.after(600, unres)
for i in range(8):
    b = tk.Button(g, text="?", bg="#1e1e2a", fg="white", font=("Segoe UI", 20, "bold"),
                  width=4, height=2, relief="flat", command=lambda i=i: flip(i))
    b.grid(row=i//4, column=i%4, padx=3, pady=3)
    S["btns"].append(b)
tk.Label(frame, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            elif gid == "cd_react2":
                code = '''import tkinter as tk, time, random
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"st": "wait", "start": 0, "best": 9999}
lbl = tk.Label(frame, text="Aguarde o verde...", bg="#0a0a0f", fg="white", font=("Segoe UI", 24, "bold"))
lbl.pack(expand=True)
def reset():
    lbl.config(text="Aguarde o verde...", fg="white"); S["st"] = "wait"
    def ready():
        if S["st"] == "wait":
            lbl.config(text="ENTER AGORA!", fg="#4caf50"); S["st"] = "ready"; S["start"] = time.time()
    frame.after(random.randint(1500, 4000), ready)
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return":
        if S["st"] == "wait": lbl.config(text="CEDO! ENTER para tentar de novo", fg="#f44336"); S["st"] = "fail"
        elif S["st"] == "ready":
            t = (time.time() - S["start"]) * 1000; S["best"] = min(S["best"], int(t))
            lbl.config(text="%.0f ms! Best: %d  ENTER para novo" % (t, S["best"]), fg="#00d4ff"); S["st"] = "fail"
        else: reset()
frame.bind("<KeyPress>", key)
frame.focus_set(); reset()
tk.Label(frame, text="ENTER quando verde | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            elif gid == "cd_pong2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"bx": W//2, "by": H//2, "vx": 5, "vy": 4, "py": H//2, "ay": H//2, "ps": 0, "as_": 0}
def draw():
    cv.delete("all")
    cv.create_line(W//2, 0, W//2, H, fill="#333", dash=(10,10))
    cv.create_rectangle(20, S["py"]-50, 30, S["py"]+50, fill="#00d4ff", outline="")
    cv.create_rectangle(W-30, S["ay"]-50, W-20, S["ay"]+50, fill="#ff3355", outline="")
    cv.create_oval(S["bx"]-10, S["by"]-10, S["bx"]+10, S["by"]+10, fill="white", outline="")
    cv.create_text(W//2, 30, text="%d - %d" % (S["ps"], S["as_"]), fill="white", font=("Consolas", 24, "bold"))
    cv.create_text(W//2, H-30, text="Setas/W-S | ESC", fill="#7a7a8a", font=("Segoe UI", 10))
def step():
    S["bx"] += S["vx"]; S["by"] += S["vy"]
    if S["by"] < 15 or S["by"] > H-15: S["vy"] = -S["vy"]
    if S["bx"] < 30 and S["py"]-50 < S["by"] < S["py"]+50: S["vx"] = abs(S["vx"])
    if S["bx"] > W-30 and S["ay"]-50 < S["by"] < S["ay"]+50: S["vx"] = -abs(S["vx"])
    if S["bx"] < 0: S["as_"] += 1; S["bx"]=W//2; S["by"]=H//2
    if S["bx"] > W: S["ps"] += 1; S["bx"]=W//2; S["by"]=H//2
    if S["by"] > S["ay"]+20 and S["ay"] < H-60: S["ay"] += 5
    elif S["by"] < S["ay"]-20 and S["ay"] > 60: S["ay"] -= 5
    draw()
    try: frame.after(16, step)
    except: pass
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("Up","w") and S["py"] > 60: S["py"] -= 30
    elif ev.keysym in ("Down","s") and S["py"] < H-60: S["py"] += 30
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force(); step()
'''
            elif gid == "cd_dice2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
l1 = tk.Label(frame, text="?", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 60, "bold"))
l1.pack()
l2 = tk.Label(frame, text="?", bg="#0a0a0f", fg="#e91e63", font=("Segoe UI", 60, "bold"))
l2.pack()
st = tk.Label(frame, text="Voce 0 - 0 CPU", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 14))
st.pack()
S = {"w": 0, "l": 0}
def roll():
    a = random.randint(1,6); b = random.randint(1,6)
    l1.config(text=str(a)); l2.config(text=str(b))
    if a > b: S["w"] += 1
    elif b > a: S["l"] += 1
    st.config(text="Voce %d - %d CPU" % (S["w"], S["l"]))
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("Return","space"): roll()
frame.bind("<KeyPress>", key)
frame.focus_set()
tk.Label(frame, text="ENTER para rolar | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=20)
'''
            elif gid == "cd_coin2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
l = tk.Label(frame, text="?", bg="#0a0a0f", fg="#ffc107", font=("Segoe UI", 80, "bold"))
l.pack(pady=30)
st = tk.Label(frame, text="Voce 0 - 0 CPU", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 14))
st.pack()
S = {"w": 0, "l": 0}
def flip():
    you = random.choice(["Cara","Coroa"]); cpu = random.choice(["Cara","Coroa"])
    l.config(text=you)
    if you == cpu: pass
    elif (you=="Cara" and cpu=="Coroa") or (you=="Coroa" and cpu=="Cara"): S["w"] += 1
    else: S["l"] += 1
    st.config(text="Voce %d - %d CPU" % (S["w"], S["l"]))
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("Return","space"): flip()
frame.bind("<KeyPress>", key)
frame.focus_set()
tk.Label(frame, text="ENTER para jogar | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=20)
'''
            elif gid == "cd_tictac2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"b": [""]*9, "cur": 0, "over": False}
lbl = tk.Label(frame, text="Sua vez (X)", bg="#0a0a0f", fg="white", font=("Segoe UI", 14, "bold"))
lbl.pack(pady=10)
g = tk.Frame(frame, bg="#0a0a0f"); g.pack()
btns = []
def check():
    wins = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
    for a,b,c in wins:
        if S["b"][a] and S["b"][a]==S["b"][b]==S["b"][c]: return S["b"][a]
    return "Empate" if "" not in S["b"] else None
def click(i):
    if S["over"] or S["b"][i]: return
    S["b"][i] = "X"; btns[i].config(text="X", fg="#00d4ff")
    w = check()
    if w: lbl.config(text="Voce venceu!" if w=="X" else "Empate"); S["over"] = True; return
    for j in range(9):
        if S["b"][j] == "": S["b"][j] = "O"; btns[j].config(text="O", fg="#e91e63"); break
    w = check()
    if w: lbl.config(text="CPU venceu!" if w=="O" else "Empate"); S["over"] = True
for i in range(9):
    b = tk.Button(g, text="", bg="#1e1e2a", fg="white", font=("Segoe UI", 22, "bold"),
                  width=4, height=2, relief="flat", command=lambda i=i: click(i))
    b.grid(row=i//3, column=i%3, padx=3, pady=3)
    btns.append(b)
tk.Label(frame, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            elif gid == "cd_2048b":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"g": [[0]*4 for _ in range(4)], "score": 0}
def add():
    em = [(r,c) for r in range(4) for c in range(4) if S["g"][r][c]==0]
    if em:
        r,c = random.choice(em); S["g"][r][c] = 2 if random.random()<0.9 else 4
colors = {2:"#eee4da",4:"#ede0c8",8:"#f2b179",16:"#f59563",32:"#f67c5f"}
cv = tk.Canvas(frame, bg="#1a1a24", highlightthickness=0, width=440, height=440)
cv.pack(pady=10)
lbl = tk.Label(frame, text="Score: 0", bg="#0a0a0f", fg="#ffeb3b", font=("Consolas", 14, "bold"))
lbl.pack()
def draw():
    cv.delete("all")
    cs = 105; pad = 10
    for r in range(4):
        for c in range(4):
            x = c*(cs+pad)+pad; y = r*(cs+pad)+pad
            v = S["g"][r][c]
            if v == 0: cv.create_rectangle(x,y,x+cs,y+cs, fill="#2a2a3a", outline="")
            else:
                cv.create_rectangle(x,y,x+cs,y+cs, fill=colors.get(v,"#3c3a32"), outline="")
                cv.create_text(x+cs//2, y+cs//2, text=str(v), fill="white", font=("Segoe UI", 24, "bold"))
    lbl.config(text="Score: %d" % S["score"])
def move(d):
    mv = False
    if d == "left":
        for r in range(4):
            row = [x for x in S["g"][r] if x]; new = []; i = 0
            while i < len(row):
                if i+1 < len(row) and row[i]==row[i+1]: new.append(row[i]*2); S["score"] += row[i]*2; i += 2
                else: new.append(row[i]); i += 1
            new += [0]*(4-len(new))
            if new != S["g"][r]: mv = True; S["g"][r] = new
    elif d == "right":
        for r in range(4):
            row = [x for x in S["g"][r] if x]; new = []; i = len(row)-1
            while i >= 0:
                if i-1 >= 0 and row[i]==row[i-1]: new.insert(0, row[i]*2); S["score"] += row[i]*2; i -= 2
                else: new.insert(0, row[i]); i -= 1
            new = [0]*(4-len(new)) + new
            if new != S["g"][r]: mv = True; S["g"][r] = new
    elif d == "up":
        for c in range(4):
            col = [S["g"][r][c] for r in range(4) if S["g"][r][c]]; new = []; i = 0
            while i < len(col):
                if i+1 < len(col) and col[i]==col[i+1]: new.append(col[i]*2); S["score"] += col[i]*2; i += 2
                else: new.append(col[i]); i += 1
            new += [0]*(4-len(new))
            for r in range(4):
                if S["g"][r][c] != new[r]: mv = True
                S["g"][r][c] = new[r]
    elif d == "down":
        for c in range(4):
            col = [S["g"][r][c] for r in range(4) if S["g"][r][c]]; new = []; i = len(col)-1
            while i >= 0:
                if i-1 >= 0 and col[i]==col[i-1]: new.insert(0, col[i]*2); S["score"] += col[i]*2; i -= 2
                else: new.insert(0, col[i]); i -= 1
            new = [0]*(4-len(new)) + new
            for r in range(4):
                if S["g"][r][c] != new[r]: mv = True
                S["g"][r][c] = new[r]
    if mv: add(); draw()
def key(ev):
    if ev.keysym == "Escape": return
    d = ev.keysym.lower()
    if d in ("up","down","left","right"): move(d)
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force()
add(); add(); draw()
'''
            elif gid == "cd_snake2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0, width=440, height=440)
cv.pack(pady=10)
S = {"s": [(10,10)], "d": (1,0), "f": (5,5), "sc": 0, "alive": True, "sp": 120}
def draw():
    cv.delete("all")
    for x in range(0, 441, 22): cv.create_line(x, 0, x, 440, fill="#1a1a24")
    for y in range(0, 441, 22): cv.create_line(0, y, 440, y, fill="#1a1a24")
    for i, (x, y) in enumerate(S["s"]):
        c = "#81c784" if i == 0 else "#4caf50"
        cv.create_rectangle(x*22+1, y*22+1, (x+1)*22-1, (y+1)*22-1, fill=c, outline="")
    fx, fy = S["f"]
    cv.create_oval(fx*22+3, fy*22+3, (fx+1)*22-3, (fy+1)*22-3, fill="#ff3355", outline="")
    cv.create_text(10, 460, anchor="w", text="Score: %d" % S["sc"], fill="white", font=("Consolas", 12, "bold"))
    if not S["alive"]: cv.create_text(220, 220, text="GAME OVER", fill="#ff3355", font=("Segoe UI", 24, "bold"))
def step():
    if not S["alive"]: return
    hx, hy = S["s"][0]; dx, dy = S["d"]; nx, ny = hx+dx, hy+dy
    if nx < 0 or nx >= 20 or ny < 0 or ny >= 20 or (nx, ny) in S["s"]:
        S["alive"] = False; draw(); return
    S["s"].insert(0, (nx, ny))
    if (nx, ny) == S["f"]:
        S["sc"] += 1
        while True:
            nf = (random.randint(0,19), random.randint(0,19))
            if nf not in S["s"]: break
        S["f"] = nf
        if S["sc"] % 5 == 0 and S["sp"] > 60: S["sp"] -= 5
    else: S["s"].pop()
    draw()
    frame.after(S["sp"], step)
def key(ev):
    if ev.keysym == "Escape": return
    d = S["d"]
    if ev.keysym == "Up" and d != (0,1): S["d"] = (0,-1)
    elif ev.keysym == "Down" and d != (0,-1): S["d"] = (0,1)
    elif ev.keysym == "Left" and d != (1,0): S["d"] = (-1,0)
    elif ev.keysym == "Right" and d != (-1,0): S["d"] = (1,0)
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force()
draw(); step()
'''
            elif gid == "cd_flappy2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#87ceeb", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"y": H//2, "vy": 0, "pipes": [], "sc": 0, "alive": True, "t": 0}
PW, GAP = 60, 150
def draw():
    cv.delete("all")
    cv.create_rectangle(0, 0, W, H, fill="#87ceeb", outline="")
    for p in S["pipes"]:
        cv.create_rectangle(p["x"], 0, p["x"]+PW, p["top"], fill="#4caf50", outline="")
        cv.create_rectangle(p["x"], p["top"]+GAP, p["x"]+PW, H, fill="#4caf50", outline="")
    cv.create_oval(60, S["y"]-15, 90, S["y"]+15, fill="#ffc107", outline="")
    cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["sc"], fill="white", font=("Consolas", 14, "bold"))
    if not S["alive"]: cv.create_text(W//2, H//2, text="GAME OVER - ENTER", fill="white", font=("Segoe UI", 24, "bold"))
def step():
    if not S["alive"]: return
    S["vy"] += 0.5; S["y"] += S["vy"]; S["t"] += 1
    if S["t"] % 90 == 0: S["pipes"].append({"x": W, "top": random.randint(80, H-80-GAP), "p": False})
    for p in S["pipes"][:]:
        p["x"] -= 4
        if p["x"] + PW < 0: S["pipes"].remove(p); continue
        if not p["p"] and p["x"] + PW < 60: p["p"] = True; S["sc"] += 1
        if 45 < p["x"] < 105:
            if S["y"]-15 < p["top"] or S["y"]+15 > p["top"]+GAP: S["alive"] = False
    if S["y"] > H or S["y"] < 0: S["alive"] = False
    draw()
    frame.after(20, step)
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("space","Up","Return"):
        if S["alive"]: S["vy"] = -8
        else: S.update({"y": H//2, "vy": 0, "pipes": [], "sc": 0, "alive": True, "t": 0}); step()
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force(); step()
'''
            elif gid == "cd_dino2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#f7f7f7", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"y": H-100, "vy": 0, "obs": [], "sc": 0, "alive": True, "t": 0}
def draw():
    cv.delete("all")
    cv.create_rectangle(0, 0, W, H, fill="#f7f7f7", outline="")
    cv.create_rectangle(0, H-60, W, H, fill="#c5c5c5", outline="")
    for o in S["obs"]: cv.create_rectangle(o["x"], H-100, o["x"]+30, H-60, fill="#333", outline="")
    cv.create_rectangle(60, S["y"], 100, S["y"]+40, fill="#333", outline="")
    cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["sc"], fill="#333", font=("Consolas", 14, "bold"))
    if not S["alive"]: cv.create_text(W//2, H//2, text="GAME OVER", fill="#ff3355", font=("Segoe UI", 24, "bold"))
def step():
    if not S["alive"]: return
    S["t"] += 1; S["y"] += S["vy"]; S["vy"] += 0.5
    if S["y"] > H-100: S["y"] = H-100; S["vy"] = 0
    if S["t"] % 80 == 0: S["obs"].append({"x": W})
    for o in S["obs"][:]:
        o["x"] -= 6
        if o["x"]+30 < 0: S["obs"].remove(o); S["sc"] += 1; continue
        if o["x"] < 100 and o["x"]+30 > 60 and S["y"]+40 > H-100: S["alive"] = False
    draw()
    frame.after(30, step)
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("space","Up","Return"):
        if S["alive"] and S["y"] >= H-100: S["vy"] = -14
        elif not S["alive"]: S.update({"y": H-100, "vy": 0, "obs": [], "sc": 0, "alive": True, "t": 0}); step()
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force(); step()
'''
            elif gid == "cd_brick":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"bx": W//2, "by": H-100, "vx": 5, "vy": -5, "px": W//2, "blocks": [], "sc": 0, "alive": True}
for r in range(5):
    for c in range(10):
        S["blocks"].append({"x": c*75+30, "y": r*30+80, "w": 70, "h": 25,
                             "color": ["#f44336","#ff9800","#ffc107","#4caf50","#2196f3"][r]})
def draw():
    cv.delete("all")
    cv.create_rectangle(0,0,W,H,fill="#0a0a0f",outline="")
    for b in S["blocks"]: cv.create_rectangle(b["x"],b["y"],b["x"]+b["w"],b["y"]+b["h"], fill=b["color"], outline="")
    cv.create_rectangle(S["px"]-60, H-40, S["px"]+60, H-25, fill="#00d4ff", outline="")
    cv.create_oval(S["bx"]-8, S["by"]-8, S["bx"]+8, S["by"]+8, fill="white", outline="")
    cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["sc"], fill="#fff", font=("Consolas", 14, "bold"))
    if not S["alive"]: cv.create_text(W//2, H//2, text="GAME OVER", fill="#ff3355", font=("Segoe UI", 24, "bold"))
def step():
    if not S["alive"]: return
    S["bx"] += S["vx"]; S["by"] += S["vy"]
    if S["bx"] < 10 or S["bx"] > W-10: S["vx"] = -S["vx"]
    if S["by"] < 10: S["vy"] = -S["vy"]
    if S["by"] > H-40 and S["px"]-60 < S["bx"] < S["px"]+60: S["vy"] = -abs(S["vy"])
    if S["by"] > H: S["alive"] = False
    for b in S["blocks"][:]:
        if b["x"] < S["bx"] < b["x"]+b["w"] and b["y"] < S["by"] < b["y"]+b["h"]:
            S["blocks"].remove(b); S["sc"] += 10; S["vy"] = -S["vy"]; break
    if not S["blocks"]: S["alive"] = False
    draw()
    frame.after(16, step)
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Left": S["px"] = max(60, S["px"]-40)
    elif ev.keysym == "Right": S["px"] = min(W-60, S["px"]+40)
    elif not S["alive"] and ev.keysym == "Return":
        S.update({"bx": W//2, "by": H-100, "vx": 5, "vy": -5, "sc": 0, "alive": True})
        S["blocks"] = []
        for r in range(5):
            for c in range(10):
                S["blocks"].append({"x": c*75+30, "y": r*30+80, "w": 70, "h": 25,
                                     "color": ["#f44336","#ff9800","#ffc107","#4caf50","#2196f3"][r]})
        step()
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force(); step()
'''
            elif gid == "cd_pong3":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"bx": W//2, "by": H//2, "vx": 8, "vy": 6, "py": H//2, "ay": H//2, "ps": 0, "as_": 0}
def draw():
    cv.delete("all")
    cv.create_line(W//2, 0, W//2, H, fill="#333", dash=(10,10))
    cv.create_rectangle(20, S["py"]-50, 30, S["py"]+50, fill="#00d4ff", outline="")
    cv.create_rectangle(W-30, S["ay"]-50, W-20, S["ay"]+50, fill="#ff3355", outline="")
    cv.create_oval(S["bx"]-10, S["by"]-10, S["bx"]+10, S["by"]+10, fill="white", outline="")
    cv.create_text(W//2, 30, text="%d - %d" % (S["ps"], S["as_"]), fill="white", font=("Consolas", 24, "bold"))
def step():
    S["bx"] += S["vx"]; S["by"] += S["vy"]
    if S["by"] < 15 or S["by"] > H-15: S["vy"] = -S["vy"]
    if S["bx"] < 30 and S["py"]-50 < S["by"] < S["py"]+50: S["vx"] = abs(S["vx"])
    if S["bx"] > W-30 and S["ay"]-50 < S["by"] < S["ay"]+50: S["vx"] = -abs(S["vx"])
    if S["bx"] < 0: S["as_"] += 1; S["bx"]=W//2; S["by"]=H//2
    if S["bx"] > W: S["ps"] += 1; S["bx"]=W//2; S["by"]=H//2
    if S["by"] > S["ay"]+20 and S["ay"] < H-60: S["ay"] += 7
    elif S["by"] < S["ay"]-20 and S["ay"] > 60: S["ay"] -= 7
    draw()
    frame.after(16, step)
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("Up","w") and S["py"] > 60: S["py"] -= 40
    elif ev.keysym in ("Down","s") and S["py"] < H-60: S["py"] += 40
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force(); step()
'''
            elif gid == "cd_guess2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
num = [random.randint(1, 1000)]; tries = [0]
tk.Label(frame, text="GUESS 1-1000", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 20, "bold")).pack(pady=20)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 18), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
fb = tk.Label(frame, text="Digite um numero", bg="#0a0a0f", fg="#ffc107", font=("Segoe UI", 14, "bold"))
fb.pack(pady=20)
def check(ev=None):
    try:
        g = int(e.get()); tries[0] += 1; e.delete(0, "end")
        if g < num[0]: fb.config(text="MAIOR! T%d" % tries[0])
        elif g > num[0]: fb.config(text="MENOR! T%d" % tries[0])
        else:
            fb.config(text="ACERTOU em %d! ENTER para novo" % tries[0], fg="#4caf50")
            num[0] = random.randint(1, 1000); tries[0] = 0
    except: pass
e.bind("<Return>", check)
tk.Label(frame, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack()
'''
            elif gid == "cd_quiz2":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
qs = [("5x3?", 15), ("10-4?", 6), ("7+8?", 15), ("20/2?", 10), ("2^3?", 8)]
idx = [0]; sc = [0]
q = tk.Label(frame, text="", bg="#0a0a0f", fg="#9c27b0", font=("Segoe UI", 40, "bold"))
q.pack(pady=30)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 20), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
st = tk.Label(frame, text="Score: 0", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 12))
st.pack()
def newq():
    if idx[0] >= len(qs):
        q.config(text="FIM! %d/%d" % (sc[0], len(qs))); return
    q.config(text=qs[idx[0]][0])
def check(ev=None):
    try:
        if int(e.get()) == qs[idx[0]][1]: sc[0] += 1; st.config(text="Score: %d" % sc[0])
        idx[0] += 1; e.delete(0, "end"); newq()
    except: e.delete(0, "end")
e.bind("<Return>", check)
newq()
tk.Label(frame, text="Resposta + ENTER | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack()
'''
            elif gid == "cd_count":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"n": random.randint(5, 15), "cur": 0}
lbl = tk.Label(frame, text="", bg="#0a0a0f", fg="#ff5722", font=("Segoe UI", 60, "bold"))
lbl.pack(pady=40)
st = tk.Label(frame, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 12))
st.pack()
def reset():
    S["n"] = random.randint(5, 15); S["cur"] = 0
    lbl.config(text=str(S["cur"])); st.config(text="Conte ate %d com ENTER" % S["n"])
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return":
        S["cur"] += 1; lbl.config(text=str(S["cur"]))
        if S["cur"] >= S["n"]: st.config(text="PARABENS! ENTER para novo"); reset()
frame.bind("<KeyPress>", key)
frame.focus_set(); reset()
tk.Label(frame, text="ENTER para contar | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            elif gid == "cd_sequence":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"seq": [], "input": ""}
lbl = tk.Label(frame, text="", bg="#0a0a0f", fg="#673ab7", font=("Consolas", 30, "bold"))
lbl.pack(pady=30)
st = tk.Label(frame, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 12))
st.pack()
def new():
    S["seq"] = [random.randint(1,9) for _ in range(4)]
    S["input"] = ""
    lbl.config(text="".join(map(str, S["seq"]))); st.config(text="Digite os numeros + ENTER")
def check(ev=None):
    if S["input"] == "".join(map(str, S["seq"])):
        st.config(text="ACERTOU!"); lbl.config(text=""); frame.after(800, new)
    else:
        st.config(text="ERROU! Era: " + "".join(map(str, S["seq"]))); frame.after(1500, new)
    S["input"] = ""
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return": check()
    elif ev.char.isdigit(): S["input"] += ev.char
frame.bind("<KeyPress>", key)
frame.focus_set(); new()
tk.Label(frame, text="Digite os numeros + ENTER | ESC", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            elif gid == "cd_aim":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"tx": W//2, "ty": H//2, "score": 0, "time": 30, "playing": True}
def draw():
    cv.delete("all")
    cv.create_rectangle(0,0,W,H,fill="#0a0a0f",outline="")
    if S["playing"]:
        cv.create_oval(S["tx"]-25, S["ty"]-25, S["tx"]+25, S["ty"]+25, outline="#f44336", width=3)
        cv.create_oval(S["tx"]-8, S["ty"]-8, S["tx"]+8, S["ty"]+8, fill="#f44336", outline="")
    cv.create_text(W-15, 20, anchor="e", text="Score: %d Time: %ds" % (S["score"], S["time"]), fill="#fff", font=("Consolas", 14, "bold"))
def tick():
    if not S["playing"]: return
    S["time"] -= 1
    if S["time"] <= 0: S["playing"] = False
    draw()
    frame.after(1000, tick)
def click(ev):
    if not S["playing"]: return
    if abs(ev.x - S["tx"]) < 25 and abs(ev.y - S["ty"]) < 25:
        S["score"] += 1; S["tx"] = random.randint(50, W-50); S["ty"] = random.randint(50, H-50); draw()
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return" and not S["playing"]:
        S.update({"time": 30, "playing": True, "score": 0}); draw()
cv.bind("<Button-1>", click)
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force()
draw(); tick()
'''
            elif gid == "cd_boss":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"hp": 100, "boss": 200, "alive": True, "log": []}
lbl = tk.Label(frame, text="BOSS FIGHT", bg="#0a0a0f", fg="#c51111", font=("Segoe UI", 20, "bold"))
lbl.pack(pady=10)
hp = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 14))
hp.pack(pady=5)
bhp = tk.Label(frame, text="", bg="#0a0a0f", fg="#f44336", font=("Segoe UI", 14))
bhp.pack(pady=5)
st = tk.Label(frame, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 11))
st.pack(pady=10)
def upd():
    hp.config(text="Seu HP: %d/100" % S["hp"])
    bhp.config(text="Boss HP: %d/200" % S["boss"])
    if S["boss"] <= 0: st.config(text="VITORIA! ENTER para jogar de novo", fg="#4caf50"); S["alive"] = False
    elif S["hp"] <= 0: st.config(text="DERROTA! ENTER para tentar de novo", fg="#f44336"); S["alive"] = False
def attack():
    if not S["alive"]: return
    dmg = random.randint(10, 30); S["boss"] -= dmg
    if S["boss"] > 0:
        boss_dmg = random.randint(5, 20); S["hp"] -= boss_dmg
        st.config(text="Voce: -%d | Boss: -%d" % (dmg, boss_dmg))
    upd()
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return":
        if S["alive"]: attack()
        else: S.update({"hp": 100, "boss": 200, "alive": True}); upd()
frame.bind("<KeyPress>", key)
frame.focus_set(); upd()
tk.Label(frame, text="ENTER para atacar | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack()
'''
            elif gid == "cd_final":
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"lvl": 1, "score": 0}
lbl = tk.Label(frame, text="", bg="#0a0a0f", fg="#ffc107", font=("Segoe UI", 30, "bold"))
lbl.pack(pady=30)
st = tk.Label(frame, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 12))
st.pack()
def newchallenge():
    if S["lvl"] > 5:
        lbl.config(text="VOCE VENCEU TUDO!"); st.config(text="Score final: %d | ENTER para reiniciar" % S["score"]); return
    n = random.randint(3, 10 + S["lvl"]*5)
    target = S["lvl"] * 10
    lbl.config(text="Nivel %d: aperte ENTER %d vezes" % (S["lvl"], target)); st.config(text="")
    S["target"] = target; S["cur"] = 0
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return":
        if S["lvl"] > 5:
            S.update({"lvl": 1, "score": 0}); newchallenge(); return
        S["cur"] += 1
        if S["cur"] >= S["target"]:
            S["score"] += S["target"]; S["lvl"] += 1; newchallenge()
frame.bind("<KeyPress>", key)
frame.focus_set(); newchallenge()
tk.Label(frame, text="ENTER rapido | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
'''
            else:
                code = '''import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="JOGO CD", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 24, "bold")).pack(pady=60)
tk.Label(frame, text="Funcionando!", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 16)).pack()
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=30)
'''
            f = open(path, "w")
            f.write(code)
            f.close()
        except: pass

def ensure():
    for d in [DATA, CDS_DIR]:
        if not os.path.exists(d):
            try: os.makedirs(d)
            except: pass
    create_cd_games()

def lj(p, d):
    try:
        if os.path.exists(p):
            f = open(p, "r"); r = json.load(f); f.close(); return r
    except: pass
    return d

def sj(p, d):
    try:
        f = open(p, "w"); json.dump(d, f); f.close()
    except: pass

def cfg():
    return lj(CFG_F, {"som": True, "fullscreen": True})

def scfg(c): sj(CFG_F, c)

def users():
    u = lj(USERS_F, None)
    if u is None:
        u = []; sj(USERS_F, u)
    else:
        new_u = [x for x in u if x.get("name") != "Player 1"]
        if len(new_u) != len(u):
            u = new_u; sj(USERS_F, u)
    return u

def save_users(u): sj(USERS_F, u)

def snd(kind="click"):
    if not HAS_SOUND or not cfg().get("som", True): return
    try:
        if kind == "boot":
            winsound.Beep(440, 80); time.sleep(0.05)
            winsound.Beep(660, 80); time.sleep(0.05)
            winsound.Beep(880, 120); time.sleep(0.08)
            winsound.Beep(1320, 180)
        elif kind == "click": winsound.Beep(1500, 20)
        elif kind == "nav": winsound.Beep(900, 25)
        elif kind == "select":
            winsound.Beep(1000, 40); time.sleep(0.02)
            winsound.Beep(1500, 60)
        elif kind == "back":
            winsound.Beep(900, 30); time.sleep(0.02)
            winsound.Beep(600, 50)
        elif kind == "error":
            winsound.Beep(400, 80); time.sleep(0.03)
            winsound.Beep(300, 100)
        elif kind == "login":
            winsound.Beep(660, 60); time.sleep(0.04)
            winsound.Beep(880, 60); time.sleep(0.04)
            winsound.Beep(1320, 150)
        elif kind == "buy":
            winsound.Beep(880, 40); time.sleep(0.03)
            winsound.Beep(1100, 40); time.sleep(0.03)
            winsound.Beep(1400, 100)
        elif kind == "coin":
            winsound.Beep(1800, 30); time.sleep(0.02)
            winsound.Beep(2200, 50)
        elif kind == "shoot": winsound.Beep(1800, 15)
        elif kind == "hit": winsound.Beep(800, 25)
        elif kind == "die":
            winsound.Beep(400, 100); time.sleep(0.05)
            winsound.Beep(300, 150)
    except: pass

# ============================================================
class Station:
    def __init__(self):
        ensure()
        c = cfg()
        self.root = tk.Tk()
        self.root.title("minstcaveStation v" + V)
        self.root.configure(bg=BG)
        self.root.geometry("1000x650+40+40")
        self.bind_main()

        try:
            if c.get("fullscreen", True):
                self.root.attributes("-fullscreen", True)
        except: pass

        self.canvas = tk.Canvas(self.root, bg=BG, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Button-1>", lambda e: self.canvas.focus_set())

        self.state = "boot"
        self.user = None
        self.tab = 0
        self.sel_user = 0
        self.sel_game = 0
        self.sel_cfg = 0
        self.sel_store = 0
        self.in_tab_bar = True
        self.game_open = False
        self.game_frame = None
        self._store_items = []
        self._config_items = []

        self.root.after(100, self.boot_anim)

    def bind_main(self):
        try:
            self.root.bind("<F11>", lambda e: self.toggle_fs())
            self.root.bind("<Escape>", lambda e: self.esc())
            self.root.bind("<Left>", lambda e: self.safe_nav("left"))
            self.root.bind("<Right>", lambda e: self.safe_nav("right"))
            self.root.bind("<Up>", lambda e: self.safe_nav("up"))
            self.root.bind("<Down>", lambda e: self.safe_nav("down"))
            self.root.bind("<Return>", lambda e: self.safe_enter())
            self.root.bind("<space>", lambda e: self.safe_enter())
            self.root.bind("<BackSpace>", lambda e: self.safe_back())
        except: pass

    def unbind_main(self):
        for k in ["<F11>", "<Escape>", "<Left>", "<Right>", "<Up>", "<Down>",
                  "<Return>", "<space>", "<BackSpace>", "<Delete>"]:
            try: self.root.unbind(k)
            except: pass

    def safe_nav(self, d):
        try: self.nav(d)
        except Exception as e:
            try:
                sys.stderr.write("NAV: " + str(e) + "\n" + traceback.format_exc() + "\n"); sys.stderr.flush()
            except: pass
            self.root.focus_force()

    def safe_enter(self):
        try: self.enter()
        except Exception as e:
            try:
                sys.stderr.write("ENTER: " + str(e) + "\n" + traceback.format_exc() + "\n"); sys.stderr.flush()
            except: pass
            self.root.focus_force()

    def safe_back(self):
        try: self.back()
        except: pass

    def toggle_fs(self):
        try:
            cur = self.root.attributes("-fullscreen")
            self.root.attributes("-fullscreen", not cur)
            c = cfg(); c["fullscreen"] = not cur; scfg(c)
        except: pass

    def W(self):
        try: return self.canvas.winfo_width() or 1000
        except: return 1000
    def H(self):
        try: return self.canvas.winfo_height() or 650
        except: return 650

    def boot_anim(self):
        self.state = "boot"
        self.canvas.delete("all")
        snd("boot")
        w, h = self.W(), self.H()
        cx, cy = w//2, h//2 - 40

        self.canvas.create_rectangle(0, 0, w, h, fill="#000", outline="")
        for r in [180, 160, 140]:
            self.canvas.create_oval(cx-r, cy-r, cx+r, cy+r, outline=ACCENT, width=1)
        self.canvas.create_text(cx, cy-20, text="MINSTCAVE", fill=ACCENT2, font=("Segoe UI", 38, "bold"))
        self.canvas.create_text(cx, cy+30, text="STATION", fill=ACCENT, font=("Segoe UI", 24, "bold"))
        self.canvas.create_text(cx, cy+100, text="v" + V, fill=TXT_MUTED, font=("Consolas", 10))

        bar_y = h - 120; bar_w = 400; bar_x = (w - bar_w) // 2
        self.canvas.create_rectangle(bar_x, bar_y, bar_x+bar_w, bar_y+4, fill="#1a1a24", outline="")
        bar_fill = self.canvas.create_rectangle(bar_x, bar_y, bar_x, bar_y+4, fill=ACCENT, outline="")
        loading = self.canvas.create_text(w//2, bar_y+30, text="", fill=TXT_MUTED, font=("Consolas", 10))

        steps = 50
        def anim(i=0):
            try:
                if not self.canvas.winfo_exists(): return
                pct = i / float(steps)
                self.canvas.coords(bar_fill, bar_x, bar_y, bar_x+int(bar_w*pct), bar_y+4)
                if i < 12: msg = "Inicializando"
                elif i < 25: msg = "Verificando"
                elif i < 38: msg = "Carregando"
                else: msg = "Pronto"
                self.canvas.itemconfig(loading, text=msg + "." * ((i//6)%4))
                if i < steps: self.root.after(50, lambda: anim(i+1))
                else: self.root.after(300, self.login_screen)
            except: pass
        self.root.after(200, anim)

    def login_screen(self):
        self.state = "login"
        self.canvas.delete("all")
        w, h = self.W(), self.H()

        for i in range(0, h, 4):
            ratio = i / float(h)
            r = int(10 + (18-10)*ratio); g = r; b = int(15 + (26-15)*ratio)
            self.canvas.create_rectangle(0, i, w, i+4, fill="#%02x%02x%02x" % (r,g,b), outline="")

        self.canvas.create_text(w//2, 100, text="QUEM ESTA JOGANDO?", fill=TXT, font=("Segoe UI", 24, "bold"))
        self.canvas.create_text(w//2, 135, text="Selecione um perfil", fill=TXT_DIM, font=("Segoe UI", 11))

        all_u = users()
        items = [("user", u) for u in all_u] + [("new", None)]
        n = len(items)
        card_w = 180; card_h = 220; gap = 30
        total_w = n * card_w + (n-1) * gap
        start_x = (w - total_w) // 2
        cy = h // 2

        for i, (kind, data) in enumerate(items):
            x = start_x + i * (card_w + gap)
            y = cy - card_h // 2
            is_sel = (i == self.sel_user)

            if kind == "user":
                fill = "#202030" if is_sel else CARD
                outline = ACCENT if is_sel else BORDER
                width = 3 if is_sel else 1
                self.canvas.create_rectangle(x, y, x+card_w, y+card_h, fill=fill, outline=outline, width=width)
                ax = x + card_w // 2; ay = y + 75; r = 45
                self.canvas.create_oval(ax-r, ay-r, ax+r, ay+r, fill=data.get("color", ACCENT), outline="")
                self.canvas.create_text(ax, ay, text=data.get("icon", "P")[:2], fill="white", font=("Segoe UI", 32, "bold"))
                self.canvas.create_text(ax, y + 155, text=data.get("name", "Player"),
                                        fill=TXT if is_sel else TXT_DIM, font=("Segoe UI", 13, "bold"))
                if data.get("password"):
                    self.canvas.create_text(ax, y + 175, text="[protegido]", fill=TXT_MUTED, font=("Segoe UI", 8, "italic"))
                if is_sel:
                    self.canvas.create_text(ax, y + 195, text="> ENTRAR <", fill=ACCENT2, font=("Segoe UI", 9, "bold"))
            else:
                fill = "#202030" if is_sel else CARD
                outline = ACCENT2 if is_sel else BORDER
                width = 3 if is_sel else 1
                self.canvas.create_rectangle(x, y, x+card_w, y+card_h, fill=fill, outline=outline, width=width)
                ax = x + card_w // 2; ay = y + 75; r = 45
                self.canvas.create_oval(ax-r, ay-r, ax+r, ay+r, fill="", outline=TXT_MUTED, width=2, dash=(4,4))
                self.canvas.create_text(ax, ay, text="+", fill=TXT_MUTED if not is_sel else ACCENT2, font=("Segoe UI", 40, "bold"))
                self.canvas.create_text(ax, y + 155, text="Novo perfil",
                                        fill=TXT if is_sel else TXT_DIM, font=("Segoe UI", 13, "bold"))
                if is_sel:
                    self.canvas.create_text(ax, y + 195, text="> CRIAR <", fill=ACCENT2, font=("Segoe UI", 9, "bold"))

        self.canvas.create_text(w//2, h - 40,
                                text="SETAS: navegar | ENTER: selecionar | DEL: apagar | " +
                                     str(len(all_u)) + "/" + str(MAX_ACCOUNTS) + " contas",
                                fill=TXT_MUTED, font=("Segoe UI", 9))

        try: self.root.bind("<Delete>", lambda e: self.delete_user())
        except: pass

    def delete_user(self):
        if self.state != "login": return
        all_u = users()
        if not all_u or self.sel_user >= len(all_u): return
        name = all_u[self.sel_user].get("name", "?")
        if messagebox.askyesno("Apagar", "Apagar perfil '" + name + "'?"):
            all_u.pop(self.sel_user); save_users(all_u)
            self.sel_user = max(0, min(self.sel_user, len(all_u) - 1))
            snd("back"); self.root.focus_force(); self.login_screen()

    def main_screen(self):
        self.state = "main"; self.in_tab_bar = True; self.render_main()

    def render_main(self):
        self.canvas.delete("all")
        w, h = self.W(), self.H()

        for i in range(0, h, 4):
            ratio = i / float(h)
            r = int(10 + (18-10)*ratio); g = r; b = int(15 + (26-15)*ratio)
            self.canvas.create_rectangle(0, i, w, i+4, fill="#%02x%02x%02x" % (r,g,b), outline="")

        self.canvas.create_rectangle(0, 0, w, 65, fill="#050508", outline="")
        self.canvas.create_line(0, 65, w, 65, fill="#1a1a24", width=1)
        self.canvas.create_text(30, 32, anchor="w", text="MINSTCAVE", fill=ACCENT2, font=("Segoe UI", 12, "bold"))

        tab_start = 200; tab_w = 110
        for i, tab in enumerate(TABS):
            x = tab_start + i * (tab_w + 10)
            is_tab_sel = (i == self.tab)
            is_focused = (is_tab_sel and self.in_tab_bar)
            if is_focused:
                self.canvas.create_rectangle(x, 20, x+tab_w, 46, fill=ACCENT, outline="", width=0)
                color = "white"
            elif is_tab_sel:
                self.canvas.create_rectangle(x, 20, x+tab_w, 46, fill="", outline=ACCENT, width=2)
                color = ACCENT
            else:
                color = TXT_DIM
            self.canvas.create_text(x + tab_w//2, 33, text=tab, fill=color, font=("Segoe UI", 10, "bold"))

        pts = self.user.get("points", 0) if self.user else 0
        self.canvas.create_text(w-180, 32, anchor="e", text="* " + str(pts) + " pts", fill=GOLD, font=("Consolas", 12, "bold"))
        self.canvas.create_text(w-120, 32, anchor="e", text=datetime.datetime.now().strftime("%H:%M"), fill=TXT, font=("Consolas", 13, "bold"))
        ax = w - 50
        if self.user:
            self.canvas.create_oval(ax-20, 12, ax+20, 52, fill=self.user.get("color", ACCENT), outline="")
            self.canvas.create_text(ax, 32, text=self.user.get("icon", "P")[:2], fill="white", font=("Segoe UI", 13, "bold"))

        if self.tab == 0: self.render_home_content()
        elif self.tab == 1: self.render_games_content()
        elif self.tab == 2: self.render_loja_content()
        elif self.tab == 3: self.render_config_content()

        self.canvas.create_line(0, h-40, w, h-40, fill="#1a1a24", width=1)
        if self.in_tab_bar:
            hint = "SETAS ESQ/DIR: trocar aba | BAIXO: entrar | ENTER: confirmar | F11: tela cheia"
        else:
            hint = "SETAS: navegar | ENTER: selecionar | CIMA: voltar as abas | ESC: voltar"
        self.canvas.create_text(w//2, h-20, text=hint, fill=TXT_MUTED, font=("Segoe UI", 9))

    def render_home_content(self):
        if not self.user: return
        self.canvas.create_text(50, 100, anchor="w", text="Bem-vindo, " + self.user.get("name", "Player"),
                                fill=TXT, font=("Segoe UI", 22, "bold"))
        hh = datetime.datetime.now().hour
        period = "dia" if hh < 12 else ("tarde" if hh < 18 else "noite")
        self.canvas.create_text(50, 130, anchor="w", text="Bom " + period + "!", fill=TXT_DIM, font=("Segoe UI", 11))
        self.canvas.create_text(50, 160, anchor="w", text="Pontos: " + str(self.user.get("points", 0)),
                                fill=GOLD, font=("Segoe UI", 11, "bold"))
        self.render_carousel(200)

    def render_games_content(self):
        self.canvas.create_text(50, 100, anchor="w", text="MEUS JOGOS", fill=TXT, font=("Segoe UI", 20, "bold"))
        self.render_carousel(160)

    def render_loja_content(self):
        w, h = self.W(), self.H()
        self.canvas.create_text(50, 100, anchor="w", text="LOJA", fill=TXT, font=("Segoe UI", 20, "bold"))
        pts = self.user.get("points", 0) if self.user else 0
        self.canvas.create_text(50, 130, anchor="w", text="Seus pontos: " + str(pts), fill=GOLD, font=("Segoe UI", 11, "bold"))

        owned = self.user.get("owned_games", []) if self.user else []
        not_owned = [g for g in STORE_GAMES if g["id"] not in owned]
        self._store_items = not_owned

        if not not_owned:
            self.canvas.create_text(w//2, h//2 - 20, text="Voce tem todos os jogos!",
                                    fill=SUCCESS, font=("Segoe UI", 18, "bold"))
            self.canvas.create_text(w//2, h//2 + 20, text="Continue jogando para ganhar pontos",
                                    fill=TXT_DIM, font=("Segoe UI", 11))
            return

        visible = 4
        start_idx = max(0, self.sel_store - 1)
        if start_idx + visible > len(not_owned): start_idx = max(0, len(not_owned) - visible)
        items_to_show = not_owned[start_idx:start_idx+visible]

        card_w = 280; card_h = 110; gap = 12
        start_x = (w - card_w) // 2; start_y = 170

        for i, g in enumerate(items_to_show):
            real_idx = start_idx + i
            y = start_y + i * (card_h + gap)
            is_sel = (real_idx == self.sel_store) and (not self.in_tab_bar)
            fill = CARD_HOVER if is_sel else CARD
            outline = ACCENT if is_sel else BORDER
            width = 2 if is_sel else 1
            self.canvas.create_rectangle(start_x, y, start_x+card_w, y+card_h, fill=fill, outline=outline, width=width)
            ax = start_x + 55; ay = y + card_h // 2
            self.canvas.create_oval(ax-30, ay-30, ax+30, ay+30, fill=g["color"], outline="")
            self.canvas.create_text(ax, ay, text=g["icon"], fill="white", font=("Segoe UI", 18, "bold"))
            self.canvas.create_text(start_x + 100, y + 35, anchor="w", text=g["name"], fill=TXT, font=("Segoe UI", 12, "bold"))
            self.canvas.create_text(start_x + 100, y + 58, anchor="w", text=g["desc"], fill=TXT_DIM, font=("Segoe UI", 9))
            price_str = str(g["price"]) + " pts"
            self.canvas.create_text(start_x + card_w - 15, y + card_h - 25, anchor="e", text=price_str,
                                    fill=GOLD, font=("Segoe UI", 11, "bold"))
            if is_sel:
                self.canvas.create_text(start_x + card_w - 15, y + card_h - 8, anchor="e",
                                        text="> ENTER para comprar <", fill=ACCENT2, font=("Segoe UI", 9, "bold"))

        self.canvas.create_text(w//2, h-80, text="%d / %d" % (self.sel_store + 1, len(not_owned)),
                                fill=TXT_MUTED, font=("Consolas", 10))

    def render_config_content(self):
        w, h = self.W(), self.H()
        c = cfg()
        self.canvas.create_text(50, 100, anchor="w", text="CONFIGURACOES", fill=TXT, font=("Segoe UI", 20, "bold"))
        items = [
            ("Som do sistema", "Ligado" if c.get("som") else "Desligado", "som"),
            ("Tela cheia", "Ligado" if c.get("fullscreen") else "Desligado", "fullscreen"),
            ("Alterar avatar", "Icon + cor", "avatar"),
            ("Mudar senha", "Protegida" if self.user and self.user.get("password") else "Sem senha", "password"),
            ("Apagar conta", "Irreversivel", "delete_account"),
            ("Desligar console", "Sair do sistema", "shutdown"),
            ("Sobre", "v" + V, "about"),
        ]
        item_h = 50; item_w = min(700, w - 100)
        start_x = (w - item_w) // 2; start_y = 150
        for i, (label, value, key) in enumerate(items):
            y = start_y + i * (item_h + 6)
            is_sel = (i == self.sel_cfg) and (not self.in_tab_bar)
            fill = CARD_HOVER if is_sel else CARD
            outline = ACCENT if is_sel else BORDER
            self.canvas.create_rectangle(start_x, y, start_x+item_w, y+item_h, fill=fill, outline=outline,
                                         width=2 if is_sel else 1)
            label_color = DANGER if key == "shutdown" else TXT
            self.canvas.create_text(start_x + 25, y + item_h//2, anchor="w", text=label, fill=label_color, font=("Segoe UI", 12, "bold"))
            self.canvas.create_text(start_x + item_w - 25, y + item_h//2, anchor="e", text=value, fill=TXT_DIM, font=("Segoe UI", 11))
            if is_sel:
                self.canvas.create_text(start_x + item_w - 15, y + item_h//2, anchor="e", text=">", fill=ACCENT, font=("Segoe UI", 14, "bold"))
        self._config_items = items

    def get_available_games(self):
        owned = self.user.get("owned_games", []) if self.user else []
        games = []
        for g in STORE_GAMES:
            if g["id"] in owned:
                games.append({"id": g["id"], "name": g["name"], "desc": g["desc"],
                              "icon": g["icon"], "color": g["color"], "type": "digital"})
        for cd in self.scan_cds():
            games.append(cd)
        return games

    def scan_cds(self):
        if not os.path.exists(CDS_DIR):
            try: os.makedirs(CDS_DIR)
            except: pass
            return []
        cds = []
        try:
            for f in sorted(os.listdir(CDS_DIR)):
                if f.endswith(".py") and not f.startswith("_"):
                    name = f[:-3].replace("_", " ").replace("Cd ", "").title()
                    path = os.path.join(CDS_DIR, f)
                    color = PURPLE
                    for gid, n, d, i, c in CD_GAMES:
                        if gid + ".py" == f:
                            name = n; color = c; break
                    cds.append({"id": "cd_" + f[:-3], "name": name, "desc": "CD - " + f,
                                "icon": name[:2].upper(), "color": color, "type": "cd", "path": path})
        except: pass
        return cds

    def render_carousel(self, start_y):
        w, h = self.W(), self.H()
        games = self.get_available_games()

        card_w = 240; card_h = 320; gap = 25
        cy = start_y + card_h // 2 + 20

        sel_idx = self.sel_game
        if sel_idx >= len(games): sel_idx = 0
        center_x = w // 2
        offset_x = center_x - (sel_idx * (card_w + gap) + card_w // 2)

        for i, g in enumerate(games):
            x = offset_x + i * (card_w + gap)
            y = cy - card_h // 2
            if x + card_w < -50 or x > w + 50: continue

            is_sel = (i == self.sel_game) and (not self.in_tab_bar)
            fill = "#202030" if is_sel else CARD
            outline = ACCENT if is_sel else BORDER
            width = 3 if is_sel else 1

            self.canvas.create_rectangle(x, y, x+card_w, y+card_h, fill=fill, outline=outline, width=width)
            self.canvas.create_oval(x + card_w//2 - 50, y + 60, x + card_w//2 + 50, y + 160,
                                    fill=g.get("color", ACCENT), outline="")
            self.canvas.create_text(x + card_w//2, y + 110, text=g.get("icon", "?")[:2],
                                    fill="white", font=("Segoe UI", 40, "bold"))
            if g.get("type") == "cd":
                self.canvas.create_text(x + 20, y + 20, anchor="nw", text="CD", fill=PURPLE, font=("Segoe UI", 9, "bold"))
            self.canvas.create_text(x + card_w//2, y + 190, text=g.get("name", "?"),
                                    fill=TXT if is_sel else TXT_DIM, font=("Segoe UI", 13, "bold"))
            self.canvas.create_text(x + card_w//2, y + 215, text=g.get("desc", ""),
                                    fill=TXT_MUTED, font=("Segoe UI", 9), width=220)
            hs = self.user.get("high_scores", {}).get(g["id"], 0) if self.user else 0
            if hs > 0:
                self.canvas.create_text(x + card_w//2, y + 245, text="High: " + str(hs),
                                        fill=GOLD, font=("Consolas", 10, "bold"))
            if is_sel:
                self.canvas.create_rectangle(x, y+card_h-40, x+card_w, y+card_h, fill=ACCENT, outline="")
                self.canvas.create_text(x + card_w//2, y+card_h-20, text="> JOGAR <",
                                        fill="white", font=("Segoe UI", 11, "bold"))

        if not games:
            self.canvas.create_text(w//2, start_y + card_h//2, text="Nenhum jogo disponivel",
                                    fill=TXT_DIM, font=("Segoe UI", 14))
            self.canvas.create_text(w//2, start_y + card_h//2 + 30, text="Va na LOJA",
                                    fill=TXT_MUTED, font=("Segoe UI", 10))

        self.canvas.create_text(w//2, start_y + card_h + 50,
                                text="%d / %d" % (min(sel_idx+1, max(len(games),1)), max(len(games),1)),
                                fill=TXT_MUTED, font=("Consolas", 10))

    def nav(self, direction):
        if self.game_open: return
        if self.state == "boot": return
        if self.state == "login":
            total = len(users()) + 1
            if direction in ("left", "right"):
                self.sel_user = (self.sel_user + (1 if direction == "right" else -1)) % total
                snd("nav"); self.login_screen()
            return
        if self.state != "main": return

        snd("nav")
        if self.in_tab_bar:
            if direction == "left": self.tab = (self.tab - 1) % len(TABS)
            elif direction == "right": self.tab = (self.tab + 1) % len(TABS)
            elif direction == "down": self.in_tab_bar = False
            self.render_main()
        else:
            if self.tab in (0, 1):
                games = self.get_available_games()
                total = max(len(games), 1)
                if direction == "left": self.sel_game = (self.sel_game - 1) % total
                elif direction == "right": self.sel_game = (self.sel_game + 1) % total
                elif direction == "up": self.in_tab_bar = True
                self.render_main()
            elif self.tab == 2:
                total = max(len(self._store_items), 1)
                if direction == "up":
                    if self.sel_store == 0: self.in_tab_bar = True
                    else: self.sel_store = self.sel_store - 1
                elif direction == "down":
                    self.sel_store = (self.sel_store + 1) % total
                self.render_main()
            elif self.tab == 3:
                total = len(self._config_items)
                if direction == "up":
                    if self.sel_cfg == 0: self.in_tab_bar = True
                    else: self.sel_cfg = (self.sel_cfg - 1) % total
                elif direction == "down":
                    self.sel_cfg = (self.sel_cfg + 1) % total
                self.render_main()

    def enter(self):
        if self.game_open: return
        if self.state == "boot": return
        if self.state == "login":
            self.login_enter(); return
        if self.state != "main": return
        if self.in_tab_bar:
            if self.tab == 3:
                self.in_tab_bar = False; self.sel_cfg = 0; self.render_main()
            return

        if self.tab in (0, 1):
            games = self.get_available_games()
            if self.sel_game < len(games):
                snd("select"); self.start_game(games[self.sel_game])
        elif self.tab == 2:
            if self._store_items and self.sel_store < len(self._store_items):
                self.buy_game(self._store_items[self.sel_store])
        elif self.tab == 3:
            if self.sel_cfg < len(self._config_items):
                self.config_action(self._config_items[self.sel_cfg][2])

    def login_enter(self):
        snd("select")
        all_u = users()
        if self.sel_user < len(all_u):
            u = all_u[self.sel_user]
            if u.get("password"):
                pwd = simpledialog.askstring("Senha", "Senha de " + u["name"] + ":",
                                              show="*", parent=self.root)
                if pwd is None: self.root.focus_force(); return
                if pwd != u["password"]:
                    messagebox.showerror("Erro", "Senha incorreta")
                    snd("error"); self.root.focus_force(); return
            self.user = u; snd("login"); self.main_screen()
        else:
            self.create_profile()

    def create_profile(self):
        all_u = users()
        if len(all_u) >= MAX_ACCOUNTS:
            messagebox.showerror("Limite", "Maximo de " + str(MAX_ACCOUNTS) + " contas atingido.")
            self.root.focus_force(); return
        name = simpledialog.askstring("Novo perfil", "Nome:", parent=self.root)
        if not name: self.root.focus_force(); return
        icon = simpledialog.askstring("Icone", "Letra (1-2):", initialvalue=name[0].upper(), parent=self.root)
        if not icon: icon = name[0].upper()
        # LOJA VAZIA - usuario come�a sem nenhum jogo
        new_u = {"name": name, "icon": icon[:2].upper(), "color": random.choice(AVATAR_COLORS),
                 "password": "", "points": 100, "total_points": 100,
                 "owned_games": [], "high_scores": {}}
        all_u.append(new_u); save_users(all_u)
        self.sel_user = len(all_u) - 1
        snd("select"); self.root.focus_force(); self.login_screen()

    def buy_game(self, g):
        if not self.user: return
        owned = self.user.get("owned_games", [])
        if g["id"] in owned:
            messagebox.showinfo("Info", "Voce ja tem este jogo")
            self.root.focus_force(); return
        price = g["price"]
        pts = self.user.get("points", 0)
        if pts < price:
            messagebox.showerror("Pontos insuficientes", "Voce tem " + str(pts) + " pts\nPrecisa de " + str(price))
            snd("error"); self.root.focus_force(); return
        if not messagebox.askyesno("Comprar", "Comprar " + g["name"] + "\npor " + str(price) + " pontos?"):
            self.root.focus_force(); return
        all_u = users()
        for u in all_u:
            if u["name"] == self.user["name"]:
                u["points"] = pts - price
                owned.append(g["id"]); u["owned_games"] = owned
                self.user = u; break
        save_users(all_u)
        snd("buy"); messagebox.showinfo("Comprado!", g["name"] + " agora e seu!")
        self.sel_store = 0; self.root.focus_force(); self.render_main()

    def config_action(self, key):
        c = cfg()
        if key == "som":
            c["som"] = not c.get("som", True); scfg(c); snd("click"); self.render_main()
        elif key == "fullscreen": self.toggle_fs(); self.render_main()
        elif key == "avatar": self.edit_avatar()
        elif key == "password": self.edit_password()
        elif key == "delete_account": self.delete_account()
        elif key == "shutdown":
            if messagebox.askyesno("Desligar", "Desligar o console?"): self.shutdown()
        elif key == "about":
            messagebox.showinfo("Sobre", "minstcaveStation v" + V + "\n\n"
                "Console de jogos em Python\n"
                "25 jogos na loja + 25 CDs\n\n"
                "Controles: SETAS + ENTER (sem mouse!)\n\n"
                "Pasta de CDs: " + CDS_DIR)
            self.root.focus_force()

    def edit_avatar(self):
        w = tk.Toplevel(self.root)
        w.title("Alterar Avatar"); w.configure(bg=BG); w.geometry("500x500+300+100")
        w.grab_set()
        tk.Label(w, text="ALTERAR AVATAR", bg=BG, fg=ACCENT2, font=("Segoe UI", 16, "bold")).pack(pady=15)
        preview = tk.Canvas(w, width=120, height=120, bg=BG, highlightthickness=0)
        preview.pack(pady=10)
        state = {"icon": self.user.get("icon", "P"), "color": self.user.get("color", ACCENT)}
        def update_preview():
            preview.delete("all")
            preview.create_oval(10, 10, 110, 110, fill=state["color"], outline="")
            preview.create_text(60, 60, text=state["icon"][:2], fill="white", font=("Segoe UI", 40, "bold"))
        tk.Label(w, text="Icone (1-2 letras):", bg=BG, fg=TXT).pack(pady=(10, 3))
        icon_e = tk.Entry(w, bg=CARD, fg=TXT, insertbackground=TXT, font=("Segoe UI", 14),
                          relief="flat", width=5, justify="center")
        icon_e.pack(ipady=6); icon_e.insert(0, state["icon"])
        def on_icon(e=None):
            v = icon_e.get().strip().upper()
            if v: state["icon"] = v[:2]; update_preview()
        icon_e.bind("<KeyRelease>", on_icon)
        tk.Label(w, text="Cor (setas + ENTER):", bg=BG, fg=TXT).pack(pady=(15, 5))
        cf = tk.Frame(w, bg=BG); cf.pack()
        color_idx = [AVATAR_COLORS.index(state["color"]) if state["color"] in AVATAR_COLORS else 0]
        btns = []
        def update_color_sel():
            for i, b in enumerate(btns):
                b.config(borderwidth=3 if i == color_idx[0] else 0,
                         relief="solid" if i == color_idx[0] else "flat")
        for i, col in enumerate(AVATAR_COLORS):
            def mk(idx, c):
                def cmd():
                    color_idx[0] = idx; state["color"] = c; update_preview(); update_color_sel()
                return cmd
            b = tk.Button(cf, bg=col, width=4, height=2, relief="flat", command=mk(i, col))
            b.pack(side="left", padx=2); btns.append(b)
        update_color_sel()
        def save():
            all_u = users()
            for u in all_u:
                if u["name"] == self.user["name"]:
                    u["icon"] = state["icon"][:2]; u["color"] = state["color"]; self.user = u; break
            save_users(all_u); snd("select"); w.destroy(); self.root.focus_force(); self.render_main()
        tk.Button(w, text="SALVAR (ENTER)", bg=ACCENT, fg="white", font=("Segoe UI", 12, "bold"),
                  relief="flat", command=save, pady=10).pack(fill="x", padx=40, pady=20)
        tk.Button(w, text="Cancelar (ESC)", bg=CARD, fg=TXT, font=("Segoe UI", 10),
                  relief="flat", command=lambda: (w.destroy(), self.root.focus_force()), pady=6).pack()
        w.bind("<Return>", lambda e: save())
        w.bind("<Escape>", lambda e: (w.destroy(), self.root.focus_force()))
        update_preview()

    def edit_password(self):
        has_pw = bool(self.user.get("password"))
        if has_pw:
            cur = simpledialog.askstring("Senha atual", "Digite a senha atual:", show="*", parent=self.root)
            if cur is None: self.root.focus_force(); return
            if cur != self.user.get("password"):
                messagebox.showerror("Erro", "Senha incorreta"); self.root.focus_force(); return
        if has_pw:
            if not messagebox.askyesno("Senha", "Remover senha deste perfil?"):
                self.root.focus_force(); return
            all_u = users()
            for u in all_u:
                if u["name"] == self.user["name"]:
                    u["password"] = ""; self.user = u; break
            save_users(all_u); messagebox.showinfo("OK", "Senha removida")
        else:
            new = simpledialog.askstring("Nova senha", "Digite uma senha:", show="*", parent=self.root)
            if not new or len(new) < 3:
                messagebox.showerror("Erro", "Senha muito curta (min 3)"); self.root.focus_force(); return
            all_u = users()
            for u in all_u:
                if u["name"] == self.user["name"]:
                    u["password"] = new; self.user = u; break
            save_users(all_u); snd("select"); messagebox.showinfo("OK", "Senha definida!")
        self.root.focus_force(); self.render_main()

    def delete_account(self):
        if not messagebox.askyesno("Apagar conta", "APAGAR PERFIL '" + self.user["name"] + "'?"):
            self.root.focus_force(); return
        if not messagebox.askyesno("Confirmar", "TEM CERTEZA?"):
            self.root.focus_force(); return
        all_u = users()
        all_u = [u for u in all_u if u["name"] != self.user["name"]]
        save_users(all_u)
        self.user = None; self.state = "login"; self.sel_user = 0
        snd("back"); self.root.focus_force(); self.login_screen()

    def back(self):
        if self.game_open: return
        if self.state == "login":
            snd("back"); self.boot_anim()
        elif self.state == "main":
            snd("back")
            if not self.in_tab_bar: self.in_tab_bar = True; self.render_main()
            else:
                self.state = "login"; self.user = None; self.sel_user = 0; self.login_screen()

    def esc(self):
        if self.game_open: return
        if self.state == "main":
            snd("back"); self.state = "login"; self.user = None; self.login_screen()

    def shutdown(self):
        self.canvas.delete("all")
        w, h = self.W(), self.H()
        self.canvas.create_text(w//2, h//2 - 20, text="Ate a proxima!", fill=ACCENT2, font=("Segoe UI", 26, "bold"))
        self.canvas.create_text(w//2, h//2 + 20, text="Desligando...", fill=TXT_DIM, font=("Segoe UI", 12))
        def close():
            try: self.root.destroy()
            except: pass
        self.root.after(1400, close)

    def end_game(self, game_id, score):
        if not self.user: return
        pts = max(1, score // 10)
        all_u = users()
        for u in all_u:
            if u["name"] == self.user["name"]:
                u["points"] = u.get("points", 0) + pts
                u["total_points"] = u.get("total_points", 0) + pts
                hs = u.get("high_scores", {})
                if score > hs.get(game_id, 0): hs[game_id] = score
                u["high_scores"] = hs; self.user = u; break
        save_users(all_u); snd("coin")

    def start_game(self, g):
        gid = g.get("id", "")
        if g.get("type") == "cd": self.play_cd(g); return
        handler = getattr(self, "game_" + gid.replace("-", "_"), None)
        if handler: handler()
        else:
            messagebox.showinfo("Info", "Este jogo ainda nao foi implementado")
            self.close_game()

    def close_game(self):
        self.game_open = False
        if self.game_frame:
            try: self.game_frame.destroy()
            except: pass
            self.game_frame = None
        self.bind_main()
        try: self.root.focus_force()
        except: pass
        self.render_main()

    def open_game_frame(self):
        self.unbind_main()
        self.game_open = True
        self.game_frame = tk.Frame(self.root, bg="#0a0a0f")
        self.game_frame.place(x=0, y=0, relwidth=1, relheight=1)
        return self.game_frame

    def _game_canvas(self):
        frame = self.open_game_frame()
        cv = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0)
        cv.pack(fill="both", expand=True)
        frame.update_idletasks()
        return frame, cv, (cv.winfo_width() or 1000), (cv.winfo_height() or 650)

    def play_cd(self, cd):
        frame = self.open_game_frame()
        try:
            f = open(cd["path"], "r"); code = f.read(); f.close()
            namespace = {"tk": tk, "messagebox": messagebox, "random": random,
                         "time": time, "math": math, "datetime": datetime, "parent": frame}
            exec(compile(code, cd["path"], "exec"), namespace)
        except Exception as e:
            messagebox.showerror("Erro CD", "Nao foi possivel carregar:\n" + str(e))
            self.close_game(); return
        def on_esc(e):
            self.close_game(); return "break"
        frame.bind("<Escape>", on_esc)
        try: frame.focus_set()
        except: pass
        self.root.bind("<Escape>", on_esc)

    # ============ JOGOS ============

    def game_zumbi(self):
        frame = self.open_game_frame()
        canvas = tk.Canvas(frame, bg="#1a1a20", highlightthickness=0)
        canvas.pack(fill="both", expand=True)
        frame.update_idletasks()
        W = canvas.winfo_width() or 1000
        H = canvas.winfo_height() or 650
        S = {"px": W//2, "py": H//2, "hp": 100, "max_hp": 100, "aim_x": W//2, "aim_y": H//2,
             "bullets": [], "zombies": [], "particles": [], "pickups": [],
             "score": 0, "wave": 1, "killed": 0, "wave_total": 5, "ammo": 30, "max_ammo": 30,
             "reloading": False, "reload_end": 0, "keys": set(), "shooting": False,
             "last_shot": 0, "alive": True, "playing": True, "wave_notif": 0,
             "aim_angle": 0}
        def spawn_z():
            edge = random.randint(0, 3)
            if edge == 0: x, y = random.randint(0, W), -30
            elif edge == 1: x, y = W+30, random.randint(0, H)
            elif edge == 2: x, y = random.randint(0, W), H+30
            else: x, y = -30, random.randint(0, H)
            zt = random.choice([0, 0, 0, 1, 1, 2])
            if zt == 0: hp = 30 + S["wave"]*10; spd = 1.0 + S["wave"]*0.15; size = 15; color = "#4a7c59"
            elif zt == 1: hp = 20 + S["wave"]*5; spd = 2.0 + S["wave"]*0.25; size = 11; color = "#7c4a4a"
            else: hp = 80 + S["wave"]*20; spd = 0.6 + S["wave"]*0.10; size = 22; color = "#4a4a7c"
            S["zombies"].append({"x": x, "y": y, "hp": hp, "max_hp": hp, "speed": spd,
                                 "size": size, "color": color, "last_hit": 0, "type": zt})
        for _ in range(S["wave_total"]): spawn_z()
        def draw():
            canvas.delete("all")
            canvas.create_rectangle(0, 0, W, H, fill="#1a1a20", outline="")
            for i in range(0, W, 50): canvas.create_line(i, 0, i, H, fill="#252530", width=1)
            for i in range(0, H, 50): canvas.create_line(0, i, W, i, fill="#252530", width=1)
            for p in S["particles"]:
                canvas.create_oval(p["x"]-p["r"], p["y"]-p["r"], p["x"]+p["r"], p["y"]+p["r"], fill=p["color"], outline="")
            for pk in S["pickups"]:
                c = "#4caf50" if pk["type"] == "hp" else "#ff9800"
                canvas.create_rectangle(pk["x"]-10, pk["y"]-10, pk["x"]+10, pk["y"]+10, fill=c, outline="white", width=2)
                canvas.create_text(pk["x"], pk["y"], text=("+" if pk["type"]=="hp" else "A"), fill="white", font=("Segoe UI", 10, "bold"))
            for z in S["zombies"]:
                sz = z["size"]
                canvas.create_oval(z["x"]-sz, z["y"]-sz, z["x"]+sz, z["y"]+sz, fill=z["color"], outline="")
                canvas.create_oval(z["x"]-sz//2, z["y"]-sz//2, z["x"]+sz//2, z["y"]+sz//2,
                                   fill="#6ba578" if z["type"]==0 else z["color"], outline="")
                canvas.create_oval(z["x"]-sz//3-2, z["y"]-2, z["x"]-sz//3+2, z["y"]+2, fill="#ff0000", outline="")
                canvas.create_oval(z["x"]+sz//3-2, z["y"]-2, z["x"]+sz//3+2, z["y"]+2, fill="#ff0000", outline="")
                if z["hp"] < z["max_hp"]:
                    canvas.create_rectangle(z["x"]-sz, z["y"]-sz-8, z["x"]+sz, z["y"]-sz-4, fill="#333", outline="")
                    canvas.create_rectangle(z["x"]-sz, z["y"]-sz-8, z["x"]-sz+int(2*sz*z["hp"]/z["max_hp"]),
                                            z["y"]-sz-4, fill="#ff3355", outline="")
            for b in S["bullets"]:
                canvas.create_oval(b["x"]-3, b["y"]-3, b["x"]+3, b["y"]+3, fill="#ffeb3b", outline="#ff9800")
            if S["alive"]:
                px, py = S["px"], S["py"]
                canvas.create_oval(px-18, py-18, px+18, py+18, fill="#2196f3", outline="#0d47a1", width=2)
                dx = math.cos(S["aim_angle"]); dy = math.sin(S["aim_angle"])
                canvas.create_line(px+dx*10, py+dy*10, px+dx*32, py+dy*32, fill="#666", width=6)
                canvas.create_oval(px-8, py-8, px+8, py+8, fill="#64b5f6", outline="")
            canvas.create_rectangle(0, 0, W, 60, fill="#000", outline="")
            canvas.create_line(0, 60, W, 60, fill="#ff3355", width=2)
            canvas.create_text(15, 20, anchor="w", text="HP", fill="#ff3355", font=("Segoe UI", 10, "bold"))
            canvas.create_rectangle(45, 14, 220, 28, fill="#333", outline="")
            hp_w = int(175 * S["hp"] / S["max_hp"])
            canvas.create_rectangle(45, 14, 45+hp_w, 28, fill=("#ff3355" if S["hp"] < 30 else "#4caf50"), outline="")
            canvas.create_text(230, 21, anchor="w", text=str(S["hp"])+"/"+str(S["max_hp"]), fill="#fff", font=("Consolas", 10, "bold"))
            canvas.create_text(W//2, 21, text="SCORE: " + str(S["score"]), fill="#ffeb3b", font=("Consolas", 14, "bold"))
            canvas.create_text(W-260, 21, anchor="w", text="WAVE " + str(S["wave"]), fill="#00d4ff", font=("Consolas", 12, "bold"))
            ammo_color = "#4caf50" if S["ammo"] > 10 else ("#ff9800" if S["ammo"] > 0 else "#ff3355")
            canvas.create_text(W-15, 21, anchor="e", text="AMMO: "+str(S["ammo"])+"/"+str(S["max_ammo"]),
                               fill=ammo_color, font=("Consolas", 12, "bold"))
            if S["reloading"]: canvas.create_text(W//2, 45, text="RECARREGANDO...", fill="#ff9800", font=("Segoe UI", 11, "bold"))
            canvas.create_text(15, 45, anchor="w", text="WASD/setas mover | ESPACO/ENTER atirar | R recarregar | ESC sair",
                               fill="#7a7a8a", font=("Segoe UI", 9))
            if S["wave_notif"] > 0:
                canvas.create_text(W//2, H//2 - 80, text="WAVE " + str(S["wave"]), fill="#ffeb3b", font=("Segoe UI", 36, "bold"))
            if not S["alive"]:
                canvas.create_rectangle(0, 0, W, H, fill="#000", outline="")
                canvas.create_text(W//2, H//2 - 100, text="VOCE MORREU", fill="#ff3355", font=("Segoe UI", 40, "bold"))
                canvas.create_text(W//2, H//2 - 40, text="Score: " + str(S["score"]), fill="#ffeb3b", font=("Consolas", 22, "bold"))
                gain = max(1, S["score"] // 10)
                canvas.create_text(W//2, H//2 + 5, text="+" + str(gain) + " pontos", fill="#4caf50", font=("Segoe UI", 16, "bold"))
                canvas.create_text(W//2, H//2 + 90, text="ENTER: jogar de novo", fill="#00d4ff", font=("Segoe UI", 13, "bold"))
                canvas.create_text(W//2, H//2 + 120, text="ESC: voltar", fill="#7a7a8a", font=("Segoe UI", 11))
        def update():
            try:
                if not S["playing"] or not frame.winfo_exists() or not canvas.winfo_exists(): return
            except: return
            if S["alive"]:
                spd = 4.5; k = S["keys"]; dx, dy = 0, 0
                if "w" in k or "W" in k or "Up" in k: dy -= 1
                if "s" in k or "S" in k or "Down" in k: dy += 1
                if "a" in k or "A" in k or "Left" in k: dx -= 1
                if "d" in k or "D" in k or "Right" in k: dx += 1
                if dx != 0 and dy != 0: dx *= 0.707; dy *= 0.707
                S["px"] = max(30, min(W-30, S["px"] + dx*spd)); S["py"] = max(80, min(H-30, S["py"] + dy*spd))
                # Aim angle segue WASD quando move
                if dx != 0 or dy != 0: S["aim_angle"] = math.atan2(dy, dx)
                if S["reloading"] and time.time() >= S["reload_end"]:
                    S["ammo"] = S["max_ammo"]; S["reloading"] = False
                if S["shooting"] and S["ammo"] > 0 and not S["reloading"]:
                    if time.time() - S["last_shot"] > 0.12:
                        S["last_shot"] = time.time(); S["ammo"] -= 1
                        px, py = S["px"], S["py"]
                        bx = math.cos(S["aim_angle"]) * 18; by = math.sin(S["aim_angle"]) * 18
                        S["bullets"].append({"x": px+bx/2, "y": py+by/2, "vx": bx, "vy": by, "life": 60})
                        snd("shoot")
                        if S["ammo"] == 0: S["reloading"] = True; S["reload_end"] = time.time() + 1.5
                for b in S["bullets"][:]:
                    b["x"] += b["vx"]; b["y"] += b["vy"]; b["life"] -= 1
                    if b["life"] <= 0 or b["x"] < 0 or b["x"] > W or b["y"] < 60 or b["y"] > H:
                        if b in S["bullets"]: S["bullets"].remove(b)
                        continue
                    hit = False
                    for z in S["zombies"][:]:
                        if abs(b["x"]-z["x"]) < z["size"]+3 and abs(b["y"]-z["y"]) < z["size"]+3:
                            z["hp"] -= 20
                            for _ in range(6):
                                S["particles"].append({"x": z["x"], "y": z["y"],
                                    "vx": random.uniform(-4, 4), "vy": random.uniform(-4, 4),
                                    "r": random.uniform(2, 6), "color": "#ff3355", "life": 25})
                            if z["hp"] <= 0:
                                S["zombies"].remove(z)
                                S["score"] += 10 if z["type"] != 2 else 30
                                S["killed"] += 1; snd("hit")
                                if random.random() < 0.15:
                                    S["pickups"].append({"x": z["x"], "y": z["y"],
                                                         "type": "hp" if random.random()<0.5 else "ammo"})
                                if S["killed"] >= S["wave_total"]:
                                    S["wave"] += 1; S["killed"] = 0
                                    S["wave_total"] = 4 + S["wave"] * 2
                                    S["wave_notif"] = 90
                                    for _ in range(S["wave_total"]): spawn_z()
                            if b in S["bullets"]: S["bullets"].remove(b)
                            hit = True; break
                    if hit: continue
                for pk in S["pickups"][:]:
                    if math.sqrt((S["px"]-pk["x"])**2 + (S["py"]-pk["y"])**2) < 30:
                        if pk["type"] == "hp": S["hp"] = min(S["max_hp"], S["hp"]+25)
                        else: S["ammo"] = min(S["max_ammo"], S["ammo"]+15)
                        S["pickups"].remove(pk); snd("coin")
                for z in S["zombies"]:
                    ddx = S["px"] - z["x"]; ddy = S["py"] - z["y"]
                    dd = math.sqrt(ddx*ddx+ddy*ddy) or 1
                    z["x"] += ddx/dd * z["speed"]; z["y"] += ddy/dd * z["speed"]
                    if dd < z["size"] + 12:
                        if time.time() - z["last_hit"] > 0.7:
                            dmg = 15 if z["type"] == 2 else 10
                            S["hp"] -= dmg; z["last_hit"] = time.time(); snd("error")
                            if S["hp"] <= 0:
                                S["hp"] = 0; S["alive"] = False; snd("die"); self.end_game("zumbi", S["score"])
                for p in S["particles"][:]:
                    p["x"] += p["vx"]; p["y"] += p["vy"]
                    p["vx"] *= 0.9; p["vy"] *= 0.9; p["life"] -= 1
                    if p["life"] <= 0: S["particles"].remove(p)
                if S["wave_notif"] > 0: S["wave_notif"] -= 1
            draw()
            try: frame.after(16, update)
            except: pass
        def restart():
            S["px"] = W//2; S["py"] = H//2; S["hp"] = 100; S["alive"] = True
            S["bullets"] = []; S["zombies"] = []; S["particles"] = []; S["pickups"] = []
            S["score"] = 0; S["wave"] = 1; S["killed"] = 0; S["wave_total"] = 5
            S["ammo"] = 30; S["reloading"] = False; S["wave_notif"] = 0; S["aim_angle"] = 0
            for _ in range(5): spawn_z()
        def on_key(e):
            k = e.keysym
            if k == "Escape": S["playing"] = False; self.close_game(); return "break"
            if not S["alive"] and k == "Return": restart(); return "break"
            if k.lower() == "r" and not S["reloading"] and S["ammo"] < S["max_ammo"]:
                S["reloading"] = True; S["reload_end"] = time.time() + 1.5
            if k in ("space", "Return") and S["alive"]: S["shooting"] = True
            S["keys"].add(k)
        def on_kr(e):
            try:
                if e.keysym in ("space", "Return"): S["shooting"] = False
                S["keys"].discard(e.keysym)
            except: pass
        self.root.bind("<KeyPress>", on_key)
        self.root.bind("<KeyRelease>", on_kr)
        canvas.focus_set(); frame.focus_force(); update()

    def game_snake(self):
        frame = self.open_game_frame()
        tk.Label(frame, text="SNAKE", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 18, "bold")).pack(pady=5)
        canvas = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0, width=560, height=500)
        canvas.pack(pady=10)
        S = {"snake": [(10, 10)], "dir": (1, 0), "food": (5, 5), "score": 0, "alive": True, "playing": True, "speed": 120}
        cell = 25; cols = 22; rows = 20
        def spawn_food():
            while True:
                f = (random.randint(0, cols-1), random.randint(0, rows-1))
                if f not in S["snake"]: S["food"] = f; return
        def draw():
            canvas.delete("all")
            for x in range(0, cols*cell + 1, cell): canvas.create_line(x, 0, x, rows*cell, fill="#1a1a24")
            for y in range(0, rows*cell + 1, cell): canvas.create_line(0, y, cols*cell, y, fill="#1a1a24")
            for i, (x, y) in enumerate(S["snake"]):
                color = "#81c784" if i == 0 else "#4caf50"
                canvas.create_rectangle(x*cell+1, y*cell+1, (x+1)*cell-1, (y+1)*cell-1, fill=color, outline="#2e7d32")
            fx, fy = S["food"]
            canvas.create_oval(fx*cell+3, fy*cell+3, (fx+1)*cell-3, (fy+1)*cell-3, fill="#ff3355", outline="#c62828")
            canvas.create_text(10, rows*cell + 20, anchor="w", text="Score: " + str(S["score"]), fill="#fff", font=("Consolas", 12, "bold"))
            canvas.create_text(cols*cell - 10, rows*cell + 20, anchor="e", text="Setas | ESC: sair", fill="#7a7a8a", font=("Segoe UI", 9))
            if not S["alive"]:
                canvas.create_rectangle(0, 0, cols*cell, rows*cell, fill="#000", outline="")
                canvas.create_text(cols*cell//2, rows*cell//2 - 50, text="GAME OVER", fill="#ff3355", font=("Segoe UI", 32, "bold"))
                canvas.create_text(cols*cell//2, rows*cell//2 - 10, text="Score: " + str(S["score"]), fill="#ffeb3b", font=("Consolas", 18))
                gain = max(1, S["score"] // 10)
                canvas.create_text(cols*cell//2, rows*cell//2 + 20, text="+" + str(gain) + " pontos", fill="#4caf50", font=("Segoe UI", 14, "bold"))
                canvas.create_text(cols*cell//2, rows*cell//2 + 60, text="ENTER: jogar de novo", fill="#00d4ff", font=("Segoe UI", 11))
        def step():
            try:
                if not S["playing"] or not S["alive"] or not frame.winfo_exists(): return
            except: return
            hx, hy = S["snake"][0]; dx, dy = S["dir"]
            nx, ny = hx + dx, hy + dy
            if nx < 0 or nx >= cols or ny < 0 or ny >= rows or (nx, ny) in S["snake"]:
                S["alive"] = False; snd("die"); self.end_game("snake", S["score"]); draw(); return
            S["snake"].insert(0, (nx, ny))
            if (nx, ny) == S["food"]:
                S["score"] += 1; snd("hit"); spawn_food()
                if S["score"] % 5 == 0 and S["speed"] > 60: S["speed"] -= 5
            else: S["snake"].pop()
            draw()
            try: frame.after(S["speed"], step)
            except: pass
        def restart():
            S["snake"] = [(10, 10)]; S["dir"] = (1, 0); S["food"] = (5, 5)
            S["score"] = 0; S["alive"] = True; S["speed"] = 120
            draw(); step()
        def on_key(e):
            k = e.keysym
            if k == "Escape": S["playing"] = False; self.close_game(); return "break"
            if not S["alive"] and k == "Return": restart(); return "break"
            d = S["dir"]
            if k == "Up" and d != (0, 1): S["dir"] = (0, -1)
            elif k == "Down" and d != (0, -1): S["dir"] = (0, 1)
            elif k == "Left" and d != (1, 0): S["dir"] = (-1, 0)
            elif k == "Right" and d != (-1, 0): S["dir"] = (1, 0)
        self.root.bind("<KeyPress>", on_key)
        canvas.focus_set(); frame.focus_force(); draw(); step()

    def game_2048(self):
        frame = self.open_game_frame()
        tk.Label(frame, text="2048", bg="#0a0a0f", fg="#ff9800", font=("Segoe UI", 22, "bold")).pack(pady=5)
        canvas = tk.Canvas(frame, bg="#1a1a24", highlightthickness=0, width=460, height=460)
        canvas.pack(pady=10)
        S = {"grid": [[0]*4 for _ in range(4)], "score": 0, "playing": True, "won": False}
        cell = 105; pad = 10
        colors = {2:"#eee4da",4:"#ede0c8",8:"#f2b179",16:"#f59563",32:"#f67c5f",
                  64:"#f65e3b",128:"#edcf72",256:"#edcc61",512:"#edc850",1024:"#edc53f",2048:"#edc22e"}
        def add_tile():
            em = [(r,c) for r in range(4) for c in range(4) if S["grid"][r][c]==0]
            if em:
                r, c = random.choice(em)
                S["grid"][r][c] = 2 if random.random()<0.9 else 4
        def draw():
            canvas.delete("all")
            for r in range(4):
                for c in range(4):
                    x = c*(cell+pad)+pad; y = r*(cell+pad)+pad
                    v = S["grid"][r][c]
                    if v == 0: canvas.create_rectangle(x, y, x+cell, y+cell, fill="#2a2a3a", outline="")
                    else:
                        canvas.create_rectangle(x, y, x+cell, y+cell, fill=colors.get(v, "#3c3a32"), outline="")
                        fs = 32 if v < 100 else (26 if v < 1000 else 20)
                        canvas.create_text(x+cell//2, y+cell//2, text=str(v),
                                           fill="#776e65" if v<=4 else "white", font=("Segoe UI", fs, "bold"))
            if not S["playing"]:
                canvas.create_rectangle(0, 0, 460, 460, fill="#000", outline="")
                msg = "VOCE VENCEU!" if S["won"] else "GAME OVER"
                color = "#ffeb3b" if S["won"] else "#ff3355"
                canvas.create_text(230, 170, text=msg, fill=color, font=("Segoe UI", 30, "bold"))
                canvas.create_text(230, 220, text="Score: " + str(S["score"]), fill="#fff", font=("Consolas", 18))
                gain = max(1, S["score"] // 10)
                canvas.create_text(230, 260, text="+" + str(gain) + " pontos", fill="#4caf50", font=("Segoe UI", 14))
                canvas.create_text(230, 310, text="ENTER: jogar de novo", fill="#00d4ff", font=("Segoe UI", 11))
                canvas.create_text(230, 340, text="ESC: voltar", fill="#7a7a8a", font=("Segoe UI", 10))
        def check_over():
            for r in range(4):
                for c in range(4):
                    if S["grid"][r][c] == 0: return False
            for r in range(4):
                for c in range(4):
                    v = S["grid"][r][c]
                    if c < 3 and S["grid"][r][c+1] == v: return False
                    if r < 3 and S["grid"][r+1][c] == v: return False
            return True
        def move(direction):
            if not S["playing"]: return
            moved = False; g = S["grid"]
            if direction == "left":
                for r in range(4):
                    row = [x for x in g[r] if x != 0]; new = []; i = 0
                    while i < len(row):
                        if i+1 < len(row) and row[i] == row[i+1]:
                            new.append(row[i]*2); S["score"] += row[i]*2; i += 2
                        else: new.append(row[i]); i += 1
                    new += [0] * (4 - len(new))
                    if new != g[r]: moved = True; g[r] = new
            elif direction == "right":
                for r in range(4):
                    row = [x for x in g[r] if x != 0]; new = []; i = len(row)-1
                    while i >= 0:
                        if i-1 >= 0 and row[i] == row[i-1]:
                            new.insert(0, row[i]*2); S["score"] += row[i]*2; i -= 2
                        else: new.insert(0, row[i]); i -= 1
                    new = [0]*(4-len(new)) + new
                    if new != g[r]: moved = True; g[r] = new
            elif direction == "up":
                for c in range(4):
                    col = [g[r][c] for r in range(4) if g[r][c] != 0]; new = []; i = 0
                    while i < len(col):
                        if i+1 < len(col) and col[i] == col[i+1]:
                            new.append(col[i]*2); S["score"] += col[i]*2; i += 2
                        else: new.append(col[i]); i += 1
                    new += [0] * (4 - len(new))
                    for r in range(4):
                        if g[r][c] != new[r]: moved = True
                        g[r][c] = new[r]
            elif direction == "down":
                for c in range(4):
                    col = [g[r][c] for r in range(4) if g[r][c] != 0]; new = []; i = len(col)-1
                    while i >= 0:
                        if i-1 >= 0 and col[i] == col[i-1]:
                            new.insert(0, col[i]*2); S["score"] += col[i]*2; i -= 2
                        else: new.insert(0, col[i]); i -= 1
                    new = [0]*(4-len(new)) + new
                    for r in range(4):
                        if g[r][c] != new[r]: moved = True
                        g[r][c] = new[r]
            if moved:
                add_tile()
                for r in range(4):
                    for c in range(4):
                        if g[r][c] == 2048: S["won"] = True
                if check_over():
                    S["playing"] = False; self.end_game("2048", S["score"])
                draw()
                try: score_lbl.config(text="Score: " + str(S["score"]))
                except: pass
        def restart():
            S["grid"] = [[0]*4 for _ in range(4)]
            S["score"] = 0; S["playing"] = True; S["won"] = False
            add_tile(); add_tile()
            try: score_lbl.config(text="Score: 0")
            except: pass
            draw()
        def on_key(e):
            k = e.keysym
            if k == "Escape": self.close_game(); return "break"
            if not S["playing"] and k == "Return": restart(); return "break"
            if k in ("Up","Down","Left","Right"): move(k.lower())
        score_lbl = tk.Label(frame, text="Score: 0", bg="#0a0a0f", fg="#ffeb3b", font=("Consolas", 14, "bold"))
        score_lbl.pack()
        tk.Label(frame, text="Setas | ESC: sair", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 9)).pack(pady=5)
        self.root.bind("<KeyPress>", on_key)
        canvas.focus_set(); frame.focus_force()
        add_tile(); add_tile(); draw()

    def game_coin(self):
        frame, cv, W, H = self._game_canvas()
        S = {"side": "?", "heads": 0, "tails": 0}
        def draw():
            cv.delete("all")
            cv.create_text(W//2, H//3, text=S["side"], fill="#ffc107", font=("Segoe UI", 80, "bold"))
            cv.create_text(W//2, H//2, text="Cara: %d  Coroa: %d" % (S["heads"], S["tails"]), fill="white", font=("Segoe UI", 20))
            cv.create_text(W//2, H//2+80, text="ENTER: jogar | ESC: sair", fill="#7a7a8a")
        def flip():
            S["side"] = random.choice(["Cara", "Coroa"])
            S["heads" if S["side"]=="Cara" else "tails"] += 1
            draw(); snd("coin")
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym in ("Return","space"): flip()
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); draw()

    def game_dice(self):
        frame, cv, W, H = self._game_canvas()
        S = {"n": random.randint(1,6), "hist": []}
        def draw():
            cv.delete("all")
            cv.create_text(W//2, H//3, text=str(S["n"]), fill="#9c27b0", font=("Segoe UI", 120, "bold"))
            cv.create_text(W//2, H//2+30, text="Historico: " + " ".join(map(str, S["hist"][-10:])), fill="#7a7a8a", font=("Segoe UI", 14))
            cv.create_text(W//2, H//2+80, text="ENTER: rolar | ESC: sair", fill="#7a7a8a")
        def roll():
            S["n"] = random.randint(1,6); S["hist"].append(S["n"]); draw(); snd("coin")
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym in ("Return","space"): roll()
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); draw()

    def game_rps(self):
        frame = self.open_game_frame()
        fr = tk.Frame(frame, bg="#0a0a0f"); fr.pack(fill="both", expand=True)
        tk.Label(fr, text="JOKENPO", bg="#0a0a0f", fg="#2196f3", font=("Segoe UI", 24, "bold")).pack(pady=40)
        res = tk.Label(fr, text="Aperte 1, 2 ou 3", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 18))
        res.pack(pady=20)
        score = tk.Label(fr, text="0 x 0", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 16))
        score.pack()
        tk.Label(fr, text="1 = Pedra | 2 = Papel | 3 = Tesoura", bg="#0a0a0f", fg="#fff", font=("Segoe UI", 12)).pack(pady=10)
        S = {"w": 0, "l": 0}
        def play(choice):
            cpu = random.choice(["Pedra","Papel","Tesoura"])
            if choice == cpu: r = "Empate: " + choice + " vs " + cpu
            elif (choice=="Pedra" and cpu=="Tesoura") or (choice=="Papel" and cpu=="Pedra") or (choice=="Tesoura" and cpu=="Papel"):
                r = "Voce venceu! " + choice + " vs " + cpu; S["w"] += 1
            else: r = "CPU venceu! " + choice + " vs " + cpu; S["l"] += 1
            res.config(text=r); score.config(text="%d x %d" % (S["w"], S["l"])); snd("select")
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym == "1": play("Pedra")
            elif e.keysym == "2": play("Papel")
            elif e.keysym == "3": play("Tesoura")
        frame.bind("<KeyPress>", key)
        frame.focus_set(); frame.focus_force()
        tk.Label(fr, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=20)

    def game_reaction(self):
        frame, cv, W, H = self._game_canvas()
        S = {"state": "wait", "start": 0, "time": 0, "best": 9999}
        def draw():
            cv.delete("all")
            bg = {"wait":"#333", "ready":"#4caf50", "early":"#f44336", "done":"#0070e0"}[S["state"]]
            cv.create_rectangle(0,0,W,H,fill=bg,outline="")
            msgs = {"wait":"Aguarde o verde...", "ready":"APERTE ENTER AGORA!",
                    "early":"Cedo demais! ENTER", "done":"%.0f ms  Melhor: %d  ENTER" % (S["time"], S["best"])}
            cv.create_text(W//2, H//2, text=msgs[S["state"]], fill="white", font=("Segoe UI", 32, "bold"))
        def reset():
            S["state"] = "wait"; draw()
            def ready():
                if S["state"] == "wait":
                    S["state"] = "ready"; S["start"] = time.time()*1000; draw()
            frame.after(random.randint(1500, 4000), ready)
        def click(e=None):
            if S["state"] == "wait": S["state"] = "early"; draw()
            elif S["state"] == "ready":
                S["time"] = time.time()*1000 - S["start"]
                S["best"] = min(S["best"], int(S["time"]))
                S["state"] = "done"; draw()
            elif S["state"] in ("early","done"): reset()
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym in ("Return","space"): click()
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); reset()

    def game_pong(self):
        frame, cv, W, H = self._game_canvas()
        S = {"bx": W//2, "by": H//2, "vx": 5, "vy": 4, "py": H//2, "ay": H//2, "ps": 0, "as_": 0, "run": True}
        def draw():
            cv.delete("all")
            cv.create_line(W//2, 0, W//2, H, fill="#333", dash=(10,10))
            cv.create_rectangle(20, S["py"]-50, 30, S["py"]+50, fill="#00d4ff", outline="")
            cv.create_rectangle(W-30, S["ay"]-50, W-20, S["ay"]+50, fill="#ff3355", outline="")
            cv.create_oval(S["bx"]-10, S["by"]-10, S["bx"]+10, S["by"]+10, fill="white", outline="")
            cv.create_text(W//2, 30, text="%d - %d" % (S["ps"], S["as_"]), fill="white", font=("Consolas", 24, "bold"))
        def step():
            if not S["run"]: return
            S["bx"] += S["vx"]; S["by"] += S["vy"]
            if S["by"] < 15 or S["by"] > H-15: S["vy"] = -S["vy"]
            if S["bx"] < 30 and S["py"]-50 < S["by"] < S["py"]+50: S["vx"] = abs(S["vx"])
            if S["bx"] > W-30 and S["ay"]-50 < S["by"] < S["ay"]+50: S["vx"] = -abs(S["vx"])
            if S["bx"] < 0: S["as_"] += 1; S["bx"]=W//2; S["by"]=H//2
            if S["bx"] > W: S["ps"] += 1; S["bx"]=W//2; S["by"]=H//2
            if S["by"] > S["ay"]+20 and S["ay"] < H-60: S["ay"] += 5
            elif S["by"] < S["ay"]-20 and S["ay"] > 60: S["ay"] -= 5
            draw()
            try: frame.after(16, step)
            except: pass
        def key(e):
            k = e.keysym
            if k == "Escape": S["run"]=False; self.close_game(); return "break"
            if k in ("Up","w") and S["py"] > 60: S["py"] -= 30
            elif k in ("Down","s") and S["py"] < H-60: S["py"] += 30
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); step()

    def game_flappy(self):
        frame, cv, W, H = self._game_canvas()
        S = {"y": H//2, "vy": 0, "pipes": [], "score": 0, "alive": True, "playing": True, "t": 0}
        PW, GAP, SPD = 60, 150, 3
        def draw():
            cv.delete("all")
            cv.create_rectangle(0, 0, W, H, fill="#87ceeb", outline="")
            for p in S["pipes"]:
                cv.create_rectangle(p["x"], 0, p["x"]+PW, p["top"], fill="#4caf50", outline="")
                cv.create_rectangle(p["x"], p["top"]+GAP, p["x"]+PW, H, fill="#4caf50", outline="")
            cv.create_oval(60, S["y"]-15, 90, S["y"]+15, fill="#ffc107", outline="")
            cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["score"], fill="white", font=("Consolas", 14, "bold"))
            if not S["alive"]:
                cv.create_text(W//2, H//2-40, text="GAME OVER", fill="white", font=("Segoe UI", 36, "bold"))
                cv.create_text(W//2, H//2, text="Score: %d" % S["score"], fill="white", font=("Consolas", 24))
                cv.create_text(W//2, H//2+40, text="ENTER: de novo | ESC: sair", fill="white")
        def step():
            if not S["playing"] or not S["alive"]: return
            S["vy"] += 0.5; S["y"] += S["vy"]; S["t"] += 1
            if S["t"] % 90 == 0:
                S["pipes"].append({"x": W, "top": random.randint(80, H-80-GAP), "passed": False})
            for p in S["pipes"][:]:
                p["x"] -= SPD
                if p["x"] + PW < 0: S["pipes"].remove(p); continue
                if not p["passed"] and p["x"] + PW < 60: p["passed"] = True; S["score"] += 1
                if 45 < p["x"] < 105:
                    if S["y"]-15 < p["top"] or S["y"]+15 > p["top"]+GAP:
                        S["alive"] = False; snd("die"); self.end_game("flappy", S["score"])
            if S["y"] > H or S["y"] < 0:
                S["alive"] = False; snd("die"); self.end_game("flappy", S["score"])
            draw()
            try: frame.after(20, step)
            except: pass
        def flap():
            if S["alive"]: S["vy"] = -8
            else:
                S.update({"y": H//2, "vy": 0, "pipes": [], "score": 0, "alive": True, "t": 0}); step()
        def key(e):
            if e.keysym == "Escape": S["playing"]=False; self.close_game(); return "break"
            if e.keysym in ("Return","space","Up","w"): flap()
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); step()

    def game_math(self):
        frame, cv, W, H = self._game_canvas()
        S = {"a": 0, "b": 0, "op": "+", "ans": 0, "input": "", "score": 0, "time": 60, "playing": True}
        def newq():
            S["a"] = random.randint(1, 20); S["b"] = random.randint(1, 20)
            S["op"] = random.choice(["+", "-", "*"])
            S["ans"] = S["a"]+S["b"] if S["op"]=="+" else (S["a"]-S["b"] if S["op"]=="-" else S["a"]*S["b"])
            S["input"] = ""
        def draw():
            cv.delete("all")
            cv.create_rectangle(0,0,W,H,fill="#0a0a0f",outline="")
            cv.create_text(W-15, 20, anchor="e", text="Score: %d  Time: %ds" % (S["score"], int(S["time"])),
                           fill="#ffc107", font=("Consolas", 14, "bold"))
            cv.create_text(W//2, H//3, text="%d %s %d = ?" % (S["a"], S["op"], S["b"]), fill="white", font=("Segoe UI", 48, "bold"))
            cv.create_text(W//2, H//2+40, text=S["input"] or "_", fill="#00d4ff", font=("Consolas", 40, "bold"))
            if not S["playing"]:
                cv.create_text(W//2, H//2+120, text="FIM! Score: %d" % S["score"], fill="#4caf50", font=("Segoe UI", 28, "bold"))
                cv.create_text(W//2, H//2+170, text="ENTER: de novo | ESC: sair", fill="#7a7a8a")
        def submit():
            try:
                if int(S["input"]) == S["ans"]: S["score"] += 1; snd("coin"); newq()
                else: S["input"] = ""; snd("error")
            except: S["input"] = ""
            draw()
        def tick():
            if S["playing"] and S["time"] > 0:
                S["time"] -= 1
                if S["time"] <= 0: S["playing"] = False; self.end_game("math", S["score"])
                draw()
                try: frame.after(1000, tick)
                except: pass
        def key(e):
            k = e.keysym
            if k == "Escape": self.close_game(); return "break"
            if not S["playing"]:
                if k == "Return":
                    S.update({"score":0,"time":60,"playing":True}); newq(); draw(); tick()
                return
            if k.isdigit(): S["input"] += k; draw()
            elif k == "BackSpace": S["input"] = S["input"][:-1]; draw()
            elif k == "Return": submit()
        newq()
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); draw(); tick()

    def game_scramble(self):
        frame = self.open_game_frame()
        fr = tk.Frame(frame, bg="#0a0a0f"); fr.pack(fill="both", expand=True)
        words = ["PYTHON", "JOGO", "COMPUTADOR", "CODIGO", "TECLADO", "MOUSE", "JANELA",
                 "ARQUIVO", "MUSICA", "ESTRELA", "MONTANHA", "OCEANO", "FLORESTA"]
        S = {"word": "", "scrambled": "", "tries": 3, "score": 0}
        def next_word():
            S["word"] = random.choice(words)
            S["scrambled"] = "".join(random.sample(S["word"], len(S["word"])))
            while S["scrambled"] == S["word"]:
                S["scrambled"] = "".join(random.sample(S["word"], len(S["word"])))
            S["tries"] = 3
            word_lbl.config(text=S["scrambled"])
            tries_lbl.config(text="Tentativas: %d  |  Score: %d" % (S["tries"], S["score"]))
            entry.delete(0, "end")
        tk.Label(fr, text="SCRAMBLE", bg="#0a0a0f", fg="#8bc34a", font=("Segoe UI", 20, "bold")).pack(pady=15)
        word_lbl = tk.Label(fr, text="", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 40, "bold"))
        word_lbl.pack(pady=20)
        tries_lbl = tk.Label(fr, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 12))
        tries_lbl.pack()
        entry = tk.Entry(fr, bg="#1a1a24", fg="white", insertbackground="white",
                         font=("Segoe UI", 18), relief="flat", justify="center")
        entry.pack(fill="x", padx=60, pady=20, ipady=8)
        msg = tk.Label(fr, text="", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 12, "bold"))
        msg.pack()
        def check(e=None):
            if entry.get().upper().strip() == S["word"]:
                S["score"] += 1; msg.config(text="ACERTOU!", fg="#4caf50")
                snd("coin"); fr.after(800, next_word)
            else:
                S["tries"] -= 1
                if S["tries"] <= 0:
                    msg.config(text="Era: " + S["word"], fg="#f44336")
                    snd("error"); fr.after(1500, next_word)
                else:
                    tries_lbl.config(text="Tentativas: %d  |  Score: %d" % (S["tries"], S["score"]))
                    snd("error")
            entry.delete(0, "end")
        entry.bind("<Return>", check)
        entry.focus_set()
        tk.Label(fr, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=15)
        next_word()
        frame.bind("<Escape>", lambda e: self.close_game())

    def game_memory(self):
        frame = self.open_game_frame()
        fr = tk.Frame(frame, bg="#0a0a0f"); fr.pack(fill="both", expand=True)
        syms = ["A","B","C","D","E","F","G","H"] * 2
        random.shuffle(syms)
        S = {"rev": [], "mat": set(), "btns": []}
        status = tk.Label(fr, text="Ache os pares!", bg="#0a0a0f", fg="#fff", font=("Segoe UI", 14, "bold"))
        status.pack(pady=10)
        g = tk.Frame(fr, bg="#0a0a0f"); g.pack()
        def unres():
            try:
                for i in S["rev"]: S["btns"][i].config(text="?", bg="#1e1e2a")
                S["rev"] = []
            except: pass
        def flip(i):
            if i in S["mat"] or i in S["rev"]: return
            S["rev"].append(i); S["btns"][i].config(text=syms[i], bg="#9c27b0")
            if len(S["rev"]) == 2:
                a, b = S["rev"][0], S["rev"][1]
                if syms[a] == syms[b]:
                    S["mat"].add(a); S["mat"].add(b); S["rev"] = []
                    status.config(text="Par! %d/8" % (len(S["mat"])//2))
                    if len(S["mat"]) == 16: status.config(text="Vitoria!"); snd("coin")
                else:
                    frame.after(600, unres)
        for i in range(16):
            b = tk.Button(g, text="?", bg="#1e1e2a", fg="white", font=("Segoe UI", 20, "bold"),
                          width=4, height=2, relief="flat", command=lambda i=i: flip(i))
            b.grid(row=i//4, column=i%4, padx=3, pady=3)
            S["btns"].append(b)
        tk.Label(fr, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
        frame.bind("<Escape>", lambda e: self.close_game())

    def game_hangman(self):
        frame = self.open_game_frame()
        fr = tk.Frame(frame, bg="#0a0a0f"); fr.pack(fill="both", expand=True)
        words = ["PYTHON", "COMPUTADOR", "TECLADO", "PROGRAMAR", "ESTRELA", "MONTANHA", "FLORESTA", "ELEFANTE"]
        S = {"word": random.choice(words), "guessed": set(), "errors": 0}
        tk.Label(fr, text="HANGMAN", bg="#0a0a0f", fg="#e91e63", font=("Segoe UI", 20, "bold")).pack(pady=15)
        word_lbl = tk.Label(fr, text="", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 32, "bold"))
        word_lbl.pack(pady=20)
        status = tk.Label(fr, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 11))
        status.pack()
        def update():
            d = " ".join([c if c in S["guessed"] else "_" for c in S["word"]])
            word_lbl.config(text=d)
            status.config(text="Erros: %d/6  |  Letras: %s" % (S["errors"], " ".join(sorted(S["guessed"]))))
            if "_" not in d: word_lbl.config(text="VITORIA! " + S["word"], fg="#4caf50"); snd("coin")
            elif S["errors"] >= 6: word_lbl.config(text="PERDEU! Era " + S["word"], fg="#f44336"); snd("die")
        def on_key(e):
            k = e.keysym.upper()
            if e.keysym == "Escape": self.close_game(); return "break"
            if len(k) == 1 and k.isalpha() and k not in S["guessed"]:
                S["guessed"].add(k)
                if k not in S["word"]: S["errors"] += 1; snd("error")
                else: snd("coin")
                update()
        self.root.bind("<KeyPress>", on_key)
        frame.focus_force(); update()

    def game_whack(self):
        frame = self.open_game_frame()
        fr = tk.Frame(frame, bg="#0a0a0f"); fr.pack(fill="both", expand=True)
        tk.Label(fr, text="WHACK-A-MOLE", bg="#0a0a0f", fg="#795548", font=("Segoe UI", 20, "bold")).pack(pady=10)
        score_lbl = tk.Label(fr, text="Score: 0", bg="#0a0a0f", fg="#ffc107", font=("Consolas", 16, "bold"))
        score_lbl.pack()
        S = {"score": 0, "playing": True}
        g = tk.Frame(fr, bg="#0a0a0f"); g.pack(pady=10)
        btns = []
        for r in range(3):
            row = []
            for c in range(3):
                b = tk.Button(g, text="", bg="#3a2a1a", fg="white", font=("Segoe UI", 24, "bold"),
                              width=4, height=2, relief="flat", state="disabled")
                b.grid(row=r, column=c, padx=5, pady=5)
                row.append(b)
            btns.append(row)
        def spawn():
            if not S["playing"]: return
            for r in range(3):
                for c in range(3):
                    btns[r][c].config(text="", bg="#3a2a1a", state="disabled")
            for _ in range(2):
                r, c = random.randint(0,2), random.randint(0,2)
                btns[r][c].config(text="M", bg="#795548", state="normal",
                                  command=lambda r=r,c=c: hit(r,c))
            frame.after(max(600, 1500 - S["score"]*100), spawn)
        def hit(r, c):
            if btns[r][c]["state"] == "normal":
                S["score"] += 1; score_lbl.config(text="Score: %d" % S["score"])
                btns[r][c].config(text="X", bg="#4caf50", state="disabled")
                snd("hit"); self.end_game("whack", S["score"])
        spawn()
        tk.Label(fr, text="Clique nos M! ESC sai", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
        frame.bind("<Escape>", lambda e: (S.__setitem__("playing", False), self.close_game()))

    def game_simon(self):
        frame = self.open_game_frame()
        fr = tk.Frame(frame, bg="#0a0a0f"); fr.pack(fill="both", expand=True)
        tk.Label(fr, text="SIMON", bg="#0a0a0f", fg="#ff5722", font=("Segoe UI", 20, "bold")).pack(pady=10)
        S = {"seq": [], "player": []}
        status = tk.Label(fr, text="Aperte ENTER para comecar", bg="#0a0a0f", fg="white", font=("Segoe UI", 14, "bold"))
        status.pack(pady=5)
        colors = ["#00d4ff", "#4caf50", "#ff9800", "#f44336"]
        g = tk.Frame(fr, bg="#0a0a0f"); g.pack(pady=10)
        btns = []
        def flash(i, dur=300):
            b = btns[i]; b.config(bg="white")
            frame.after(dur, lambda: b.config(bg=colors[i]))
        def show_seq():
            for i, idx in enumerate(S["seq"]):
                frame.after(500 + i*700, lambda ix=idx: flash(ix))
            frame.after(500 + len(S["seq"])*700 + 500, lambda: status.config(text="Digite 1, 2, 3 ou 4"))
        def start():
            S["seq"] = [random.randint(0,3)]; S["player"] = []
            status.config(text="Observe..."); show_seq(); snd("select")
        def click(i):
            if not S["seq"]: return
            flash(i, 150); S["player"].append(i); snd("click")
            if S["player"] != S["seq"][:len(S["player"])]:
                status.config(text="ERROU! Score: %d - ENTER para reiniciar" % (len(S["seq"])-1))
                snd("error"); S["seq"] = []; return
            if len(S["player"]) == len(S["seq"]):
                S["seq"].append(random.randint(0,3)); S["player"] = []
                status.config(text="Acertou! Nivel %d" % len(S["seq"]))
                snd("coin"); frame.after(800, show_seq)
        for i in range(4):
            b = tk.Button(g, bg=colors[i], width=8, height=3, relief="flat",
                          command=lambda i=i: click(i))
            b.grid(row=i//2, column=i%2, padx=5, pady=5)
            btns.append(b)
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym == "Return":
                if not S["seq"]: start()
                else: start()  # reinicia
            elif e.keysym in ("1","2","3","4"):
                click(int(e.keysym)-1)
        self.root.bind("<KeyPress>", key)
        frame.focus_set(); frame.focus_force()

    def game_tictac(self):
        frame = self.open_game_frame()
        fr = tk.Frame(frame, bg="#0a0a0f"); fr.pack(fill="both", expand=True)
        tk.Label(fr, text="TIC TAC TOE", bg="#0a0a0f", fg="#607d8b", font=("Segoe UI", 20, "bold")).pack(pady=10)
        S = {"board": [""]*9, "over": False, "cursor": 0}
        status = tk.Label(fr, text="Use 1-9 para jogar | ENTER confirma", bg="#0a0a0f", fg="white", font=("Segoe UI", 12, "bold"))
        status.pack(pady=5)
        g = tk.Frame(fr, bg="#0a0a0f"); g.pack()
        btns = []
        def check_win(b):
            wins = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
            for a,c1,c2 in wins:
                if b[a] and b[a]==b[c1]==b[c2]: return b[a]
            return "Empate" if "" not in b else None
        def ai_move():
            b = S["board"]
            for i in range(9):
                if b[i] == "":
                    b[i] = "O"
                    if check_win(b) == "O": return i
                    b[i] = ""
            for i in range(9):
                if b[i] == "":
                    b[i] = "X"
                    if check_win(b) == "X": b[i] = ""; return i
                    b[i] = ""
            if b[4] == "": return 4
            for i in [0,2,6,8]:
                if b[i] == "": return i
            for i in range(9):
                if b[i] == "": return i
            return None
        def click(i):
            if S["over"] or S["board"][i]: return
            S["board"][i] = "X"; btns[i].config(text="X", fg="#00d4ff")
            snd("click")
            w = check_win(S["board"])
            if w: status.config(text="Voce venceu!" if w=="X" else "Empate"); S["over"] = True; snd("coin"); return
            ai = ai_move()
            if ai is not None:
                S["board"][ai] = "O"; btns[ai].config(text="O", fg="#e91e63")
                w = check_win(S["board"])
                if w: status.config(text="CPU venceu!" if w=="O" else "Empate"); S["over"] = True; snd("error"); return
            status.config(text="Use 1-9 para jogar")
        for i in range(9):
            b = tk.Button(g, text="", bg="#1e1e2a", fg="white", font=("Segoe UI", 24, "bold"),
                          width=4, height=2, relief="flat", command=lambda i=i: click(i))
            b.grid(row=i//3, column=i%3, padx=3, pady=3)
            btns.append(b)
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym.isdigit():
                n = int(e.keysym) - 1
                if 0 <= n <= 8: click(n)
        self.root.bind("<KeyPress>", key)
        frame.focus_set(); frame.focus_force()
        tk.Label(fr, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)

    def game_stack(self):
        frame, cv, W, H = self._game_canvas()
        S = {"blocks": [], "cur": {"x": W//2-80, "w": 160, "y": H-80}, "dir": 1, "speed": 6, "score": 0, "playing": True}
        def draw():
            cv.delete("all")
            cv.create_rectangle(0, 0, W, H, fill="#0a0a0f", outline="")
            for b in S["blocks"]:
                cv.create_rectangle(b["x"], b["y"], b["x"]+b["w"], b["y"]+20, fill="#ff5722", outline="white")
            c = S["cur"]
            cv.create_rectangle(c["x"], c["y"], c["x"]+c["w"], c["y"]+20, fill="#00d4ff", outline="white")
            cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["score"], fill="white", font=("Consolas", 14, "bold"))
            cv.create_text(W//2, H-10, text="ENTER/ESPACO para soltar | ESC sair", fill="#7a7a8a", font=("Segoe UI", 10))
            if not S["playing"]:
                cv.create_text(W//2, H//2, text="GAME OVER\nScore: %d" % S["score"],
                               fill="#ff3355", font=("Segoe UI", 28, "bold"), justify="center")
        def step():
            if not S["playing"]: return
            c = S["cur"]
            c["x"] += S["dir"] * S["speed"]
            if c["x"] <= 0 or c["x"] + c["w"] >= W: S["dir"] = -S["dir"]
            draw()
            try: frame.after(30, step)
            except: pass
        def drop():
            if not S["playing"]: return
            c = S["cur"]
            if S["blocks"]:
                last = S["blocks"][-1]
                left = max(c["x"], last["x"]); right = min(c["x"]+c["w"], last["x"]+last["w"])
                if right <= left: S["playing"] = False; snd("die"); draw(); return
                c["x"] = left; c["w"] = right - left
            S["blocks"].append({"x": c["x"], "w": c["w"], "y": c["y"]})
            S["score"] += 1; snd("click")
            if S["score"] % 3 == 0: S["speed"] += 1
            S["cur"] = {"x": W//2-80, "w": 160, "y": c["y"]-22}
            draw()
        def key(e):
            if e.keysym == "Escape": S["playing"]=False; self.close_game(); return "break"
            if e.keysym in ("space", "Return"): drop()
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); step()

    def game_dino(self):
        frame, cv, W, H = self._game_canvas()
        S = {"y": H-100, "vy": 0, "obs": [], "score": 0, "alive": True, "t": 0, "spd": 6}
        def draw():
            cv.delete("all")
            cv.create_rectangle(0, 0, W, H, fill="#f7f7f7", outline="")
            cv.create_rectangle(0, H-60, W, H, fill="#c5c5c5", outline="")
            for o in S["obs"]:
                cv.create_rectangle(o["x"], H-100, o["x"]+30, H-60, fill="#333", outline="")
            cv.create_rectangle(60, S["y"], 100, S["y"]+40, fill="#333", outline="")
            cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["score"], fill="#333", font=("Consolas", 14, "bold"))
            cv.create_text(W//2, 20, text="ESPACO/ENTER para pular", fill="#666", font=("Segoe UI", 10))
            if not S["alive"]:
                cv.create_rectangle(0,0,W,H,fill="#000",outline="")
                cv.create_text(W//2, H//2, text="GAME OVER\n%d" % S["score"], fill="#fff", font=("Segoe UI", 28, "bold"), justify="center")
                cv.create_text(W//2, H//2+80, text="ENTER/espaco: de novo | ESC: sair", fill="#7a7a8a")
        def step():
            if not S["alive"]: return
            S["t"] += 1; S["y"] += S["vy"]; S["vy"] += 0.5
            if S["y"] > H-100: S["y"] = H-100; S["vy"] = 0
            if S["t"] % 80 == 0: S["obs"].append({"x": W})
            for o in S["obs"][:]:
                o["x"] -= S["spd"]
                if o["x"]+30 < 0: S["obs"].remove(o); S["score"] += 1; continue
                if o["x"] < 100 and o["x"]+30 > 60 and S["y"]+40 > H-100:
                    S["alive"] = False; snd("die"); self.end_game("dino", S["score"])
            S["spd"] = 6 + S["score"] // 5
            draw()
            try: frame.after(30, step)
            except: pass
        def jump(e=None):
            if S["alive"] and S["y"] >= H-100: S["vy"] = -14
            elif not S["alive"]:
                S.update({"y": H-100, "vy": 0, "obs": [], "score": 0, "alive": True, "t": 0}); step()
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym in ("space", "Up", "Return"): jump()
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); step()

    def game_breakout(self):
        frame, cv, W, H = self._game_canvas()
        S = {"bx": W//2, "by": H-100, "vx": 5, "vy": -5, "px": W//2, "blocks": [], "score": 0, "alive": True}
        def make_blocks():
            S["blocks"] = []
            for r in range(5):
                for c in range(10):
                    S["blocks"].append({"x": c*80+20, "y": r*30+80, "w": 70, "h": 25,
                                         "color": ["#f44336","#ff9800","#ffc107","#4caf50","#2196f3"][r]})
        make_blocks()
        def draw():
            cv.delete("all")
            cv.create_rectangle(0, 0, W, H, fill="#0a0a0f", outline="")
            for b in S["blocks"]:
                cv.create_rectangle(b["x"], b["y"], b["x"]+b["w"], b["y"]+b["h"], fill=b["color"], outline="")
            cv.create_rectangle(S["px"]-60, H-40, S["px"]+60, H-25, fill="#00d4ff", outline="")
            cv.create_oval(S["bx"]-8, S["by"]-8, S["bx"]+8, S["by"]+8, fill="white", outline="")
            cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["score"], fill="#fff", font=("Consolas", 14, "bold"))
            cv.create_text(W//2, H-10, text="SETAS ESQ/DIR para mover | ESC sair", fill="#7a7a8a", font=("Segoe UI", 10))
            if not S["alive"]:
                cv.create_text(W//2, H//2, text="GAME OVER\n%d" % S["score"], fill="#ff3355", font=("Segoe UI", 28, "bold"), justify="center")
        def step():
            if not S["alive"]: return
            S["bx"] += S["vx"]; S["by"] += S["vy"]
            if S["bx"] < 10 or S["bx"] > W-10: S["vx"] = -S["vx"]
            if S["by"] < 10: S["vy"] = -S["vy"]
            if S["by"] > H-40 and S["px"]-60 < S["bx"] < S["px"]+60: S["vy"] = -abs(S["vy"]); snd("hit")
            if S["by"] > H: S["alive"] = False; snd("die"); self.end_game("breakout", S["score"])
            for b in S["blocks"][:]:
                if b["x"] < S["bx"] < b["x"]+b["w"] and b["y"] < S["by"] < b["y"]+b["h"]:
                    S["blocks"].remove(b); S["score"] += 10; snd("hit"); S["vy"] = -S["vy"]; break
            if not S["blocks"]: S["alive"] = False; snd("coin"); self.end_game("breakout", S["score"])
            draw()
            try: frame.after(16, step)
            except: pass
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym == "Left": S["px"] = max(60, S["px"]-40)
            elif e.keysym == "Right": S["px"] = min(W-60, S["px"]+40)
            elif not S["alive"] and e.keysym == "Return":
                S["bx"]=W//2; S["by"]=H-100; S["vx"]=5; S["vy"]=-5; S["score"]=0; S["alive"]=True
                make_blocks(); step()
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); step()

    def game_asteroids(self):
        frame, cv, W, H = self._game_canvas()
        S = {"px": W//2, "py": H//2, "ang": 0, "vx": 0, "vy": 0,
             "bullets": [], "ast": [], "score": 0, "alive": True, "keys": set()}
        for _ in range(5):
            S["ast"].append({"x": random.randint(0, W), "y": random.randint(0, H),
                              "vx": random.uniform(-2, 2), "vy": random.uniform(-2, 2),
                              "r": random.randint(20, 40)})
        def draw():
            cv.delete("all")
            cv.create_rectangle(0, 0, W, H, fill="#0a0a0f", outline="")
            for a in S["ast"]:
                cv.create_oval(a["x"]-a["r"], a["y"]-a["r"], a["x"]+a["r"], a["y"]+a["r"],
                                fill="#888", outline="#666", width=2)
            for b in S["bullets"]:
                cv.create_oval(b["x"]-3, b["y"]-3, b["x"]+3, b["y"]+3, fill="white", outline="")
            if S["alive"]:
                px, py, ang = S["px"], S["py"], S["ang"]
                pts = [(px+20*math.cos(ang), py+20*math.sin(ang)),
                       (px+15*math.cos(ang+2.5), py+15*math.sin(ang+2.5)),
                       (px+15*math.cos(ang-2.5), py+15*math.sin(ang-2.5))]
                cv.create_polygon(pts, fill="#00d4ff", outline="white")
            cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["score"], fill="#fff", font=("Consolas", 14, "bold"))
            cv.create_text(W//2, H-10, text="SETAS: girar/mover | ESPACO: atirar | ESC: sair", fill="#7a7a8a", font=("Segoe UI", 10))
            if not S["alive"]:
                cv.create_text(W//2, H//2, text="GAME OVER\n%d" % S["score"], fill="#ff3355", font=("Segoe UI", 28, "bold"), justify="center")
        def step():
            if not S["alive"]: return
            k = S["keys"]
            if "Left" in k or "a" in k: S["ang"] -= 0.15
            if "Right" in k or "d" in k: S["ang"] += 0.15
            if "Up" in k or "w" in k:
                S["vx"] += 0.3 * math.cos(S["ang"]); S["vy"] += 0.3 * math.sin(S["ang"])
            S["px"] += S["vx"]; S["py"] += S["vy"]
            S["vx"] *= 0.98; S["vy"] *= 0.98
            if S["px"] < 0: S["px"] = W
            if S["px"] > W: S["px"] = 0
            if S["py"] < 0: S["py"] = H
            if S["py"] > H: S["py"] = 0
            for a in S["ast"]:
                a["x"] += a["vx"]; a["y"] += a["vy"]
                if a["x"] < 0 or a["x"] > W: a["vx"] = -a["vx"]
                if a["y"] < 0 or a["y"] > H: a["vy"] = -a["vy"]
                if math.sqrt((a["x"]-S["px"])**2 + (a["y"]-S["py"])**2) < a["r"] + 15:
                    S["alive"] = False; snd("die"); self.end_game("asteroids", S["score"])
            for b in S["bullets"][:]:
                b["x"] += b["vx"]; b["y"] += b["vy"]; b["life"] -= 1
                if b["life"] <= 0 or b["x"] < 0 or b["x"] > W or b["y"] < 0 or b["y"] > H:
                    S["bullets"].remove(b); continue
                for a in S["ast"][:]:
                    if math.sqrt((a["x"]-b["x"])**2 + (a["y"]-b["y"])**2) < a["r"]:
                        if a in S["ast"]: S["ast"].remove(a)
                        if b in S["bullets"]: S["bullets"].remove(b)
                        S["score"] += 20; snd("hit")
                        if a["r"] > 25:
                            for _ in range(2):
                                S["ast"].append({"x": a["x"], "y": a["y"],
                                                  "vx": random.uniform(-3, 3), "vy": random.uniform(-3, 3),
                                                  "r": a["r"]//2})
                        break
            if not S["ast"]:
                for _ in range(5):
                    S["ast"].append({"x": random.randint(0, W), "y": random.randint(0, H),
                                      "vx": random.uniform(-2, 2), "vy": random.uniform(-2, 2),
                                      "r": random.randint(20, 40)})
            draw()
            try: frame.after(16, step)
            except: pass
        def on_key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym == "space":
                S["bullets"].append({"x": S["px"], "y": S["py"],
                                      "vx": 8*math.cos(S["ang"]), "vy": 8*math.sin(S["ang"]), "life": 60})
                snd("shoot")
            S["keys"].add(e.keysym)
        def on_kr(e):
            try: S["keys"].discard(e.keysym)
            except: pass
        self.root.bind("<KeyPress>", on_key)
        self.root.bind("<KeyRelease>", on_kr)
        cv.focus_set(); frame.focus_force(); step()

    def game_tetris(self):
        frame, cv, W, H = self._game_canvas()
        S = {"grid": [[0]*10 for _ in range(20)], "piece": None, "px": 4, "py": 0,
             "color": 0, "score": 0, "alive": True, "speed": 500, "last": 0}
        shapes = [
            [[1,1,1,1]],
            [[1,1],[1,1]],
            [[0,1,0],[1,1,1]],
            [[1,0,0],[1,1,1]],
            [[0,0,1],[1,1,1]],
            [[0,1,1],[1,1,0]],
            [[1,1,0],[0,1,1]],
        ]
        colors = ["#00d4ff", "#ffc107", "#9c27b0", "#ff9800", "#2196f3", "#4caf50", "#f44336"]
        def new_piece():
            i = random.randint(0, len(shapes)-1)
            S["piece"] = [row[:] for row in shapes[i]]
            S["color"] = i
            S["px"] = 4; S["py"] = 0
            if not can_place(S["piece"], S["px"], S["py"]):
                S["alive"] = False; snd("die"); self.end_game("tetris", S["score"])
        def can_place(shape, px, py):
            for r, row in enumerate(shape):
                for c, v in enumerate(row):
                    if v:
                        x, y = px + c, py + r
                        if x < 0 or x >= 10 or y >= 20: return False
                        if y >= 0 and S["grid"][y][x]: return False
            return True
        def place():
            for r, row in enumerate(S["piece"]):
                for c, v in enumerate(row):
                    if v:
                        y = S["py"] + r
                        if y >= 0: S["grid"][y][S["px"]+c] = S["color"] + 1
            cleared = 0
            for y in range(19, -1, -1):
                if all(S["grid"][y]):
                    S["grid"].pop(y); S["grid"].insert(0, [0]*10)
                    cleared += 1
            if cleared:
                S["score"] += cleared * 100
                snd("coin")
                if cleared >= 4: snd("buy")
            new_piece()
        def draw():
            cv.delete("all")
            cv.create_rectangle(0, 0, W, H, fill="#0a0a0f", outline="")
            cs = 28; ox = (W - 10*cs) // 2; oy = 40
            for y in range(20):
                for x in range(10):
                    v = S["grid"][y][x]
                    if v:
                        cv.create_rectangle(ox+x*cs, oy+y*cs, ox+(x+1)*cs, oy+(y+1)*cs,
                                            fill=colors[v-1], outline="#333")
                    else:
                        cv.create_rectangle(ox+x*cs, oy+y*cs, ox+(x+1)*cs, oy+(y+1)*cs,
                                            fill="#1a1a24", outline="#222")
            if S["piece"] and S["alive"]:
                for r, row in enumerate(S["piece"]):
                    for c, v in enumerate(row):
                        if v:
                            y = S["py"] + r; x = S["px"] + c
                            if y >= 0:
                                cv.create_rectangle(ox+x*cs, oy+y*cs, ox+(x+1)*cs, oy+(y+1)*cs,
                                                    fill=colors[S["color"]], outline="#fff")
            cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["score"], fill="#fff", font=("Consolas", 14, "bold"))
            cv.create_text(W//2, 20, text="TETRIS", fill="#3f51b5", font=("Segoe UI", 14, "bold"))
            cv.create_text(W//2, H-10, text="SETAS mover | CIMA girar | ESPACO drop | ESC sair", fill="#7a7a8a", font=("Segoe UI", 10))
            if not S["alive"]:
                cv.create_text(W//2, H//2, text="GAME OVER\n%d" % S["score"], fill="#ff3355", font=("Segoe UI", 28, "bold"), justify="center")
                cv.create_text(W//2, H//2+80, text="ENTER: de novo | ESC: sair", fill="#7a7a8a")
        def tick():
            if not S["alive"]: return
            if time.time()*1000 - S["last"] > S["speed"]:
                S["last"] = time.time()*1000
                if can_place(S["piece"], S["px"], S["py"]+1): S["py"] += 1
                else: place()
            draw()
            try: frame.after(50, tick)
            except: pass
        def key(e):
            k = e.keysym
            if k == "Escape": self.close_game(); return "break"
            if not S["alive"] and k == "Return":
                S["grid"] = [[0]*10 for _ in range(20)]; S["score"] = 0; S["alive"] = True
                new_piece(); tick(); return "break"
            if not S["alive"]: return
            if k == "Left" and can_place(S["piece"], S["px"]-1, S["py"]): S["px"] -= 1
            elif k == "Right" and can_place(S["piece"], S["px"]+1, S["py"]): S["px"] += 1
            elif k == "Down" and can_place(S["piece"], S["px"], S["py"]+1): S["py"] += 1
            elif k == "space":
                while can_place(S["piece"], S["px"], S["py"]+1): S["py"] += 1
                place()
            elif k == "Up":
                old = S["piece"]
                new = [list(row) for row in zip(*old[::-1])]
                if can_place(new, S["px"], S["py"]): S["piece"] = new
            draw()
        new_piece()
        S["last"] = time.time()*1000
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); tick()

    def game_minesweeper(self):
        frame, cv, W, H = self._game_canvas()
        SIZE = 10; MINES = 15
        S = {"grid": [["" for _ in range(SIZE)] for _ in range(SIZE)],
             "revealed": set(), "flags": set(), "started": False, "alive": True, "score": 0, "cursor": [0,0]}
        def place_mines(safe_r, safe_c):
            placed = 0
            while placed < MINES:
                r, c = random.randint(0, SIZE-1), random.randint(0, SIZE-1)
                if (r, c) == (safe_r, safe_c) or S["grid"][r][c] == "M": continue
                S["grid"][r][c] = "M"; placed += 1
            for r in range(SIZE):
                for c in range(SIZE):
                    if S["grid"][r][c] != "M":
                        cnt = 0
                        for dr in (-1, 0, 1):
                            for dc in (-1, 0, 1):
                                nr, nc = r+dr, c+dc
                                if 0 <= nr < SIZE and 0 <= nc < SIZE and S["grid"][nr][nc] == "M":
                                    cnt += 1
                        S["grid"][r][c] = cnt
        def reveal(r, c):
            if not S["alive"]: return
            if not S["started"]:
                place_mines(r, c); S["started"] = True
            if (r, c) in S["revealed"] or (r, c) in S["flags"]: return
            if S["grid"][r][c] == "M":
                S["alive"] = False; snd("die"); self.end_game("minesweeper", S["score"]); return
            S["revealed"].add((r, c)); S["score"] += 10
            if S["grid"][r][c] == 0:
                for dr in (-1, 0, 1):
                    for dc in (-1, 0, 1):
                        nr, nc = r+dr, c+dc
                        if 0 <= nr < SIZE and 0 <= nc < SIZE:
                            reveal(nr, nc)
        def draw():
            cv.delete("all")
            cv.create_rectangle(0, 0, W, H, fill="#0a0a0f", outline="")
            cs = min(W, H-100) // SIZE - 2
            ox = (W - SIZE*cs) // 2; oy = 50
            for r in range(SIZE):
                for c in range(SIZE):
                    x, y = ox+c*cs, oy+r*cs
                    if (r, c) in S["revealed"]:
                        v = S["grid"][r][c]
                        fill = "#333"
                        txt = "" if v == 0 else str(v)
                        tc = ["#00d4ff","#4caf50","#ff3355","#9c27b0","#ff9800","#ffc107","#607d8b","#fff"]
                        if v != "M": color = tc[v-1] if v > 0 else "#fff"
                        else: color = "#ff3355"; txt = "M"
                        cv.create_rectangle(x, y, x+cs, y+cs, fill=fill, outline="#222")
                        cv.create_text(x+cs//2, y+cs//2, text=txt, fill=color, font=("Consolas", 12, "bold"))
                    else:
                        fill = "#555" if (r, c) in S["flags"] else "#1e1e2a"
                        cv.create_rectangle(x, y, x+cs, y+cs, fill=fill, outline="#444")
                        if (r, c) in S["flags"]:
                            cv.create_text(x+cs//2, y+cs//2, text="F", fill="red", font=("Consolas", 12, "bold"))
            # Cursor
            cr, cc = S["cursor"]
            cv.create_rectangle(ox+cc*cs, oy+cr*cs, ox+(cc+1)*cs, oy+(cr+1)*cs,
                                outline="#00d4ff", width=3)
            cv.create_text(W//2, 20, text="MINESWEEPER", fill="#9e9e9e", font=("Segoe UI", 14, "bold"))
            cv.create_text(W//2, H-30, text="SETAS mover | ENTER revelar | F bandeira | ESC sair", fill="#7a7a8a", font=("Segoe UI", 10))
            if not S["alive"]:
                cv.create_text(W//2, H//2, text="BOOM! GAME OVER", fill="#ff3355", font=("Segoe UI", 28, "bold"))
        def key(e):
            k = e.keysym
            if k == "Escape": self.close_game(); return "break"
            r, c = S["cursor"]
            if k == "Up" and r > 0: S["cursor"] = [r-1, c]
            elif k == "Down" and r < SIZE-1: S["cursor"] = [r+1, c]
            elif k == "Left" and c > 0: S["cursor"] = [r, c-1]
            elif k == "Right" and c < SIZE-1: S["cursor"] = [r, c+1]
            elif k == "Return": reveal(r, c)
            elif k.lower() == "f":
                if (r, c) in S["flags"]: S["flags"].remove((r, c))
                elif (r, c) not in S["revealed"]: S["flags"].add((r, c))
            draw()
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); draw()

    def game_maze(self):
        frame, cv, W, H = self._game_canvas()
        COLS, ROWS = 15, 11
        maze = [[1 for _ in range(COLS*2+1)] for _ in range(ROWS*2+1)]
        visited = [[False]*COLS for _ in range(ROWS)]
        def carve(r, c):
            visited[r][c] = True
            maze[r*2+1][c*2+1] = 0
            dirs = [(0,1),(0,-1),(1,0),(-1,0)]
            random.shuffle(dirs)
            for dr, dc in dirs:
                nr, nc = r+dr, c+dc
                if 0 <= nr < ROWS and 0 <= nc < COLS and not visited[nr][nc]:
                    maze[r*2+1+dr][c*2+1+dc] = 0
                    carve(nr, nc)
        carve(0, 0)
        maze[ROWS*2-1][COLS*2-1] = 0
        S = {"x": 1, "y": 1}
        def draw():
            cv.delete("all")
            cv.create_rectangle(0, 0, W, H, fill="#0a0a0f", outline="")
            cell = min(W // (COLS*2+1), (H-60) // (ROWS*2+1))
            ox = (W - cell*(COLS*2+1)) // 2; oy = 50
            for r in range(ROWS*2+1):
                for c in range(COLS*2+1):
                    if maze[r][c]:
                        cv.create_rectangle(ox+c*cell, oy+r*cell, ox+(c+1)*cell, oy+(r+1)*cell,
                                            fill="#333", outline="")
                    else:
                        cv.create_rectangle(ox+c*cell, oy+r*cell, ox+(c+1)*cell, oy+(r+1)*cell,
                                            fill="#0f0f15", outline="")
            cv.create_oval(ox+S["x"]*cell+3, oy+S["y"]*cell+3, ox+(S["x"]+1)*cell-3, oy+(S["y"]+1)*cell-3,
                            fill="#00d4ff", outline="")
            cv.create_rectangle(ox+(COLS*2-1)*cell, oy+(ROWS*2-1)*cell, ox+(COLS*2)*cell, oy+(ROWS*2)*cell,
                                fill="#4caf50", outline="")
            cv.create_text(W//2, 20, text="MAZE", fill="#4caf50", font=("Segoe UI", 14, "bold"))
            cv.create_text(W//2, H-20, text="SETAS mover | ESC sair", fill="#7a7a8a", font=("Segoe UI", 10))
            if S["x"] == COLS*2-1 and S["y"] == ROWS*2-1:
                cv.create_text(W//2, 50, text="VITORIA!", fill="#4caf50", font=("Segoe UI", 24, "bold"))
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            dx, dy = 0, 0
            if e.keysym == "Up": dy = -1
            elif e.keysym == "Down": dy = 1
            elif e.keysym == "Left": dx = -1
            elif e.keysym == "Right": dx = 1
            nx, ny = S["x"]+dx, S["y"]+dy
            if 0 <= ny < ROWS*2+1 and 0 <= nx < COLS*2+1 and maze[ny][nx] == 0:
                S["x"] = nx; S["y"] = ny; draw()
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); draw()

    def game_invaders(self):
        frame, cv, W, H = self._game_canvas()
        S = {"px": W//2, "bullets": [], "enemies": [], "ebullets": [], "score": 0, "alive": True, "t": 0}
        for r in range(4):
            for c in range(8):
                S["enemies"].append({"x": 100+c*80, "y": 80+r*50, "alive": True})
        def draw():
            cv.delete("all")
            cv.create_rectangle(0, 0, W, H, fill="#0a0a0f", outline="")
            for e in S["enemies"]:
                if e["alive"]:
                    cv.create_rectangle(e["x"]-15, e["y"]-10, e["x"]+15, e["y"]+10, fill="#673ab7", outline="")
                    cv.create_oval(e["x"]-6, e["y"]-5, e["x"]-2, e["y"]-1, fill="white", outline="")
                    cv.create_oval(e["x"]+2, e["y"]-5, e["x"]+6, e["y"]-1, fill="white", outline="")
            for b in S["bullets"]:
                cv.create_rectangle(b["x"]-2, b["y"]-6, b["x"]+2, b["y"]+6, fill="#4caf50", outline="")
            for b in S["ebullets"]:
                cv.create_rectangle(b["x"]-2, b["y"]-6, b["x"]+2, b["y"]+6, fill="#f44336", outline="")
            if S["alive"]:
                cv.create_polygon(S["px"], H-60, S["px"]-20, H-30, S["px"]+20, H-30, fill="#00d4ff")
            cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["score"], fill="#fff", font=("Consolas", 14, "bold"))
            cv.create_text(W//2, H-10, text="SETAS mover | ESPACO atirar | ESC sair", fill="#7a7a8a", font=("Segoe UI", 10))
            if not S["alive"]:
                cv.create_text(W//2, H//2, text="GAME OVER", fill="#ff3355", font=("Segoe UI", 32, "bold"))
        def step():
            if not S["alive"]: return
            S["t"] += 1
            for e in S["enemies"][:]:
                if not e["alive"]: continue
                e["x"] += 1 if (S["t"] // 100) % 2 == 0 else -1
                if S["t"] % 60 == 0:
                    S["ebullets"].append({"x": e["x"], "y": e["y"]+15})
            for b in S["bullets"][:]:
                b["y"] -= 10
                if b["y"] < 0: S["bullets"].remove(b); continue
                for e in S["enemies"][:]:
                    if e["alive"] and abs(e["x"]-b["x"]) < 20 and abs(e["y"]-b["y"]) < 15:
                        e["alive"] = False; S["score"] += 10; snd("hit")
                        S["bullets"].remove(b); break
            for b in S["ebullets"][:]:
                b["y"] += 5
                if b["y"] > H: S["ebullets"].remove(b); continue
                if abs(b["x"]-S["px"]) < 20 and b["y"] > H-50:
                    S["alive"] = False; snd("die"); self.end_game("invaders", S["score"])
            if all(not e["alive"] for e in S["enemies"]):
                S["enemies"] = []
                for r in range(4):
                    for c in range(8):
                        S["enemies"].append({"x": 100+c*80, "y": 80+r*50, "alive": True})
            draw()
            try: frame.after(30, step)
            except: pass
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym == "Left" and S["px"] > 30: S["px"] -= 30
            elif e.keysym == "Right" and S["px"] < W-30: S["px"] += 30
            elif e.keysym in ("space", "Return"):
                S["bullets"].append({"x": S["px"], "y": H-70})
                snd("shoot")
        self.root.bind("<KeyPress>", key)
        cv.focus_set(); frame.focus_force(); step()

    def game_connect4(self):
        frame = self.open_game_frame()
        fr = tk.Frame(frame, bg="#0a0a0f"); fr.pack(fill="both", expand=True)
        tk.Label(fr, text="CONNECT 4", bg="#0a0a0f", fg="#2196f3", font=("Segoe UI", 20, "bold")).pack(pady=10)
        S = {"grid": [[0]*7 for _ in range(6)], "over": False}
        status = tk.Label(fr, text="Aperte 1-7 para escolher coluna", bg="#0a0a0f", fg="white", font=("Segoe UI", 12, "bold"))
        status.pack()
        g = tk.Frame(fr, bg="#2196f3"); g.pack(pady=10)
        btns = []
        def check(p):
            g2 = S["grid"]
            for r in range(6):
                for c in range(4):
                    if all(g2[r][c+i] == p for i in range(4)): return True
            for r in range(3):
                for c in range(7):
                    if all(g2[r+i][c] == p for i in range(4)): return True
            for r in range(3):
                for c in range(4):
                    if all(g2[r+i][c+i] == p for i in range(4)): return True
            for r in range(3):
                for c in range(3, 7):
                    if all(g2[r+i][c-i] == p for i in range(4)): return True
            return False
        def drop(col):
            if S["over"]: return
            for r in range(5, -1, -1):
                if S["grid"][r][col] == 0:
                    S["grid"][r][col] = 1; btns[r][col].config(bg="#f44336")
                    if check(1): status.config(text="Voce venceu!"); S["over"] = True; snd("coin"); return
                    best = None
                    for c2 in range(7):
                        for r2 in range(5, -1, -1):
                            if S["grid"][r2][c2] == 0:
                                S["grid"][r2][c2] = 2
                                if check(2): best = c2
                                S["grid"][r2][c2] = 0
                                break
                    if best is None:
                        for c2 in [3, 2, 4, 1, 5, 0, 6]:
                            for r2 in range(5, -1, -1):
                                if S["grid"][r2][c2] == 0: best = c2; break
                            if best is not None: break
                    for r2 in range(5, -1, -1):
                        if S["grid"][r2][best] == 0:
                            S["grid"][r2][best] = 2; btns[r2][best].config(bg="#ffc107")
                            if check(2): status.config(text="CPU venceu!"); S["over"] = True; snd("error")
                            return
                    return
            return
        for r in range(6):
            row = []
            for c in range(7):
                b = tk.Button(g, text="", bg="#0a0a0f", width=4, height=2, relief="flat",
                              command=lambda c=c: drop(c))
                b.grid(row=r, column=c, padx=2, pady=2)
                row.append(b)
            btns.append(row)
        def key(e):
            if e.keysym == "Escape": self.close_game(); return "break"
            if e.keysym.isdigit():
                n = int(e.keysym) - 1
                if 0 <= n <= 6: drop(n)
        frame.bind("<KeyPress>", key)
        frame.focus_set(); frame.focus_force()
        tk.Label(fr, text="1-7 para coluna | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)


# ============================================================
if __name__ == "__main__":
    try:
        try:
            sys.stdout.write("minstcaveStation v" + V + "\n")
            sys.stdout.flush()
        except: pass
        app = Station()
        app.root.mainloop()
    except Exception as e:
        msg = "ERRO: " + type(e).__name__ + "\n" + str(e) + "\n\n" + traceback.format_exc()
        try:
            f = open(os.path.join(BASE, "erro.log"), "w")
            f.write(msg); f.close()
        except: pass
        try:
            sys.stdout.write(msg + "\n"); sys.stdout.flush()
        except: pass
        try: input("ENTER...")
        except: pass