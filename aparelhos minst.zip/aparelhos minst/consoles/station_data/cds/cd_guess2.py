import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
num = [random.randint(1, 1000)]; tries = [0]
tk.Label(frame, text="GUESS 1-1000", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 20, "bold")).pack(pady=20)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 18), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
fb = tk.Label(frame, text="Digite um numero", bg="#0a0a0f", fg="#ffc107", font=("Segoe UI", 14, "bold"))
fb.pack(pady=20)
def check(ev=None):
    try:
        g = int(e.get()); tries[0] += 1; e.delete(0, "end")
        if g < num[0]: fb.config(text="MAIOR! T%d" % tries[0])
        elif g > num[0]: fb.config(text="MENOR! T%d" % tries[0])
        else:
            fb.config(text="ACERTOU em %d! ENTER para novo" % tries[0], fg="#4caf50")
            num[0] = random.randint(1, 1000); tries[0] = 0
    except: pass
e.bind("<Return>", check)
tk.Label(frame, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack()
