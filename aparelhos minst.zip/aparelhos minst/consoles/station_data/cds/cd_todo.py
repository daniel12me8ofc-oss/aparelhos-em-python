import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="TO-DO LIST", bg="#0a0a0f", fg="#795548", font=("Segoe UI", 20, "bold")).pack(pady=10)
lb = tk.Listbox(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 12), relief="flat")
lb.pack(fill="both", expand=True, padx=20, pady=10)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 12), relief="flat")
e.pack(fill="x", padx=20, pady=5, ipady=5)
def add():
    t = e.get().strip()
    if t: lb.insert("end", t); e.delete(0, "end")
def rm():
    s = lb.curselection()
    if s: lb.delete(s[0])
bf = tk.Frame(frame, bg="#0a0a0f"); bf.pack(pady=10)
tk.Button(bf, text="+ Add", bg="#795548", fg="white", font=("Segoe UI", 11, "bold"),
          command=add, padx=20, pady=6, relief="flat").pack(side="left", padx=5)
tk.Button(bf, text="- Rem", bg="#f44336", fg="white", font=("Segoe UI", 11, "bold"),
          command=rm, padx=20, pady=6, relief="flat").pack(side="left", padx=5)
e.bind("<Return>", lambda e: add())
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack()
