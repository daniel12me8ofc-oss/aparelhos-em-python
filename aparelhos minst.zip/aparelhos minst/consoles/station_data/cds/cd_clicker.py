import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
score = [0]
lbl = tk.Label(frame, text="0", bg="#0a0a0f", fg="#ff5722", font=("Segoe UI", 80, "bold"))
lbl.pack(pady=40)
def click():
    score[0] += 1
    lbl.config(text=str(score[0]))
tk.Button(frame, text="CLIQUE!", bg="#ff5722", fg="white", font=("Segoe UI", 16, "bold"),
          command=click, padx=60, pady=20, relief="flat").pack()
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 11)).pack(pady=20)
