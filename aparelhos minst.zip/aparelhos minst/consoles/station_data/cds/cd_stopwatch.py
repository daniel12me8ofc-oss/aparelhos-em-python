import tkinter as tk, time
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="STOPWATCH", bg="#0a0a0f", fg="#607d8b", font=("Segoe UI", 20, "bold")).pack(pady=15)
lbl = tk.Label(frame, text="00:00.00", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 36, "bold"))
lbl.pack(pady=30)
S = {"run": False, "start": 0, "elapsed": 0}
def tick():
    if S["run"]:
        el = S["elapsed"] + (time.time() - S["start"])
        lbl.config(text="%02d:%05.2f" % (int(el//60), el%60))
    frame.after(50, tick)
tick()
def toggle():
    if S["run"]:
        S["elapsed"] += time.time() - S["start"]; S["run"] = False
    else:
        S["start"] = time.time(); S["run"] = True
def reset():
    S["run"] = False; S["elapsed"] = 0; lbl.config(text="00:00.00")
bf = tk.Frame(frame, bg="#0a0a0f"); bf.pack()
tk.Button(bf, text="Play/Pause", bg="#607d8b", fg="white", font=("Segoe UI", 11, "bold"),
          command=toggle, padx=20, pady=8, relief="flat").pack(side="left", padx=5)
tk.Button(bf, text="Reset", bg="#f44336", fg="white", font=("Segoe UI", 11, "bold"),
          command=reset, padx=20, pady=8, relief="flat").pack(side="left", padx=5)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=15)
