import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="TEMP CONVERTER", bg="#0a0a0f", fg="#f44336", font=("Segoe UI", 18, "bold")).pack(pady=15)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 14), relief="flat", justify="center")
e.pack(padx=40, pady=15, ipady=8, fill="x")
r = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 14, "bold"))
r.pack(pady=20)
def c2f(e_=None):
    try: r.config(text="%.1f F" % (float(e.get()) * 9/5 + 32))
    except: r.config(text="Erro")
def f2c(e_=None):
    try: r.config(text="%.1f C" % ((float(e.get()) - 32) * 5/9))
    except: r.config(text="Erro")
bf = tk.Frame(frame, bg="#0a0a0f"); bf.pack()
tk.Button(bf, text="C -> F", bg="#f44336", fg="white", font=("Segoe UI", 11, "bold"),
          command=c2f, padx=20, pady=6, relief="flat").pack(side="left", padx=5)
tk.Button(bf, text="F -> C", bg="#2196f3", fg="white", font=("Segoe UI", 11, "bold"),
          command=f2c, padx=20, pady=6, relief="flat").pack(side="left", padx=5)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=15)
