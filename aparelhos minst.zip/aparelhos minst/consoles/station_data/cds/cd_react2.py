import tkinter as tk, time, random
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"st": "wait", "start": 0, "best": 9999}
lbl = tk.Label(frame, text="Aguarde o verde...", bg="#0a0a0f", fg="white", font=("Segoe UI", 24, "bold"))
lbl.pack(expand=True)
def reset():
    lbl.config(text="Aguarde o verde...", fg="white"); S["st"] = "wait"
    def ready():
        if S["st"] == "wait":
            lbl.config(text="ENTER AGORA!", fg="#4caf50"); S["st"] = "ready"; S["start"] = time.time()
    frame.after(random.randint(1500, 4000), ready)
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return":
        if S["st"] == "wait": lbl.config(text="CEDO! ENTER para tentar de novo", fg="#f44336"); S["st"] = "fail"
        elif S["st"] == "ready":
            t = (time.time() - S["start"]) * 1000; S["best"] = min(S["best"], int(t))
            lbl.config(text="%.0f ms! Best: %d  ENTER para novo" % (t, S["best"]), fg="#00d4ff"); S["st"] = "fail"
        else: reset()
frame.bind("<KeyPress>", key)
frame.focus_set(); reset()
tk.Label(frame, text="ENTER quando verde | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
