import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
qs = [("5x3?", 15), ("10-4?", 6), ("7+8?", 15), ("20/2?", 10), ("2^3?", 8)]
idx = [0]; sc = [0]
q = tk.Label(frame, text="", bg="#0a0a0f", fg="#9c27b0", font=("Segoe UI", 40, "bold"))
q.pack(pady=30)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 20), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
st = tk.Label(frame, text="Score: 0", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 12))
st.pack()
def newq():
    if idx[0] >= len(qs):
        q.config(text="FIM! %d/%d" % (sc[0], len(qs))); return
    q.config(text=qs[idx[0]][0])
def check(ev=None):
    try:
        if int(e.get()) == qs[idx[0]][1]: sc[0] += 1; st.config(text="Score: %d" % sc[0])
        idx[0] += 1; e.delete(0, "end"); newq()
    except: e.delete(0, "end")
e.bind("<Return>", check)
newq()
tk.Label(frame, text="Resposta + ENTER | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack()
