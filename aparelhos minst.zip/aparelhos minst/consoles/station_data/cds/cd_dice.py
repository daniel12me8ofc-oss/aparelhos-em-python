import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="DADOS", bg="#0a0a0f", fg="#673ab7", font=("Segoe UI", 20, "bold")).pack(pady=15)
l1 = tk.Label(frame, text="?", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 80, "bold"))
l1.pack()
l2 = tk.Label(frame, text="?", bg="#0a0a0f", fg="#e91e63", font=("Segoe UI", 80, "bold"))
l2.pack()
def roll():
    l1.config(text=str(random.randint(1,6)))
    l2.config(text=str(random.randint(1,6)))
tk.Button(frame, text="ROLAR", bg="#673ab7", fg="white", font=("Segoe UI", 14, "bold"),
          command=roll, padx=40, pady=12, relief="flat").pack(pady=20)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack()
