import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="MOEDA", bg="#0a0a0f", fg="#ffc107", font=("Segoe UI", 20, "bold")).pack(pady=15)
l = tk.Label(frame, text="?", bg="#0a0a0f", fg="#ffc107", font=("Segoe UI", 80, "bold"))
l.pack(pady=30)
st = tk.Label(frame, text="Cara: 0 | Coroa: 0", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 12))
st.pack()
c = {"Cara": 0, "Coroa": 0}
def flip():
    r = random.choice(["Cara", "Coroa"]); l.config(text=r); c[r] += 1
    st.config(text="Cara: %d | Coroa: %d" % (c["Cara"], c["Coroa"]))
tk.Button(frame, text="JOGAR", bg="#ffc107", fg="black", font=("Segoe UI", 14, "bold"),
          command=flip, padx=40, pady=12, relief="flat").pack(pady=20)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack()
