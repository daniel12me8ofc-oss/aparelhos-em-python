import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
questions = [
    ("Quanto e 2+2?", ["3", "4", "5"], 1),
    ("Cor do ceu?", ["Azul", "Verde", "Roxo"], 0),
    ("Capital do Brasil?", ["SP", "RJ", "Brasilia"], 2),
]
idx = [0]
score = [0]
q_lbl = tk.Label(frame, text="", bg="#0a0a0f", fg="#9c27b0", font=("Segoe UI", 16, "bold"))
q_lbl.pack(pady=20)
bf = tk.Frame(frame, bg="#0a0a0f"); bf.pack()
def show():
    if idx[0] >= len(questions):
        q_lbl.config(text="FIM! Score: %d/%d" % (score[0], len(questions)))
        for w in bf.winfo_children(): w.destroy()
        return
    q, opts, _ = questions[idx[0]]
    q_lbl.config(text=q)
    for w in bf.winfo_children(): w.destroy()
    for i, o in enumerate(opts):
        tk.Button(bf, text=o, bg="#9c27b0", fg="white", font=("Segoe UI", 11, "bold"),
                  command=lambda i=i: answer(i), padx=20, pady=8, relief="flat").pack(pady=3)
def answer(i):
    if i == questions[idx[0]][2]: score[0] += 1
    idx[0] += 1
    show()
show()
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=20)
