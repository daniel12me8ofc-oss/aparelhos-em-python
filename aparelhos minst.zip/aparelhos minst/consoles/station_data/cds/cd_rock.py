import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="JOKENPO", bg="#0a0a0f", fg="#ffc107", font=("Segoe UI", 20, "bold")).pack(pady=20)
res = tk.Label(frame, text="Escolha:", bg="#0a0a0f", fg="white", font=("Segoe UI", 16))
res.pack(pady=20)
score = tk.Label(frame, text="0 x 0", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 14))
score.pack()
S = {"w": 0, "l": 0}
def play(c):
    cpu = random.choice(["Pedra", "Papel", "Tesoura"])
    if c == cpu: r = "Empate: " + c + " vs " + cpu
    elif (c=="Pedra" and cpu=="Tesoura") or (c=="Papel" and cpu=="Pedra") or (c=="Tesoura" and cpu=="Papel"):
        r = "Voce venceu: " + c + " vs " + cpu; S["w"] += 1
    else:
        r = "CPU venceu: " + c + " vs " + cpu; S["l"] += 1
    res.config(text=r); score.config(text="%d x %d" % (S["w"], S["l"]))
bf = tk.Frame(frame, bg="#0a0a0f"); bf.pack(pady=20)
for o in ["Pedra", "Papel", "Tesoura"]:
    tk.Button(bf, text=o, bg="#ffc107", fg="black", font=("Segoe UI", 11, "bold"),
              command=lambda x=o: play(x), padx=15, pady=8, relief="flat").pack(side="left", padx=5)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=20)
