import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"tx": W//2, "ty": H//2, "score": 0, "time": 30, "playing": True}
def draw():
    cv.delete("all")
    cv.create_rectangle(0,0,W,H,fill="#0a0a0f",outline="")
    if S["playing"]:
        cv.create_oval(S["tx"]-25, S["ty"]-25, S["tx"]+25, S["ty"]+25, outline="#f44336", width=3)
        cv.create_oval(S["tx"]-8, S["ty"]-8, S["tx"]+8, S["ty"]+8, fill="#f44336", outline="")
    cv.create_text(W-15, 20, anchor="e", text="Score: %d Time: %ds" % (S["score"], S["time"]), fill="#fff", font=("Consolas", 14, "bold"))
def tick():
    if not S["playing"]: return
    S["time"] -= 1
    if S["time"] <= 0: S["playing"] = False
    draw()
    frame.after(1000, tick)
def click(ev):
    if not S["playing"]: return
    if abs(ev.x - S["tx"]) < 25 and abs(ev.y - S["ty"]) < 25:
        S["score"] += 1; S["tx"] = random.randint(50, W-50); S["ty"] = random.randint(50, H-50); draw()
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return" and not S["playing"]:
        S.update({"time": 30, "playing": True, "score": 0}); draw()
cv.bind("<Button-1>", click)
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force()
draw(); tick()
