import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"bx": W//2, "by": H//2, "vx": 5, "vy": 4, "py": H//2, "ay": H//2, "ps": 0, "as_": 0}
def draw():
    cv.delete("all")
    cv.create_line(W//2, 0, W//2, H, fill="#333", dash=(10,10))
    cv.create_rectangle(20, S["py"]-50, 30, S["py"]+50, fill="#00d4ff", outline="")
    cv.create_rectangle(W-30, S["ay"]-50, W-20, S["ay"]+50, fill="#ff3355", outline="")
    cv.create_oval(S["bx"]-10, S["by"]-10, S["bx"]+10, S["by"]+10, fill="white", outline="")
    cv.create_text(W//2, 30, text="%d - %d" % (S["ps"], S["as_"]), fill="white", font=("Consolas", 24, "bold"))
    cv.create_text(W//2, H-30, text="Setas/W-S | ESC", fill="#7a7a8a", font=("Segoe UI", 10))
def step():
    S["bx"] += S["vx"]; S["by"] += S["vy"]
    if S["by"] < 15 or S["by"] > H-15: S["vy"] = -S["vy"]
    if S["bx"] < 30 and S["py"]-50 < S["by"] < S["py"]+50: S["vx"] = abs(S["vx"])
    if S["bx"] > W-30 and S["ay"]-50 < S["by"] < S["ay"]+50: S["vx"] = -abs(S["vx"])
    if S["bx"] < 0: S["as_"] += 1; S["bx"]=W//2; S["by"]=H//2
    if S["bx"] > W: S["ps"] += 1; S["bx"]=W//2; S["by"]=H//2
    if S["by"] > S["ay"]+20 and S["ay"] < H-60: S["ay"] += 5
    elif S["by"] < S["ay"]-20 and S["ay"] > 60: S["ay"] -= 5
    draw()
    try: frame.after(16, step)
    except: pass
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("Up","w") and S["py"] > 60: S["py"] -= 30
    elif ev.keysym in ("Down","s") and S["py"] < H-60: S["py"] += 30
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force(); step()
