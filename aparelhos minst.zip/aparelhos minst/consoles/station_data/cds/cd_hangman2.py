import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
words = ["PYTHON", "JOGO", "MOUSE", "TECLADO", "CODIGO", "JANELA", "ARQUIVO", "MUSICA", "ESTRELA", "MONTANHA"]
S = {"w": random.choice(words), "g": set(), "e": 0}
lbl = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 28, "bold"))
lbl.pack(pady=20)
st = tk.Label(frame, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 12))
st.pack()
def upd():
    d = " ".join([c if c in S["g"] else "_" for c in S["w"]])
    lbl.config(text=d)
    st.config(text="Erros: %d/6  Letras: %s" % (S["e"], " ".join(sorted(S["g"]))))
    if "_" not in d: lbl.config(text="VITORIA! " + S["w"], fg="#4caf50")
    elif S["e"] >= 6: lbl.config(text="PERDEU! " + S["w"], fg="#f44336")
def key(ev):
    if ev.keysym == "Escape": return
    k = ev.keysym.upper()
    if len(k) == 1 and k.isalpha() and k not in S["g"]:
        S["g"].add(k)
        if k not in S["w"]: S["e"] += 1
        upd()
frame.bind("<KeyPress>", key)
frame.focus_set(); upd()
tk.Label(frame, text="Digite letras | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
