import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
words = ["PYTHON","JOGO","MOUSE","TECLADO","CODIGO","MUSICA","ESTRELA"]
S = {"w": "", "score": 0}
def neww():
    w = random.choice(words)
    S["w"] = w
    sc = "".join(random.sample(w, len(w)))
    while sc == w: sc = "".join(random.sample(w, len(w)))
    q.config(text=sc)
q = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 30, "bold"))
q.pack(pady=20)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 16), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
st = tk.Label(frame, text="Score: 0", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 12, "bold"))
st.pack()
def check(ev=None):
    if e.get().upper().strip() == S["w"]:
        S["score"] += 1; st.config(text="Score: %d" % S["score"]); neww()
    e.delete(0, "end")
e.bind("<Return>", check)
neww()
tk.Label(frame, text="Digite a palavra + ENTER | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
