import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"lvl": 1, "score": 0}
lbl = tk.Label(frame, text="", bg="#0a0a0f", fg="#ffc107", font=("Segoe UI", 30, "bold"))
lbl.pack(pady=30)
st = tk.Label(frame, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 12))
st.pack()
def newchallenge():
    if S["lvl"] > 5:
        lbl.config(text="VOCE VENCEU TUDO!"); st.config(text="Score final: %d | ENTER para reiniciar" % S["score"]); return
    n = random.randint(3, 10 + S["lvl"]*5)
    target = S["lvl"] * 10
    lbl.config(text="Nivel %d: aperte ENTER %d vezes" % (S["lvl"], target)); st.config(text="")
    S["target"] = target; S["cur"] = 0
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return":
        if S["lvl"] > 5:
            S.update({"lvl": 1, "score": 0}); newchallenge(); return
        S["cur"] += 1
        if S["cur"] >= S["target"]:
            S["score"] += S["target"]; S["lvl"] += 1; newchallenge()
frame.bind("<KeyPress>", key)
frame.focus_set(); newchallenge()
tk.Label(frame, text="ENTER rapido | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
