import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="UPPER/LOWER", bg="#0a0a0f", fg="#ff5722", font=("Segoe UI", 18, "bold")).pack(pady=15)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 14), relief="flat")
e.pack(padx=40, pady=15, ipady=8, fill="x")
r = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 14, "bold"), wraplength=400)
r.pack(pady=20)
def up(): r.config(text=e.get().upper())
def lo(): r.config(text=e.get().lower())
bf = tk.Frame(frame, bg="#0a0a0f"); bf.pack()
tk.Button(bf, text="UPPER", bg="#ff5722", fg="white", font=("Segoe UI", 11, "bold"),
          command=up, padx=20, pady=6, relief="flat").pack(side="left", padx=5)
tk.Button(bf, text="lower", bg="#2196f3", fg="white", font=("Segoe UI", 11, "bold"),
          command=lo, padx=20, pady=6, relief="flat").pack(side="left", padx=5)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=15)
