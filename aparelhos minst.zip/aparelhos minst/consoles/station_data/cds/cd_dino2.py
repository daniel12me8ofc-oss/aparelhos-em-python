import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#f7f7f7", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"y": H-100, "vy": 0, "obs": [], "sc": 0, "alive": True, "t": 0}
def draw():
    cv.delete("all")
    cv.create_rectangle(0, 0, W, H, fill="#f7f7f7", outline="")
    cv.create_rectangle(0, H-60, W, H, fill="#c5c5c5", outline="")
    for o in S["obs"]: cv.create_rectangle(o["x"], H-100, o["x"]+30, H-60, fill="#333", outline="")
    cv.create_rectangle(60, S["y"], 100, S["y"]+40, fill="#333", outline="")
    cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["sc"], fill="#333", font=("Consolas", 14, "bold"))
    if not S["alive"]: cv.create_text(W//2, H//2, text="GAME OVER", fill="#ff3355", font=("Segoe UI", 24, "bold"))
def step():
    if not S["alive"]: return
    S["t"] += 1; S["y"] += S["vy"]; S["vy"] += 0.5
    if S["y"] > H-100: S["y"] = H-100; S["vy"] = 0
    if S["t"] % 80 == 0: S["obs"].append({"x": W})
    for o in S["obs"][:]:
        o["x"] -= 6
        if o["x"]+30 < 0: S["obs"].remove(o); S["sc"] += 1; continue
        if o["x"] < 100 and o["x"]+30 > 60 and S["y"]+40 > H-100: S["alive"] = False
    draw()
    frame.after(30, step)
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("space","Up","Return"):
        if S["alive"] and S["y"] >= H-100: S["vy"] = -14
        elif not S["alive"]: S.update({"y": H-100, "vy": 0, "obs": [], "sc": 0, "alive": True, "t": 0}); step()
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force(); step()
