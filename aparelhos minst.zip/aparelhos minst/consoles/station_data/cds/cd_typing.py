import tkinter as tk, time
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="TYPING TEST", bg="#0a0a0f", fg="#2196f3", font=("Segoe UI", 20, "bold")).pack(pady=20)
words = ["python", "jogo", "programa", "teclado", "mouse"]
target = [random.choice(words)]
lbl = tk.Label(frame, text=target[0], bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 32, "bold"))
lbl.pack(pady=20)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 16), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
status = tk.Label(frame, text="", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 12, "bold"))
status.pack()
score = [0]
start = [time.time()]
def check(ev=None):
    if e.get().strip() == target[0]:
        score[0] += 1
        target[0] = random.choice(words)
        lbl.config(text=target[0])
        e.delete(0, "end")
        status.config(text="Acertos: %d" % score[0])
e.bind("<Return>", check)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=20)
