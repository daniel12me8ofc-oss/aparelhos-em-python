import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="CALCULADORA IMC", bg="#0a0a0f", fg="#e91e63", font=("Segoe UI", 18, "bold")).pack(pady=15)
tk.Label(frame, text="Peso (kg):", bg="#0a0a0f", fg="white").pack()
ep = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 12), relief="flat")
ep.pack(pady=5, ipady=4)
tk.Label(frame, text="Altura (m):", bg="#0a0a0f", fg="white").pack()
ea = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 12), relief="flat")
ea.pack(pady=5, ipady=4)
res = tk.Label(frame, text="", bg="#0a0a0f", fg="#e91e63", font=("Segoe UI", 16, "bold"))
res.pack(pady=20)
def calc():
    try:
        p = float(ep.get()); a = float(ea.get())
        imc = p / (a*a)
        cat = "Normal" if imc < 25 else ("Sobrepeso" if imc < 30 else "Obesidade")
        res.config(text="IMC: %.1f (%s)" % (imc, cat))
    except: res.config(text="Erro")
tk.Button(frame, text="Calcular", bg="#e91e63", fg="white", font=("Segoe UI", 11, "bold"),
          command=calc, padx=30, pady=8, relief="flat").pack()
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=15)
