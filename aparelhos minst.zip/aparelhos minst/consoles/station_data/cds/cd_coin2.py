import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
l = tk.Label(frame, text="?", bg="#0a0a0f", fg="#ffc107", font=("Segoe UI", 80, "bold"))
l.pack(pady=30)
st = tk.Label(frame, text="Voce 0 - 0 CPU", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 14))
st.pack()
S = {"w": 0, "l": 0}
def flip():
    you = random.choice(["Cara","Coroa"]); cpu = random.choice(["Cara","Coroa"])
    l.config(text=you)
    if you == cpu: pass
    elif (you=="Cara" and cpu=="Coroa") or (you=="Coroa" and cpu=="Cara"): S["w"] += 1
    else: S["l"] += 1
    st.config(text="Voce %d - %d CPU" % (S["w"], S["l"]))
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("Return","space"): flip()
frame.bind("<KeyPress>", key)
frame.focus_set()
tk.Label(frame, text="ENTER para jogar | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=20)
