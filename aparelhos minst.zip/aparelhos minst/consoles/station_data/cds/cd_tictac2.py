import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"b": [""]*9, "cur": 0, "over": False}
lbl = tk.Label(frame, text="Sua vez (X)", bg="#0a0a0f", fg="white", font=("Segoe UI", 14, "bold"))
lbl.pack(pady=10)
g = tk.Frame(frame, bg="#0a0a0f"); g.pack()
btns = []
def check():
    wins = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
    for a,b,c in wins:
        if S["b"][a] and S["b"][a]==S["b"][b]==S["b"][c]: return S["b"][a]
    return "Empate" if "" not in S["b"] else None
def click(i):
    if S["over"] or S["b"][i]: return
    S["b"][i] = "X"; btns[i].config(text="X", fg="#00d4ff")
    w = check()
    if w: lbl.config(text="Voce venceu!" if w=="X" else "Empate"); S["over"] = True; return
    for j in range(9):
        if S["b"][j] == "": S["b"][j] = "O"; btns[j].config(text="O", fg="#e91e63"); break
    w = check()
    if w: lbl.config(text="CPU venceu!" if w=="O" else "Empate"); S["over"] = True
for i in range(9):
    b = tk.Button(g, text="", bg="#1e1e2a", fg="white", font=("Segoe UI", 22, "bold"),
                  width=4, height=2, relief="flat", command=lambda i=i: click(i))
    b.grid(row=i//3, column=i%3, padx=3, pady=3)
    btns.append(b)
tk.Label(frame, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
