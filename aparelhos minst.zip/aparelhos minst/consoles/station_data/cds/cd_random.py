import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="RANDOM NUMBER", bg="#0a0a0f", fg="#00bcd4", font=("Segoe UI", 18, "bold")).pack(pady=15)
l = tk.Label(frame, text="?", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 80, "bold"))
l.pack(pady=20)
tk.Button(frame, text="GERAR", bg="#00bcd4", fg="white", font=("Segoe UI", 14, "bold"),
          command=lambda: l.config(text=str(random.randint(1, 100))),
          padx=40, pady=12, relief="flat").pack(pady=20)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack()
