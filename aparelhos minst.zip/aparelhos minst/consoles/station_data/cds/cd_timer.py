import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="TIMER", bg="#0a0a0f", fg="#00bcd4", font=("Segoe UI", 20, "bold")).pack(pady=15)
lbl = tk.Label(frame, text="01:00", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 48, "bold"))
lbl.pack(pady=30)
S = {"time": 60, "run": False}
def tick():
    if S["run"] and S["time"] > 0:
        S["time"] -= 1
        lbl.config(text="%02d:%02d" % (S["time"]//60, S["time"]%60))
    frame.after(1000, tick)
tick()
bf = tk.Frame(frame, bg="#0a0a0f"); bf.pack()
tk.Button(bf, text="Iniciar/Parar", bg="#00bcd4", fg="white", font=("Segoe UI", 11, "bold"),
          command=lambda: S.__setitem__("run", not S["run"]), padx=20, pady=8, relief="flat").pack(side="left", padx=5)
tk.Button(bf, text="Reset", bg="#f44336", fg="white", font=("Segoe UI", 11, "bold"),
          command=lambda: (S.update({"time": 60, "run": False}), lbl.config(text="01:00")), padx=20, pady=8, relief="flat").pack(side="left", padx=5)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=15)
