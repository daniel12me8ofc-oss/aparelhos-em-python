import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="REVERSE", bg="#0a0a0f", fg="#2196f3", font=("Segoe UI", 18, "bold")).pack(pady=15)
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 14), relief="flat", justify="center")
e.pack(padx=40, pady=15, ipady=8, fill="x")
r = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 16, "bold"), wraplength=400)
r.pack(pady=20)
def rev(e_=None):
    r.config(text=e.get()[::-1])
e.bind("<Return>", rev)
e.focus_set()
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack()
