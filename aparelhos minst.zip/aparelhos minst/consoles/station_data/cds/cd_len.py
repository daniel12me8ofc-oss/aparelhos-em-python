import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="LENGTH COUNTER", bg="#0a0a0f", fg="#3f51b5", font=("Segoe UI", 18, "bold")).pack(pady=15)
t = tk.Text(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 12), relief="flat", height=6, padx=10, pady=10, wrap="word")
t.pack(fill="x", padx=20, pady=10)
r = tk.Label(frame, text="Caracteres: 0 | Palavras: 0", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 12, "bold"))
r.pack(pady=10)
def upd(e_=None):
    txt = t.get("1.0", "end-1c")
    r.config(text="Caracteres: %d | Palavras: %d" % (len(txt), len(txt.split())))
t.bind("<KeyRelease>", upd)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack()
