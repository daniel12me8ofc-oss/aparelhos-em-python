# Exemplo de CD - Clicker
import tkinter as tk

win = tk.Toplevel(parent)
win.title("Clicker CD")
win.configure(bg="#0a0a0f")
win.geometry("500x400")

score = [0]
lbl = tk.Label(win, text="0", bg="#0a0a0f", fg="#00d4ff",
               font=("Segoe UI", 60, "bold"))
lbl.pack(pady=40)

def click():
    score[0] += 1
    lbl.config(text=str(score[0]))

btn = tk.Button(win, text="CLIQUE!", bg="#0070e0", fg="white",
                font=("Segoe UI", 14, "bold"), command=click,
                padx=40, pady=15, relief="flat")
btn.pack()

tk.Label(win, text="ESC para sair", bg="#0a0a0f", fg="#7a7a8a",
         font=("Segoe UI", 10)).pack(pady=20)

win.bind("<Escape>", lambda e: win.destroy())
win.focus_set()
win.grab_set()
