import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="COLOR PICKER", bg="#0a0a0f", fg="#ff9800", font=("Segoe UI", 18, "bold")).pack(pady=15)
colors = ["#f44336", "#e91e63", "#9c27b0", "#673ab7", "#3f51b5",
          "#2196f3", "#00bcd4", "#009688", "#4caf50", "#8bc34a",
          "#ffc107", "#ff9800", "#795548", "#607d8b", "#000000"]
preview = tk.Canvas(frame, width=200, height=100, bg="#00d4ff", highlightthickness=0)
preview.pack(pady=10)
lbl = tk.Label(frame, text="#00d4ff", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 14, "bold"))
lbl.pack()
def pick(c):
    preview.config(bg=c); lbl.config(text=c, fg=c)
g = tk.Frame(frame, bg="#0a0a0f"); g.pack(pady=10)
for i, c in enumerate(colors):
    tk.Button(g, bg=c, width=3, height=1, relief="flat",
              command=lambda c=c: pick(c)).grid(row=i//5, column=i%5, padx=2, pady=2)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack()
