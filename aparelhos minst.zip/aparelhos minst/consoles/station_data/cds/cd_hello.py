import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="HELLO WORLD", bg="#0a0a0f", fg="#9e9e9e", font=("Segoe UI", 24, "bold")).pack(pady=60)
tk.Label(frame, text="Ola, Mundo!", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 30, "bold")).pack()
tk.Label(frame, text="Seu primeiro programa", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 12)).pack(pady=20)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=30)
