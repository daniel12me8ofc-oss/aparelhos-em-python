import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0, width=440, height=440)
cv.pack(pady=10)
S = {"s": [(10,10)], "d": (1,0), "f": (5,5), "sc": 0, "alive": True, "sp": 120}
def draw():
    cv.delete("all")
    for x in range(0, 441, 22): cv.create_line(x, 0, x, 440, fill="#1a1a24")
    for y in range(0, 441, 22): cv.create_line(0, y, 440, y, fill="#1a1a24")
    for i, (x, y) in enumerate(S["s"]):
        c = "#81c784" if i == 0 else "#4caf50"
        cv.create_rectangle(x*22+1, y*22+1, (x+1)*22-1, (y+1)*22-1, fill=c, outline="")
    fx, fy = S["f"]
    cv.create_oval(fx*22+3, fy*22+3, (fx+1)*22-3, (fy+1)*22-3, fill="#ff3355", outline="")
    cv.create_text(10, 460, anchor="w", text="Score: %d" % S["sc"], fill="white", font=("Consolas", 12, "bold"))
    if not S["alive"]: cv.create_text(220, 220, text="GAME OVER", fill="#ff3355", font=("Segoe UI", 24, "bold"))
def step():
    if not S["alive"]: return
    hx, hy = S["s"][0]; dx, dy = S["d"]; nx, ny = hx+dx, hy+dy
    if nx < 0 or nx >= 20 or ny < 0 or ny >= 20 or (nx, ny) in S["s"]:
        S["alive"] = False; draw(); return
    S["s"].insert(0, (nx, ny))
    if (nx, ny) == S["f"]:
        S["sc"] += 1
        while True:
            nf = (random.randint(0,19), random.randint(0,19))
            if nf not in S["s"]: break
        S["f"] = nf
        if S["sc"] % 5 == 0 and S["sp"] > 60: S["sp"] -= 5
    else: S["s"].pop()
    draw()
    frame.after(S["sp"], step)
def key(ev):
    if ev.keysym == "Escape": return
    d = S["d"]
    if ev.keysym == "Up" and d != (0,1): S["d"] = (0,-1)
    elif ev.keysym == "Down" and d != (0,-1): S["d"] = (0,1)
    elif ev.keysym == "Left" and d != (1,0): S["d"] = (-1,0)
    elif ev.keysym == "Right" and d != (-1,0): S["d"] = (1,0)
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force()
draw(); step()
