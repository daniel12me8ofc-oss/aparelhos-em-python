import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="CALCULADORA", bg="#0a0a0f", fg="#3f51b5", font=("Segoe UI", 18, "bold")).pack(pady=10)
d = tk.Entry(frame, bg="#000", fg="white", font=("Consolas", 18), justify="right", relief="flat")
d.pack(fill="x", padx=20, pady=10, ipady=10)
def press(v):
    if v == "C": d.delete(0, "end")
    elif v == "=":
        try:
            ex = d.get()
            if all(c in "0123456789+-*/(). " for c in ex):
                r = eval(ex); d.delete(0, "end"); d.insert(0, str(r))
        except: d.delete(0, "end"); d.insert(0, "Erro")
    else: d.insert("end", v)
g = tk.Frame(frame, bg="#0a0a0f"); g.pack(padx=20, pady=10)
btns = [["C","(",")","/"],["7","8","9","*"],["4","5","6","-"],["1","2","3","+"],["0",".","=",""]]
for r, row in enumerate(btns):
    for c, lbl in enumerate(row):
        if not lbl: continue
        bg = "#3f51b5" if lbl in "=+-*/" else ("#f44336" if lbl=="C" else "#1e1e2a")
        tk.Button(g, text=lbl, bg=bg, fg="white", font=("Segoe UI", 14, "bold"),
                  width=4, height=2, relief="flat", command=lambda l=lbl: press(l)).grid(row=r, column=c, padx=2, pady=2)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
