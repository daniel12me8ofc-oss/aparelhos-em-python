import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
l1 = tk.Label(frame, text="?", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 60, "bold"))
l1.pack()
l2 = tk.Label(frame, text="?", bg="#0a0a0f", fg="#e91e63", font=("Segoe UI", 60, "bold"))
l2.pack()
st = tk.Label(frame, text="Voce 0 - 0 CPU", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 14))
st.pack()
S = {"w": 0, "l": 0}
def roll():
    a = random.randint(1,6); b = random.randint(1,6)
    l1.config(text=str(a)); l2.config(text=str(b))
    if a > b: S["w"] += 1
    elif b > a: S["l"] += 1
    st.config(text="Voce %d - %d CPU" % (S["w"], S["l"]))
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("Return","space"): roll()
frame.bind("<KeyPress>", key)
frame.focus_set()
tk.Label(frame, text="ENTER para rolar | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=20)
