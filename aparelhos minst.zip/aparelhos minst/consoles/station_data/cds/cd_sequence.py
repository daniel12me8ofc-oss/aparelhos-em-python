import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"seq": [], "input": ""}
lbl = tk.Label(frame, text="", bg="#0a0a0f", fg="#673ab7", font=("Consolas", 30, "bold"))
lbl.pack(pady=30)
st = tk.Label(frame, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 12))
st.pack()
def new():
    S["seq"] = [random.randint(1,9) for _ in range(4)]
    S["input"] = ""
    lbl.config(text="".join(map(str, S["seq"]))); st.config(text="Digite os numeros + ENTER")
def check(ev=None):
    if S["input"] == "".join(map(str, S["seq"])):
        st.config(text="ACERTOU!"); lbl.config(text=""); frame.after(800, new)
    else:
        st.config(text="ERROU! Era: " + "".join(map(str, S["seq"]))); frame.after(1500, new)
    S["input"] = ""
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return": check()
    elif ev.char.isdigit(): S["input"] += ev.char
frame.bind("<KeyPress>", key)
frame.focus_set(); new()
tk.Label(frame, text="Digite os numeros + ENTER | ESC", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
