import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#0a0a0f", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"bx": W//2, "by": H-100, "vx": 5, "vy": -5, "px": W//2, "blocks": [], "sc": 0, "alive": True}
for r in range(5):
    for c in range(10):
        S["blocks"].append({"x": c*75+30, "y": r*30+80, "w": 70, "h": 25,
                             "color": ["#f44336","#ff9800","#ffc107","#4caf50","#2196f3"][r]})
def draw():
    cv.delete("all")
    cv.create_rectangle(0,0,W,H,fill="#0a0a0f",outline="")
    for b in S["blocks"]: cv.create_rectangle(b["x"],b["y"],b["x"]+b["w"],b["y"]+b["h"], fill=b["color"], outline="")
    cv.create_rectangle(S["px"]-60, H-40, S["px"]+60, H-25, fill="#00d4ff", outline="")
    cv.create_oval(S["bx"]-8, S["by"]-8, S["bx"]+8, S["by"]+8, fill="white", outline="")
    cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["sc"], fill="#fff", font=("Consolas", 14, "bold"))
    if not S["alive"]: cv.create_text(W//2, H//2, text="GAME OVER", fill="#ff3355", font=("Segoe UI", 24, "bold"))
def step():
    if not S["alive"]: return
    S["bx"] += S["vx"]; S["by"] += S["vy"]
    if S["bx"] < 10 or S["bx"] > W-10: S["vx"] = -S["vx"]
    if S["by"] < 10: S["vy"] = -S["vy"]
    if S["by"] > H-40 and S["px"]-60 < S["bx"] < S["px"]+60: S["vy"] = -abs(S["vy"])
    if S["by"] > H: S["alive"] = False
    for b in S["blocks"][:]:
        if b["x"] < S["bx"] < b["x"]+b["w"] and b["y"] < S["by"] < b["y"]+b["h"]:
            S["blocks"].remove(b); S["sc"] += 10; S["vy"] = -S["vy"]; break
    if not S["blocks"]: S["alive"] = False
    draw()
    frame.after(16, step)
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Left": S["px"] = max(60, S["px"]-40)
    elif ev.keysym == "Right": S["px"] = min(W-60, S["px"]+40)
    elif not S["alive"] and ev.keysym == "Return":
        S.update({"bx": W//2, "by": H-100, "vx": 5, "vy": -5, "sc": 0, "alive": True})
        S["blocks"] = []
        for r in range(5):
            for c in range(10):
                S["blocks"].append({"x": c*75+30, "y": r*30+80, "w": 70, "h": 25,
                                     "color": ["#f44336","#ff9800","#ffc107","#4caf50","#2196f3"][r]})
        step()
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force(); step()
