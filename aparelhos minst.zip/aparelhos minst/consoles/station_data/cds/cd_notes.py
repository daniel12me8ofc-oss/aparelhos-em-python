import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="NOTES", bg="#0a0a0f", fg="#ff9800", font=("Segoe UI", 20, "bold")).pack(pady=10)
t = tk.Text(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 12), relief="flat", padx=10, pady=10, wrap="word")
t.pack(fill="both", expand=True, padx=20, pady=10)
tk.Label(frame, text="Suas notas aqui. ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
