import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"hp": 100, "boss": 200, "alive": True, "log": []}
lbl = tk.Label(frame, text="BOSS FIGHT", bg="#0a0a0f", fg="#c51111", font=("Segoe UI", 20, "bold"))
lbl.pack(pady=10)
hp = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 14))
hp.pack(pady=5)
bhp = tk.Label(frame, text="", bg="#0a0a0f", fg="#f44336", font=("Segoe UI", 14))
bhp.pack(pady=5)
st = tk.Label(frame, text="", bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 11))
st.pack(pady=10)
def upd():
    hp.config(text="Seu HP: %d/100" % S["hp"])
    bhp.config(text="Boss HP: %d/200" % S["boss"])
    if S["boss"] <= 0: st.config(text="VITORIA! ENTER para jogar de novo", fg="#4caf50"); S["alive"] = False
    elif S["hp"] <= 0: st.config(text="DERROTA! ENTER para tentar de novo", fg="#f44336"); S["alive"] = False
def attack():
    if not S["alive"]: return
    dmg = random.randint(10, 30); S["boss"] -= dmg
    if S["boss"] > 0:
        boss_dmg = random.randint(5, 20); S["hp"] -= boss_dmg
        st.config(text="Voce: -%d | Boss: -%d" % (dmg, boss_dmg))
    upd()
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym == "Return":
        if S["alive"]: attack()
        else: S.update({"hp": 100, "boss": 200, "alive": True}); upd()
frame.bind("<KeyPress>", key)
frame.focus_set(); upd()
tk.Label(frame, text="ENTER para atacar | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack()
