import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"g": [[0]*4 for _ in range(4)], "score": 0}
def add():
    em = [(r,c) for r in range(4) for c in range(4) if S["g"][r][c]==0]
    if em:
        r,c = random.choice(em); S["g"][r][c] = 2 if random.random()<0.9 else 4
colors = {2:"#eee4da",4:"#ede0c8",8:"#f2b179",16:"#f59563",32:"#f67c5f"}
cv = tk.Canvas(frame, bg="#1a1a24", highlightthickness=0, width=440, height=440)
cv.pack(pady=10)
lbl = tk.Label(frame, text="Score: 0", bg="#0a0a0f", fg="#ffeb3b", font=("Consolas", 14, "bold"))
lbl.pack()
def draw():
    cv.delete("all")
    cs = 105; pad = 10
    for r in range(4):
        for c in range(4):
            x = c*(cs+pad)+pad; y = r*(cs+pad)+pad
            v = S["g"][r][c]
            if v == 0: cv.create_rectangle(x,y,x+cs,y+cs, fill="#2a2a3a", outline="")
            else:
                cv.create_rectangle(x,y,x+cs,y+cs, fill=colors.get(v,"#3c3a32"), outline="")
                cv.create_text(x+cs//2, y+cs//2, text=str(v), fill="white", font=("Segoe UI", 24, "bold"))
    lbl.config(text="Score: %d" % S["score"])
def move(d):
    mv = False
    if d == "left":
        for r in range(4):
            row = [x for x in S["g"][r] if x]; new = []; i = 0
            while i < len(row):
                if i+1 < len(row) and row[i]==row[i+1]: new.append(row[i]*2); S["score"] += row[i]*2; i += 2
                else: new.append(row[i]); i += 1
            new += [0]*(4-len(new))
            if new != S["g"][r]: mv = True; S["g"][r] = new
    elif d == "right":
        for r in range(4):
            row = [x for x in S["g"][r] if x]; new = []; i = len(row)-1
            while i >= 0:
                if i-1 >= 0 and row[i]==row[i-1]: new.insert(0, row[i]*2); S["score"] += row[i]*2; i -= 2
                else: new.insert(0, row[i]); i -= 1
            new = [0]*(4-len(new)) + new
            if new != S["g"][r]: mv = True; S["g"][r] = new
    elif d == "up":
        for c in range(4):
            col = [S["g"][r][c] for r in range(4) if S["g"][r][c]]; new = []; i = 0
            while i < len(col):
                if i+1 < len(col) and col[i]==col[i+1]: new.append(col[i]*2); S["score"] += col[i]*2; i += 2
                else: new.append(col[i]); i += 1
            new += [0]*(4-len(new))
            for r in range(4):
                if S["g"][r][c] != new[r]: mv = True
                S["g"][r][c] = new[r]
    elif d == "down":
        for c in range(4):
            col = [S["g"][r][c] for r in range(4) if S["g"][r][c]]; new = []; i = len(col)-1
            while i >= 0:
                if i-1 >= 0 and col[i]==col[i-1]: new.insert(0, col[i]*2); S["score"] += col[i]*2; i -= 2
                else: new.insert(0, col[i]); i -= 1
            new = [0]*(4-len(new)) + new
            for r in range(4):
                if S["g"][r][c] != new[r]: mv = True
                S["g"][r][c] = new[r]
    if mv: add(); draw()
def key(ev):
    if ev.keysym == "Escape": return
    d = ev.keysym.lower()
    if d in ("up","down","left","right"): move(d)
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force()
add(); add(); draw()
