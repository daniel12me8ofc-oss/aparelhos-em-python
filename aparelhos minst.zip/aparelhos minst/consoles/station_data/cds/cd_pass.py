import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="GERADOR DE SENHA", bg="#0a0a0f", fg="#e91e63", font=("Segoe UI", 18, "bold")).pack(pady=15)
l = tk.Label(frame, text="", bg="#0a0a0f", fg="#00d4ff", font=("Consolas", 18, "bold"), wraplength=400)
l.pack(pady=20)
def gen():
    import string
    chars = string.ascii_letters + string.digits + "!@#$%&*"
    l.config(text="".join(random.choice(chars) for _ in range(16)))
tk.Button(frame, text="GERAR", bg="#e91e63", fg="white", font=("Segoe UI", 14, "bold"),
          command=gen, padx=40, pady=12, relief="flat").pack(pady=20)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack()
