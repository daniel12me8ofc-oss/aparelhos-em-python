import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
cv = tk.Canvas(frame, bg="#87ceeb", highlightthickness=0)
cv.pack(fill="both", expand=True)
frame.update_idletasks()
W = cv.winfo_width() or 800; H = cv.winfo_height() or 500
S = {"y": H//2, "vy": 0, "pipes": [], "sc": 0, "alive": True, "t": 0}
PW, GAP = 60, 150
def draw():
    cv.delete("all")
    cv.create_rectangle(0, 0, W, H, fill="#87ceeb", outline="")
    for p in S["pipes"]:
        cv.create_rectangle(p["x"], 0, p["x"]+PW, p["top"], fill="#4caf50", outline="")
        cv.create_rectangle(p["x"], p["top"]+GAP, p["x"]+PW, H, fill="#4caf50", outline="")
    cv.create_oval(60, S["y"]-15, 90, S["y"]+15, fill="#ffc107", outline="")
    cv.create_text(W-15, 20, anchor="e", text="Score: %d" % S["sc"], fill="white", font=("Consolas", 14, "bold"))
    if not S["alive"]: cv.create_text(W//2, H//2, text="GAME OVER - ENTER", fill="white", font=("Segoe UI", 24, "bold"))
def step():
    if not S["alive"]: return
    S["vy"] += 0.5; S["y"] += S["vy"]; S["t"] += 1
    if S["t"] % 90 == 0: S["pipes"].append({"x": W, "top": random.randint(80, H-80-GAP), "p": False})
    for p in S["pipes"][:]:
        p["x"] -= 4
        if p["x"] + PW < 0: S["pipes"].remove(p); continue
        if not p["p"] and p["x"] + PW < 60: p["p"] = True; S["sc"] += 1
        if 45 < p["x"] < 105:
            if S["y"]-15 < p["top"] or S["y"]+15 > p["top"]+GAP: S["alive"] = False
    if S["y"] > H or S["y"] < 0: S["alive"] = False
    draw()
    frame.after(20, step)
def key(ev):
    if ev.keysym == "Escape": return
    if ev.keysym in ("space","Up","Return"):
        if S["alive"]: S["vy"] = -8
        else: S.update({"y": H//2, "vy": 0, "pipes": [], "sc": 0, "alive": True, "t": 0}); step()
frame.bind("<KeyPress>", key)
cv.focus_set(); frame.focus_force(); step()
