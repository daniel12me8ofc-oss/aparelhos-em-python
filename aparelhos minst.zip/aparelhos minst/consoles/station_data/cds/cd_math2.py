import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
S = {"a": random.randint(1,10), "b": random.randint(1,10), "score": 0}
q = tk.Label(frame, text="", bg="#0a0a0f", fg="#ff9800", font=("Segoe UI", 40, "bold"))
q.pack(pady=30)
def newq():
    S["a"] = random.randint(1,10); S["b"] = random.randint(1,10)
    q.config(text="%d + %d = ?" % (S["a"], S["b"]))
e = tk.Entry(frame, bg="#1e1e2a", fg="white", font=("Segoe UI", 20), relief="flat", justify="center")
e.pack(padx=60, pady=20, ipady=8, fill="x")
e.focus_set()
st = tk.Label(frame, text="Score: 0", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 12, "bold"))
st.pack()
def check(ev=None):
    try:
        if int(e.get()) == S["a"]+S["b"]: S["score"] += 1; st.config(text="Score: %d" % S["score"])
        e.delete(0, "end"); newq()
    except: e.delete(0, "end")
e.bind("<Return>", check)
newq()
tk.Label(frame, text="Resposta + ENTER | ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
