import tkinter as tk
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
syms = ["A","B","C","D"] * 2
random.shuffle(syms)
S = {"rev": [], "mat": set(), "btns": []}
st = tk.Label(frame, text="Ache os pares!", bg="#0a0a0f", fg="white", font=("Segoe UI", 14, "bold"))
st.pack(pady=10)
g = tk.Frame(frame, bg="#0a0a0f"); g.pack()
def unres():
    for i in S["rev"]: S["btns"][i].config(text="?", bg="#1e1e2a")
    S["rev"] = []
def flip(i):
    if i in S["mat"] or i in S["rev"]: return
    S["rev"].append(i); S["btns"][i].config(text=syms[i], bg="#9c27b0")
    if len(S["rev"]) == 2:
        a, b = S["rev"][0], S["rev"][1]
        if syms[a] == syms[b]:
            S["mat"].add(a); S["mat"].add(b); S["rev"] = []
            st.config(text="Par! %d/4" % (len(S["mat"])//2))
            if len(S["mat"]) == 8: st.config(text="VITORIA!")
        else: frame.after(600, unres)
for i in range(8):
    b = tk.Button(g, text="?", bg="#1e1e2a", fg="white", font=("Segoe UI", 20, "bold"),
                  width=4, height=2, relief="flat", command=lambda i=i: flip(i))
    b.grid(row=i//4, column=i%4, padx=3, pady=3)
    S["btns"].append(b)
tk.Label(frame, text="ESC volta", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
