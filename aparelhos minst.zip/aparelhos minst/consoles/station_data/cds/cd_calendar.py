import tkinter as tk, calendar, datetime
frame = tk.Frame(parent, bg="#0a0a0f")
frame.pack(fill="both", expand=True)
tk.Label(frame, text="CALENDARIO", bg="#0a0a0f", fg="#4caf50", font=("Segoe UI", 18, "bold")).pack(pady=15)
now = datetime.datetime.now()
title = tk.Label(frame, text=now.strftime("%B %Y"), bg="#0a0a0f", fg="#00d4ff", font=("Segoe UI", 14, "bold"))
title.pack()
g = tk.Frame(frame, bg="#0a0a0f"); g.pack(pady=10)
for i, dname in enumerate(["S","T","Q","Q","S","S","D"]):
    tk.Label(g, text=dname, bg="#0a0a0f", fg="#7a7a8a", font=("Segoe UI", 9, "bold"),
             width=4).grid(row=0, column=i)
cal = calendar.monthcalendar(now.year, now.month)
for r, week in enumerate(cal):
    for c, day in enumerate(week):
        if day == 0:
            tk.Label(g, text="", bg="#0a0a0f", width=4, height=1).grid(row=r+1, column=c)
        else:
            color = "#4caf50" if day == now.day else "#1e1e2a"
            fg = "white" if day == now.day else "#aaa"
            tk.Label(g, text=str(day), bg=color, fg=fg, font=("Segoe UI", 10),
                     width=4, height=1).grid(row=r+1, column=c, padx=1, pady=1)
tk.Label(frame, text="ESC para voltar", bg="#0a0a0f", fg="#7a7a8a").pack(pady=10)
