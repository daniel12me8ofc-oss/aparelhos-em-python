# -*- coding: utf-8 -*-
# minstcaveOS v9.0 - Final Edition
# Python 3.4.4 / Windows 7 32 bits
# ESTE SISTEMA OPERACIONAL E PARA ESTUDANTES

import os
import sys
import time
import datetime
import hashlib
import json
import random
import shutil
import traceback

import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

# ============================================================
# CONFIG
# ============================================================
VERSION = "9.0"
CODENAME = "Final"

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "minstcave_data")
HOME_DIR = os.path.join(DATA, "home")
USERS_FILE = os.path.join(DATA, "users.json")
CONFIG_FILE = os.path.join(DATA, "config.json")
INSTALLED_FILE = os.path.join(DATA, "installed.json")
WIDGETS_FILE = os.path.join(DATA, "widgets.json")

# Cores refinadas
BG_ROOT = "#080d17"
BG_DARK = "#0d1b2a"
BG_MID = "#1b263b"
BG_PANEL = "#243447"
BG_HOVER = "#2d4059"
BG_LIGHT = "#3a5068"

ACCENT = "#4dd0e1"
ACCENT_DK = "#26a3b5"
SUCCESS = "#4caf50"
WARNING = "#ffb74d"
ERROR = "#ef5350"
INFO = "#42a5f5"
PURPLE = "#ab47bc"
PINK = "#ec407a"

TEXT = "#e8eef5"
TEXT_DIM = "#8899aa"
TEXT_MUTED = "#5a6d80"

BORDER = "#2d3f54"

WALLPAPERS = [
    ("Oceano", "#0d1b2a", "#1b263b"),
    ("Floresta", "#0d2a1a", "#1b3b2a"),
    ("Aurora", "#1a0d2a", "#2a1b3b"),
    ("Deserto", "#2a1a0d", "#3b2a1b"),
    ("Vulcao", "#2a0d0d", "#3b1b1b"),
    ("Meia-noite", "#000000", "#1a1a2e"),
]

QUOTES = [
    "A simplicidade e a ultima sofisticacao.",
    "Programas devem ser escritos para pessoas lerem.",
    "A melhor maneira de prever o futuro e inventa-lo.",
    "Todo grande projeto comecou com uma linha de codigo.",
    "A pratica leva a perfeicao.",
    "Aprender e como remar contra a corrente.",
]

APPS = []
MAIN = None

# ============================================================
# HELPERS
# ============================================================
def ensure_dirs():
    for d in [DATA, HOME_DIR]:
        if not os.path.exists(d):
            try:
                os.makedirs(d)
            except:
                pass
    for sub in ["Documents", "Pictures", "Downloads", "Music", "Videos"]:
        p = os.path.join(HOME_DIR, sub)
        if not os.path.exists(p):
            try:
                os.makedirs(p)
            except:
                pass

def hash_pw(p):
    return hashlib.sha256(p.encode("utf-8")).hexdigest()

def load_json(path, default):
    try:
        if os.path.exists(path):
            f = open(path, "r")
            d = json.load(f)
            f.close()
            return d
    except:
        pass
    return default

def save_json(path, data):
    try:
        f = open(path, "w")
        json.dump(data, f)
        f.close()
    except:
        pass

def get_installed():
    installed = load_json(INSTALLED_FILE, None)
    if installed is None:
        installed = ["Configuracoes"]
        save_json(INSTALLED_FILE, installed)
    return installed

def is_installed(key):
    return key in get_installed()

def install_app(key):
    installed = get_installed()
    if key not in installed:
        installed.append(key)
        save_json(INSTALLED_FILE, installed)

def uninstall_app(key):
    if key == "Configuracoes":
        return
    installed = get_installed()
    if key in installed:
        installed.remove(key)
        save_json(INSTALLED_FILE, installed)

def get_app_entry(key):
    for e in APPS:
        if e[0] == key:
            return e
    return None

def disk_used_mb():
    home_size = 0
    try:
        for root, dirs, files in os.walk(HOME_DIR):
            for f in files:
                try:
                    home_size += os.path.getsize(os.path.join(root, f))
                except:
                    pass
    except:
        pass
    home_mb = home_size / 1024.0 / 1024.0
    apps_mb = 0
    for key in get_installed():
        entry = get_app_entry(key)
        if entry:
            apps_mb += entry[2]
    return 60 + home_mb + apps_mb

def disk_total_mb():
    return 8192

def disk_free_mb():
    return disk_total_mb() - disk_used_mb()

def safe_after(widget, ms, fn):
    try:
        if widget.winfo_exists():
            widget.after(ms, fn)
    except:
        pass

# ============================================================
# WINDOW HELPER
# ============================================================
def new_win(parent, title, color, w, h):
    win = tk.Toplevel(parent)
    win.title(title)
    win.geometry(str(w) + "x" + str(h))
    win.configure(bg=BG_DARK)
    try:
        win.lift()
        win.focus_force()
    except:
        pass
    header = tk.Frame(win, bg=BG_MID, height=46)
    header.pack(fill="x")
    header.pack_propagate(False)
    tk.Label(header, text="  " + title[0].upper() + "  ", bg=color, fg="white",
             font=("Segoe UI", 12, "bold"), width=3).pack(side="left", padx=(10, 8), pady=8)
    tk.Label(header, text=title, bg=BG_MID, fg=color,
             font=("Segoe UI", 12, "bold")).pack(side="left", pady=10)
    body = tk.Frame(win, bg=BG_DARK)
    body.pack(fill="both", expand=True, padx=14, pady=14)
    return win, body

# ============================================================
# TOAST NOTIFICATIONS
# ============================================================
class Toast(object):
    active = []
    COLORS = {"info": ACCENT, "success": SUCCESS, "warning": WARNING, "error": ERROR}

    def __init__(self, parent, title, message, kind="info", duration=3500):
        self.parent = parent
        self.duration = duration
        color = self.COLORS.get(kind, ACCENT)

        try:
            win = tk.Toplevel(parent)
            win.overrideredirect(True)
            win.attributes("-topmost", True)
            win.configure(bg=color)

            # Posicao inicial (canto inferior direito)
            try:
                px = parent.winfo_x()
                py = parent.winfo_y()
                pw = parent.winfo_width()
                ph = parent.winfo_height()
            except:
                px, py, pw, ph = 200, 100, 1000, 700

            # Empilha toasts
            offset = 0
            for t in Toast.active:
                try:
                    if t.win.winfo_exists():
                        offset += 85
                except:
                    pass

            x = px + pw - 340
            y = py + ph - 130 - offset
            win.geometry("320x80+%d+%d" % (x, y))

            # Barra colorida lateral
            tk.Frame(win, bg=color, width=6).pack(side="left", fill="y")

            inner = tk.Frame(win, bg=BG_MID)
            inner.pack(side="left", fill="both", expand=True, padx=10, pady=8)

            tk.Label(inner, text=title, bg=BG_MID, fg=color,
                     font=("Segoe UI", 10, "bold"), anchor="w").pack(fill="x")
            tk.Label(inner, text=message, bg=BG_MID, fg=TEXT,
                     font=("Segoe UI", 9), anchor="w", wraplength=280,
                     justify="left").pack(fill="x", pady=(2, 0))

            self.win = win
            Toast.active.append(self)

            try:
                win.after(duration, self.dismiss)
            except:
                pass
        except:
            pass

    def dismiss(self):
        try:
            if self.win.winfo_exists():
                self.win.destroy()
        except:
            pass
        try:
            if self in Toast.active:
                Toast.active.remove(self)
        except:
            pass

# ============================================================
# BOOT
# ============================================================
def boot():
    try:
        os.system("cls" if os.name == "nt" else "clear")

        # BIOS
        print("")
        print("  minstcaveOS BIOS v" + VERSION + "  (C) 2025-2026")
        print("")
        print("  CPU  : Pentium(R) Dual-Core @ 2.60GHz")
        print("  RAM  : 4096 MB OK")
        print("  DISK : MINSTCAVE_HDD 8192 MB")
        print("  VID  : Integrated Graphics")
        print("")
        print("  Detectando dispositivos USB...")
        time.sleep(0.2)
        print("    Porta 1: OK (Teclado)")
        print("    Porta 2: OK (Mouse)")
        print("")
        print("  ==========================================")
        print("   ESTE SISTEMA OPERACIONAL E PARA ESTUDANTES")
        print("  ==========================================")
        print("")
        print("  Pressione DEL para entrar no SETUP")
        time.sleep(1.3)

        os.system("cls" if os.name == "nt" else "clear")

        # Logo splash
        print("")
        print("")
        print("         __  ____       __  _____ __")
        print("        /  |/  (_)___  / /_/ ___// /____ _ _   _____")
        print("       / /|_/ / / __ \\/ __/\\__ \\/ __/ _ `/ | / / _ \\")
        print("      / /  / / / / / / /_ ___/ / /_/ __/| |/ /  __/")
        print("     /_/  /_/_/_/ /_/\\__//____/\\__/\\__/ |___/\\___/")
        print("")
        print("                 v" + VERSION + " - " + CODENAME)
        print("")
        time.sleep(0.8)

        os.system("cls" if os.name == "nt" else "clear")

        # Loading com barras
        phases = [
            ("Carregando kernel", 15),
            ("Iniciando drivers", 25),
            ("Montando disco", 15),
            ("Iniciando sessao", 20),
            ("Preparando interface", 25),
        ]

        print("")
        print("  minstcaveOS " + VERSION + " - Iniciando")
        print("")

        for name, count in phases:
            sys.stdout.write("  " + name.ljust(24) + " [")
            sys.stdout.flush()
            for i in range(20):
                time.sleep(0.025)
                sys.stdout.write("=")
                sys.stdout.flush()
            print("] OK")

        print("")
        print("  Tudo pronto.")
        time.sleep(0.3)
        print("  Abrindo interface grafica...")
        time.sleep(0.4)
    except:
        pass

# ============================================================
# APP: ARQUIVOS (sidebar + breadcrumb + drag-drop)
# ============================================================
def app_files(parent):
    win, body = new_win(parent, "Meus Arquivos", ACCENT, 950, 640)
    state = {"path": HOME_DIR}

    # Layout: sidebar | main
    sidebar = tk.Frame(body, bg=BG_MID, width=180)
    sidebar.pack(side="left", fill="y", padx=(0, 12))
    sidebar.pack_propagate(False)

    tk.Label(sidebar, text="ACESSO RAPIDO", bg=BG_MID, fg=TEXT_MUTED,
             font=("Segoe UI", 8, "bold"), pady=8).pack(fill="x", padx=10)

    def goto(path):
        state["path"] = path
        refresh()

    quick = [
        ("Home", HOME_DIR),
        ("Documents", os.path.join(HOME_DIR, "Documents")),
        ("Pictures", os.path.join(HOME_DIR, "Pictures")),
        ("Downloads", os.path.join(HOME_DIR, "Downloads")),
        ("Music", os.path.join(HOME_DIR, "Music")),
        ("Videos", os.path.join(HOME_DIR, "Videos")),
    ]

    for name, path in quick:
        b = tk.Button(sidebar, text="  " + name, bg=BG_MID, fg=TEXT,
                      anchor="w", relief="flat", font=("Segoe UI", 10),
                      activebackground=BG_HOVER, activeforeground=ACCENT,
                      command=lambda p=path: goto(p))
        b.pack(fill="x", padx=8, pady=2, ipady=6)

    tk.Frame(sidebar, bg=BORDER, height=1).pack(fill="x", padx=10, pady=10)

    tk.Label(sidebar, text="DISCO", bg=BG_MID, fg=TEXT_MUTED,
             font=("Segoe UI", 8, "bold"), anchor="w").pack(fill="x", padx=10, pady=(5, 3))

    disk_bar = tk.Frame(sidebar, bg=BG_PANEL, height=6)
    disk_bar.pack(fill="x", padx=10, pady=3)
    disk_bar.pack_propagate(False)
    pct = disk_used_mb() / disk_total_mb()
    tk.Frame(disk_bar, bg=ACCENT if pct < 0.7 else WARNING, width=int(160 * pct)).pack(side="left", fill="y")

    tk.Label(sidebar, text="%.0f / %d MB" % (disk_used_mb(), disk_total_mb()),
             bg=BG_MID, fg=TEXT_DIM, font=("Segoe UI", 8)).pack(anchor="w", padx=10)

    # Main area
    main = tk.Frame(body, bg=BG_DARK)
    main.pack(side="left", fill="both", expand=True)

    # Breadcrumb
    crumb_frame = tk.Frame(main, bg=BG_DARK)
    crumb_frame.pack(fill="x", pady=(0, 8))

    def rebuild_breadcrumb():
        for w in crumb_frame.winfo_children():
            w.destroy()
        parts = []
        p = state["path"]
        rel = p.replace(HOME_DIR, "")
        if rel == "":
            parts = [("Home", HOME_DIR)]
        else:
            parts = [("Home", HOME_DIR)]
            cur = HOME_DIR
            for part in rel.split(os.sep):
                if part:
                    cur = os.path.join(cur, part)
                    parts.append((part, cur))

        for i, (name, path) in enumerate(parts):
            def mk(p=path):
                return lambda: goto(p)
            b = tk.Button(crumb_frame, text=name, bg=BG_DARK, fg=ACCENT,
                          relief="flat", font=("Segoe UI", 10),
                          activebackground=BG_DARK, activeforeground=ACCENT,
                          command=mk())
            b.pack(side="left")
            if i < len(parts) - 1:
                tk.Label(crumb_frame, text=" > ", bg=BG_DARK, fg=TEXT_MUTED,
                         font=("Segoe UI", 9)).pack(side="left")

        tk.Button(crumb_frame, text="+ Pasta", bg=ACCENT, fg=BG_DARK,
                  relief="flat", font=("Segoe UI", 9, "bold"),
                  command=lambda: new_folder()).pack(side="right", padx=2, ipady=4)
        tk.Button(crumb_frame, text="+ Arquivo", bg=SUCCESS, fg="white",
                  relief="flat", font=("Segoe UI", 9, "bold"),
                  command=lambda: new_file()).pack(side="right", padx=2, ipady=4)

    def new_folder():
        n = simpledialog.askstring("Nova pasta", "Nome:")
        if not n:
            return
        try:
            os.makedirs(os.path.join(state["path"], n))
            refresh()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def new_file():
        n = simpledialog.askstring("Novo arquivo", "Nome:")
        if not n:
            return
        c = simpledialog.askstring("Conteudo", "Digite o conteudo:")
        if c is None:
            c = ""
        try:
            f = open(os.path.join(state["path"], n), "w")
            f.write(c)
            f.close()
            refresh()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    # Grid area
    canvas = tk.Canvas(main, bg=BG_DARK, highlightthickness=0)
    canvas.pack(fill="both", expand=True)
    sb = tk.Scrollbar(main, orient="vertical", command=canvas.yview)
    sb.pack(side="right", fill="y")
    canvas.configure(yscrollcommand=sb.set)

    grid_frame = tk.Frame(canvas, bg=BG_DARK)
    canvas.create_window((0, 0), window=grid_frame, anchor="nw", tags="grid")

    def on_config(event):
        canvas.itemconfig("grid", width=event.width)
        grid_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))
    canvas.bind("<Configure>", on_config)

    info_lbl = tk.Label(main, text="", bg=BG_DARK, fg=TEXT_DIM,
                        font=("Segoe UI", 9), anchor="w")
    info_lbl.pack(fill="x", pady=(6, 0))

    # Drag state
    DRAG = {"item": None, "ghost": None, "lbl": None, "active": False}

    def start_press(event, item_path):
        DRAG["item"] = item_path
        DRAG["active"] = False
        DRAG["sx"] = event.x_root
        DRAG["sy"] = event.y_root
        try:
            win.bind_all("<B1-Motion>", on_motion, add="+")
            win.bind_all("<ButtonRelease-1>", on_release, add="+")
        except:
            pass

    def on_motion(event):
        if not DRAG.get("item"):
            return
        if not DRAG["active"]:
            if abs(event.x_root - DRAG["sx"]) < 6 and abs(event.y_root - DRAG["sy"]) < 6:
                return
            DRAG["active"] = True
            try:
                g = tk.Toplevel(win)
                g.overrideredirect(True)
                g.attributes("-topmost", True)
                g.configure(bg=WARNING)
                g.geometry("160x46+%d+%d" % (event.x_root + 15, event.y_root + 15))
                lbl = tk.Label(g, text="  Movendo...", bg=WARNING, fg=BG_DARK,
                               font=("Segoe UI", 9, "bold"), anchor="w", padx=8)
                lbl.pack(fill="both", expand=True)
                DRAG["ghost"] = g
                DRAG["lbl"] = lbl
            except:
                pass

        try:
            g = DRAG.get("ghost")
            if g:
                g.geometry("+%d+%d" % (event.x_root + 15, event.y_root + 15))
                t = find_folder(event.x_root, event.y_root)
                color = SUCCESS if t else WARNING
                g.configure(bg=color)
                DRAG["lbl"].configure(bg=color)
        except:
            pass

    def find_folder(x, y):
        g = DRAG.get("ghost")
        if g:
            try:
                g.withdraw()
            except:
                pass
        w = None
        try:
            w = win.winfo_containing(x, y)
        except:
            pass
        if g:
            try:
                g.deiconify()
            except:
                pass
        while w:
            fp = getattr(w, "_folder", None)
            if fp:
                return fp
            try:
                w = w.master
            except:
                break
        return None

    def on_release(event):
        try:
            win.unbind_all("<B1-Motion>")
            win.unbind_all("<ButtonRelease-1>")
        except:
            pass
        g = DRAG.get("ghost")
        if g:
            try:
                g.destroy()
            except:
                pass
        if DRAG["active"] and DRAG.get("item"):
            target = find_folder(event.x_root, event.y_root)
            if target:
                move_item(DRAG["item"], target)
        DRAG["item"] = None
        DRAG["ghost"] = None
        DRAG["lbl"] = None
        DRAG["active"] = False
        refresh()

    def move_item(src, dst):
        if not os.path.exists(src) or os.path.dirname(src) == dst or src == dst:
            return
        if os.path.isdir(src) and dst.startswith(src + os.sep):
            messagebox.showerror("Erro", "Nao pode mover para dentro dela mesma")
            return
        name = os.path.basename(src)
        dest = os.path.join(dst, name)
        if os.path.exists(dest):
            messagebox.showerror("Erro", "Ja existe '" + name + "'")
            return
        try:
            shutil.move(src, dest)
            if MAIN:
                MAIN.toast("Movido", name + " -> " + os.path.basename(dst), "success")
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def open_item(path, folder):
        if folder:
            state["path"] = path
            refresh()
        else:
            try:
                f = open(path, "r")
                c = f.read()
                f.close()
                messagebox.showinfo(os.path.basename(path), c[:2000])
            except Exception as e:
                messagebox.showerror("Erro", str(e))

    def delete_item(path):
        if not messagebox.askyesno("Deletar", "Deletar '" + os.path.basename(path) + "'?"):
            return
        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
            refresh()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def rename_item(path):
        old = os.path.basename(path)
        new = simpledialog.askstring("Renomear", "Novo nome:", initialvalue=old)
        if not new or new == old:
            return
        p = os.path.dirname(path)
        np = os.path.join(p, new)
        if os.path.exists(np):
            messagebox.showerror("Erro", "Nome ja existe")
            return
        try:
            os.rename(path, np)
            refresh()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def render_card(row_frame, name, path, folder):
        color = ACCENT if folder else BG_LIGHT
        icon = "F" if folder else "D"

        outer = tk.Frame(row_frame, bg=BG_DARK)
        outer.pack(side="left", padx=8, pady=8)

        card = tk.Frame(outer, bg=color, width=80, height=80, cursor="hand2")
        card.pack()
        card.pack_propagate(False)

        lbl = tk.Label(card, text=icon, bg=color, fg="white",
                       font=("Segoe UI", 30, "bold"), cursor="hand2")
        lbl.pack(expand=True)

        name_lbl = tk.Label(outer, text=name[:14], bg=BG_DARK, fg=TEXT,
                            font=("Segoe UI", 9), wraplength=84, cursor="hand2")
        name_lbl.pack(pady=(4, 0))

        if folder:
            card._folder = path
            lbl._folder = path
            name_lbl._folder = path

        def dbl(e, p=path, f=folder):
            open_item(p, f)
        for w in [card, lbl, name_lbl]:
            w.bind("<Double-Button-1>", dbl)
            w.bind("<ButtonPress-1>", lambda e, p=path: start_press(e, p))

        def right(e, p=path, f=folder):
            m = tk.Menu(win, tearoff=0, bg=BG_PANEL, fg=TEXT,
                        activebackground=ACCENT, activeforeground=BG_DARK)
            m.add_command(label="Abrir", command=lambda: open_item(p, f))
            m.add_command(label="Renomear", command=lambda: rename_item(p))
            m.add_separator()
            m.add_command(label="Deletar", command=lambda: delete_item(p))
            try:
                m.tk_popup(e.x_root, e.y_root)
            except:
                pass
        for w in [card, lbl, name_lbl]:
            w.bind("<Button-3>", right)

    def refresh():
        rebuild_breadcrumb()
        for w in grid_frame.winfo_children():
            w.destroy()
        try:
            items = sorted(os.listdir(state["path"]))
        except Exception as e:
            info_lbl.config(text="Erro: " + str(e))
            return
        folders = []
        files = []
        for it in items:
            full = os.path.join(state["path"], it)
            if os.path.isdir(full):
                folders.append(it)
            else:
                files.append(it)

        cols = 8
        row = None
        cnt = 0

        if state["path"] != HOME_DIR:
            parent_dir = os.path.dirname(state["path"])
            if parent_dir.startswith(HOME_DIR):
                row = tk.Frame(grid_frame, bg=BG_DARK)
                row.pack(fill="x")
                outer = tk.Frame(row, bg=BG_DARK)
                outer.pack(side="left", padx=8, pady=8)
                card = tk.Frame(outer, bg=BG_PANEL, width=80, height=80, cursor="hand2")
                card.pack()
                card.pack_propagate(False)
                tk.Label(card, text="..", bg=BG_PANEL, fg="white",
                         font=("Segoe UI", 24, "bold")).pack(expand=True)
                tk.Label(outer, text="(voltar)", bg=BG_DARK, fg=TEXT_DIM,
                         font=("Segoe UI", 9)).pack(pady=4)

                card._folder = parent_dir
                for w in card.winfo_children():
                    w._folder = parent_dir
                    w.bind("<Double-Button-1>", lambda e, p=parent_dir: goto(p))
                card.bind("<Double-Button-1>", lambda e, p=parent_dir: goto(p))
                cnt = 1

        for name in folders + files:
            full = os.path.join(state["path"], name)
            is_folder = os.path.isdir(full)
            if row is None or cnt >= cols:
                row = tk.Frame(grid_frame, bg=BG_DARK)
                row.pack(fill="x", anchor="w")
                cnt = 0
            render_card(row, name, full, is_folder)
            cnt += 1

        info_lbl.config(text="%d pastas, %d arquivos  |  Arraste para mover" %
                        (len(folders), len(files)))
        grid_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))

    def on_wheel(event):
        try:
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except:
            pass
    try:
        canvas.bind_all("<MouseWheel>", on_wheel)
    except:
        pass

    refresh()
    return win

# ============================================================
# APP: CAVESTORE (grid de cards + categorias)
# ============================================================
def app_store(parent):
    win, body = new_win(parent, "CaveStore", SUCCESS, 900, 660)

    # Header
    header = tk.Frame(body, bg=BG_MID)
    header.pack(fill="x", pady=(0, 12))
    tk.Label(header, text="Store", bg=BG_MID, fg=SUCCESS,
             font=("Segoe UI", 14, "bold")).pack(side="left", padx=15, pady=10)
    tk.Label(header, text="Instale apps", bg=BG_MID, fg=TEXT_DIM,
             font=("Segoe UI", 9)).pack(side="left")

    disk_lbl = tk.Label(header, text="", bg=BG_MID, fg=ACCENT,
                        font=("Segoe UI", 9, "bold"))
    disk_lbl.pack(side="right", padx=15)

    def update_disk():
        try:
            if disk_lbl.winfo_exists():
                disk_lbl.config(text="Disco: %.0f / %d MB" %
                                (disk_used_mb(), disk_total_mb()))
        except:
            pass
    update_disk()

    # Search
    sf = tk.Frame(body, bg=BG_DARK)
    sf.pack(fill="x", pady=(0, 10))
    tk.Label(sf, text="Buscar:", bg=BG_DARK, fg=TEXT_DIM,
             font=("Segoe UI", 9)).pack(side="left", padx=(0, 5))
    search_var = tk.StringVar()
    se = tk.Entry(sf, textvariable=search_var, bg=BG_PANEL, fg=TEXT,
                  insertbackground=ACCENT, relief="flat",
                  font=("Segoe UI", 10))
    se.pack(side="left", fill="x", expand=True, ipady=6, padx=(0, 8))
    se.insert(0, "")

    # Category tabs
    cats_frame = tk.Frame(body, bg=BG_DARK)
    cats_frame.pack(fill="x", pady=(0, 10))
    current_cat = tk.StringVar(value="Todos")

    def set_cat(c):
        current_cat.set(c)
        for w in cats_frame.winfo_children():
            w.destroy()
        build_cats()

    def build_cats():
        all_cats = ["Todos"]
        for e in APPS:
            if e[7] not in all_cats:
                all_cats.append(e[7])
        for c in all_cats:
            active = (c == current_cat.get())
            bg = ACCENT if active else BG_PANEL
            fg = BG_DARK if active else TEXT
            tk.Button(cats_frame, text=c, bg=bg, fg=fg, relief="flat",
                      font=("Segoe UI", 9, "bold" if active else "normal"),
                      command=lambda x=c: set_cat(x)).pack(side="left", padx=3, ipady=4, ipadx=10)

    # Main grid
    canvas = tk.Canvas(body, bg=BG_DARK, highlightthickness=0)
    canvas.pack(fill="both", expand=True)
    sb = tk.Scrollbar(body, orient="vertical", command=canvas.yview)
    sb.pack(side="right", fill="y")
    canvas.configure(yscrollcommand=sb.set)

    inner = tk.Frame(canvas, bg=BG_DARK)
    canvas.create_window((0, 0), window=inner, anchor="nw", tags="inner")
    canvas.bind("<Configure>", lambda e: canvas.itemconfig("inner", width=e.width))

    def render_card(row, entry):
        key = entry[0]
        size_mb = entry[2]
        color = entry[3]
        icon = entry[4]
        desc = entry[5]
        installed = is_installed(key)

        card = tk.Frame(row, bg=BG_PANEL, padx=0, pady=0, width=220, height=160)
        card.pack(side="left", padx=6, pady=6)
        card.pack_propagate(False)

        top = tk.Frame(card, bg=color, height=50)
        top.pack(fill="x")
        top.pack_propagate(False)
        tk.Label(top, text=icon, bg=color, fg="white",
                 font=("Segoe UI", 22, "bold")).pack(expand=True)

        info = tk.Frame(card, bg=BG_PANEL)
        info.pack(fill="both", expand=True, padx=10, pady=8)

        tk.Label(info, text=key, bg=BG_PANEL, fg=TEXT,
                 font=("Segoe UI", 11, "bold"), anchor="w").pack(fill="x")
        tk.Label(info, text=desc[:30] + ("..." if len(desc) > 30 else ""),
                 bg=BG_PANEL, fg=TEXT_DIM, font=("Segoe UI", 8),
                 anchor="w", wraplength=200, justify="left").pack(fill="x", pady=(2, 4))

        bot = tk.Frame(info, bg=BG_PANEL)
        bot.pack(fill="x")
        tk.Label(bot, text=str(size_mb) + " MB", bg=BG_PANEL, fg=TEXT_MUTED,
                 font=("Segoe UI", 8)).pack(side="left")

        if installed:
            tk.Label(bot, text="Instalado", bg=BG_PANEL, fg=SUCCESS,
                     font=("Segoe UI", 8, "bold")).pack(side="right")
        else:
            tk.Button(bot, text="Instalar", bg=SUCCESS, fg="white",
                      relief="flat", font=("Segoe UI", 8, "bold"),
                      command=lambda k=key: do_install(k)).pack(side="right", ipadx=8, ipady=2)

    def render_all():
        for w in inner.winfo_children():
            w.destroy()

        q = search_var.get().lower().strip()
        cat_filter = current_cat.get()

        filtered = []
        for e in APPS:
            if cat_filter != "Todos" and e[7] != cat_filter:
                continue
            if q and q not in e[0].lower() and q not in e[5].lower():
                continue
            filtered.append(e)

        if not filtered:
            tk.Label(inner, text="Nenhum app foi encontrado", bg=BG_DARK,
                     fg=TEXT_MUTED, font=("Segoe UI", 11)).pack(pady=50)
        else:
            row = None
            cnt = 0
            cols = 4
            for entry in filtered:
                if row is None or cnt >= cols:
                    row = tk.Frame(inner, bg=BG_DARK)
                    row.pack(fill="x", padx=10, pady=2)
                    cnt = 0
                render_card(row, entry)
                cnt += 1

        inner.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))

    def do_install(key):
        entry = get_app_entry(key)
        if entry and entry[2] > disk_free_mb():
            messagebox.showerror("Erro", "Disco cheio!")
            return
        install_app(key)
        update_disk()
        render_all()
        if MAIN:
            MAIN.refresh_icons()
            MAIN.toast("Instalado", key + " foi instalado", "success")

    se.bind("<KeyRelease>", lambda e: render_all())

    build_cats()
    render_all()
    return win

# ============================================================
# APP: CONFIGURACOES
# ============================================================
def app_config(parent):
    win, body = new_win(parent, "Configuracoes", ACCENT, 740, 600)

    tk.Button(body, text="ABRIR LOJA DE APPS", bg=SUCCESS, fg="white",
              relief="flat", font=("Segoe UI", 12, "bold"),
              command=lambda: app_store(parent)).pack(fill="x", pady=(0, 12), ipady=10)

    nb = ttk.Notebook(body)
    nb.pack(fill="both", expand=True)

    # Aparencia
    t1 = tk.Frame(nb, bg=BG_DARK)
    nb.add(t1, text="Aparencia")
    tk.Label(t1, text="Papel de parede", bg=BG_DARK, fg=TEXT,
             font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=20, pady=(15, 8))
    for i, (name, _, _) in enumerate(WALLPAPERS):
        def mk(idx):
            def cmd():
                cfg = load_json(CONFIG_FILE, {})
                cfg["wallpaper_idx"] = idx
                save_json(CONFIG_FILE, cfg)
                if MAIN:
                    MAIN.show_desktop()
                win.destroy()
            return cmd
        tk.Button(t1, text=name, bg=BG_PANEL, fg=TEXT, relief="flat",
                  font=("Segoe UI", 9), anchor="w",
                  command=mk(i)).pack(fill="x", padx=30, pady=2, ipady=4)

    # Armazenamento
    t2 = tk.Frame(nb, bg=BG_DARK)
    nb.add(t2, text="Armazenamento")
    tk.Label(t2, text="Uso do disco", bg=BG_DARK, fg=TEXT,
             font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=20, pady=(15, 8))
    used = disk_used_mb()
    total = disk_total_mb()
    pct = used * 100 / total if total > 0 else 0
    bar = tk.Frame(t2, bg=BG_PANEL, height=28)
    bar.pack(fill="x", padx=30, pady=10)
    bar.pack_propagate(False)
    col = SUCCESS
    if pct > 90:
        col = ERROR
    elif pct > 70:
        col = WARNING
    tk.Frame(bar, bg=col, width=int(6.6 * pct)).pack(side="left", fill="y")
    tk.Label(t2, text="%.1f MB de %d MB (%.1f%%)" % (used, total, pct),
             bg=BG_DARK, fg=TEXT_DIM, font=("Segoe UI", 10)).pack(anchor="w", padx=30)
    tk.Label(t2, text="Livre: %.1f MB" % disk_free_mb(),
             bg=BG_DARK, fg=SUCCESS, font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=30, pady=(5, 15))

    tk.Label(t2, text="Apps instalados:", bg=BG_DARK, fg=TEXT,
             font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=20, pady=(10, 5))
    for k in get_installed():
        tk.Label(t2, text="  " + k, bg=BG_DARK, fg=TEXT_DIM,
                 font=("Consolas", 9), anchor="w").pack(fill="x", padx=40)

    # Sistema
    t3 = tk.Frame(nb, bg=BG_DARK)
    nb.add(t3, text="Sistema")
    for lbl, val in [("Versao", VERSION), ("Codinome", CODENAME),
                     ("Kernel", "Python " + sys.version.split()[0]),
                     ("Plataforma", sys.platform),
                     ("Pasta", BASE)]:
        r = tk.Frame(t3, bg=BG_DARK)
        r.pack(fill="x", padx=20, pady=5)
        tk.Label(r, text=lbl, bg=BG_DARK, fg=TEXT_MUTED, width=15, anchor="w",
                 font=("Segoe UI", 9)).pack(side="left")
        tk.Label(r, text=val, bg=BG_DARK, fg=TEXT, font=("Consolas", 9),
                 anchor="w").pack(side="left")

    # Sobre
    t4 = tk.Frame(nb, bg=BG_DARK)
    nb.add(t4, text="Sobre")
    tk.Label(t4, text="minstcaveOS", bg=BG_DARK, fg=ACCENT,
             font=("Segoe UI", 24, "bold")).pack(pady=(40, 5))
    tk.Label(t4, text="Versao " + VERSION + " - " + CODENAME, bg=BG_DARK, fg=TEXT,
             font=("Segoe UI", 12)).pack()
    tk.Label(t4, text="ESTE SISTEMA OPERACIONAL E PARA ESTUDANTES",
             bg=BG_DARK, fg=WARNING, font=("Segoe UI", 11, "bold")).pack(pady=25)
    tk.Label(t4, text="Feito para aprender. Explore, crie, quebre e conserte.",
             bg=BG_DARK, fg=TEXT_DIM, font=("Segoe UI", 10)).pack()

    return win

# ============================================================
# APPS RESTANTES
# ============================================================
def app_readme(parent):
    win, body = new_win(parent, "LEIA-ME", ACCENT, 620, 500)
    tk.Label(body, text="ESTE SISTEMA OPERACIONAL", bg=BG_DARK, fg=ACCENT,
             font=("Segoe UI", 20, "bold")).pack(pady=(20, 5))
    tk.Label(body, text="E PARA ESTUDANTES", bg=BG_DARK, fg=WARNING,
             font=("Segoe UI", 24, "bold")).pack(pady=(0, 20))
    msg = (
        "Bem-vindo ao minstcaveOS!\n\n"
        "Este sistema foi feito para aprendizado.\n\n"
        "Primeiros passos:\n"
        "  1. Abra a CaveStore (botao LOJA na barra)\n"
        "  2. Instale os apps que quiser\n"
        "  3. Use Arquivos (com drag and drop)\n"
        "  4. Use Criador para programar seus apps\n\n"
        "Sobre o gerenciador de arquivos:\n"
        "  - Sidebar com acesso rapido\n"
        "  - Duplo clique abre pastas\n"
        "  - Arraste arquivo para pasta = move\n"
        "  - Botao direito: renomear / deletar\n\n"
        "Versao: " + VERSION + " (" + CODENAME + ")\n"
    )
    t = tk.Text(body, bg=BG_ROOT, fg=TEXT, font=("Segoe UI", 11),
                relief="flat", wrap="word", padx=15, pady=15)
    t.pack(fill="both", expand=True)
    t.insert("1.0", msg)
    t.config(state="disabled")
    return win

def app_notepad(parent):
    win, body = new_win(parent, "Notepad", WARNING, 720, 520)
    text = tk.Text(body, bg=BG_ROOT, fg=TEXT, insertbackground=WARNING,
                   font=("Consolas", 10), wrap="word", relief="flat",
                   padx=10, pady=10)
    text.pack(fill="both", expand=True)
    status = tk.Label(body, text="", bg=BG_DARK, fg=SUCCESS,
                      font=("Segoe UI", 9), anchor="w")
    status.pack(fill="x", pady=(5, 0))
    bar = tk.Frame(body, bg=BG_DARK)
    bar.pack(fill="x")
    def save():
        n = simpledialog.askstring("Salvar", "Nome:", initialvalue="nota.txt")
        if not n:
            return
        try:
            f = open(os.path.join(HOME_DIR, n), "w")
            f.write(text.get("1.0", "end-1c"))
            f.close()
            status.config(text="Salvo!")
            if MAIN:
                MAIN.toast("Salvo", n, "success")
        except Exception as e:
            status.config(text="Erro: " + str(e))
    def open_f():
        try:
            files = [f for f in os.listdir(HOME_DIR)
                     if os.path.isfile(os.path.join(HOME_DIR, f))]
            if not files:
                status.config(text="Vazio")
                return
            p = simpledialog.askstring("Abrir", "Arquivos:\n" + "\n".join(files))
            if p and p in files:
                f = open(os.path.join(HOME_DIR, p), "r")
                text.delete("1.0", "end")
                text.insert("1.0", f.read())
                f.close()
                status.config(text="Aberto: " + p)
        except Exception as e:
            status.config(text="Erro: " + str(e))
    tk.Button(bar, text="Abrir", bg=BG_PANEL, fg=TEXT, relief="flat",
              font=("Segoe UI", 9), command=open_f).pack(side="right", padx=2, ipady=3)
    tk.Button(bar, text="Salvar", bg=WARNING, fg=BG_DARK, relief="flat",
              font=("Segoe UI", 9, "bold"), command=save).pack(side="right", padx=2, ipady=3)
    return win

def app_calc(parent):
    win, body = new_win(parent, "Calculadora", PURPLE, 360, 500)
    disp = tk.Entry(body, bg=BG_ROOT, fg="white", insertbackground="white",
                    font=("Consolas", 18), justify="right", relief="flat")
    disp.pack(fill="x", pady=(0, 8), ipady=10)
    def press(v):
        if v == "C":
            disp.delete(0, "end")
        elif v == "=":
            try:
                expr = disp.get()
                ok = all(c in "0123456789+-*/(). " for c in expr)
                if ok:
                    r = eval(expr)
                    disp.delete(0, "end")
                    disp.insert(0, str(r))
            except:
                disp.delete(0, "end")
                disp.insert(0, "Erro")
        else:
            disp.insert("end", v)
    grid = tk.Frame(body, bg=BG_DARK)
    grid.pack(fill="both", expand=True)
    btns = [["C", "(", ")", "/"], ["7", "8", "9", "*"],
            ["4", "5", "6", "-"], ["1", "2", "3", "+"],
            ["0", ".", "=", ""]]
    for i, row in enumerate(btns):
        for j, lbl in enumerate(row):
            if not lbl:
                continue
            bg = BG_PANEL
            if lbl in "=+-*/":
                bg = PURPLE
            elif lbl == "C":
                bg = ERROR
            tk.Button(grid, text=lbl, bg=bg, fg="white", relief="flat",
                      font=("Segoe UI", 14, "bold"),
                      command=lambda l=lbl: press(l)).grid(
                      row=i, column=j, sticky="nsew", padx=2, pady=2, ipady=8)
        grid.rowconfigure(i, weight=1)
    for j in range(4):
        grid.columnconfigure(j, weight=1)
    return win

def app_clock(parent):
    win, body = new_win(parent, "Relogio", ACCENT, 440, 340)
    lbl = tk.Label(body, text="", bg=BG_DARK, fg=ACCENT,
                   font=("Consolas", 48, "bold"))
    lbl.pack(pady=30)
    dl = tk.Label(body, text="", bg=BG_DARK, fg=TEXT, font=("Segoe UI", 11))
    dl.pack()
    def tick():
        try:
            if not win.winfo_exists():
                return
            n = datetime.datetime.now()
            lbl.config(text=n.strftime("%H:%M:%S"))
            dl.config(text=n.strftime("%A, %d de %B de %Y"))
            win.after(1000, tick)
        except:
            pass
    tick()
    return win

def app_calendar(parent):
    import calendar as pycal
    win, body = new_win(parent, "Calendario", SUCCESS, 580, 580)
    today = datetime.datetime.now()
    st = {"y": today.year, "m": today.month}
    title = tk.Label(body, text="", bg=BG_DARK, fg=SUCCESS,
                     font=("Segoe UI", 15, "bold"))
    title.pack(pady=10)
    grid = tk.Frame(body, bg=BG_DARK)
    grid.pack()
    for i, d in enumerate(["Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom"]):
        tk.Label(grid, text=d, bg=BG_DARK, fg=TEXT_MUTED,
                 font=("Segoe UI", 9, "bold"), width=7).grid(row=0, column=i, pady=5)
    day_lbls = []
    for r in range(6):
        row = []
        for c in range(7):
            lb = tk.Label(grid, text="", bg=BG_PANEL, fg=TEXT, width=7, height=2,
                          font=("Segoe UI", 10))
            lb.grid(row=r+1, column=c, padx=2, pady=2)
            row.append(lb)
        day_lbls.append(row)
    def render():
        title.config(text=datetime.date(st["y"], st["m"], 1).strftime("%B %Y"))
        fw, nd = pycal.monthrange(st["y"], st["m"])
        fw = (fw + 6) % 7
        n = 1
        for r in range(6):
            for c in range(7):
                if r == 0 and c < fw:
                    day_lbls[r][c].config(text="", bg=BG_DARK)
                elif n > nd:
                    day_lbls[r][c].config(text="", bg=BG_DARK)
                else:
                    is_t = (st["y"] == today.year and st["m"] == today.month and n == today.day)
                    day_lbls[r][c].config(text=str(n),
                                          bg=ACCENT if is_t else BG_PANEL,
                                          fg=BG_DARK if is_t else TEXT)
                    n += 1
    def prev():
        st["m"] -= 1
        if st["m"] < 1:
            st["m"] = 12
            st["y"] -= 1
        render()
    def nxt():
        st["m"] += 1
        if st["m"] > 12:
            st["m"] = 1
            st["y"] += 1
        render()
    bar = tk.Frame(body, bg=BG_DARK)
    bar.pack(pady=15)
    tk.Button(bar, text="< Anterior", bg=BG_PANEL, fg=TEXT, relief="flat",
              font=("Segoe UI", 10), command=prev).pack(side="left", padx=5, ipady=4)
    tk.Button(bar, text="Hoje", bg=SUCCESS, fg="white", relief="flat",
              font=("Segoe UI", 10, "bold"),
              command=lambda: (st.update({"y": today.year, "m": today.month}), render())).pack(side="left", padx=5, ipady=4)
    tk.Button(bar, text="Proximo >", bg=BG_PANEL, fg=TEXT, relief="flat",
              font=("Segoe UI", 10), command=nxt).pack(side="left", padx=5, ipady=4)
    render()
    return win

def app_terminal(parent):
    win, body = new_win(parent, "Terminal", SUCCESS, 720, 500)
    out = tk.Text(body, bg="#000", fg="#00ff41", insertbackground="#00ff41",
                  font=("Consolas", 10), relief="flat", padx=10, pady=10)
    out.pack(fill="both", expand=True)
    out.insert("end", "minstcaveOS Terminal v" + VERSION + "\nDigite 'help'\n\n")
    out.config(state="disabled")
    inp = tk.Frame(body, bg=BG_DARK)
    inp.pack(fill="x", pady=(5, 0))
    tk.Label(inp, text="$", bg=BG_DARK, fg=SUCCESS,
             font=("Consolas", 10, "bold")).pack(side="left")
    entry = tk.Entry(inp, bg="#000", fg="#00ff41", insertbackground="#00ff41",
                     font=("Consolas", 10), relief="flat")
    entry.pack(side="left", fill="x", expand=True, ipady=4)
    entry.focus_set()
    def echo(t):
        out.config(state="normal")
        out.insert("end", t + "\n")
        out.see("end")
        out.config(state="disabled")
    def go(e=None):
        cmd = entry.get().strip()
        entry.delete(0, "end")
        echo("$ " + cmd)
        if not cmd:
            return
        p = cmd.split()
        op = p[0].lower()
        if op == "help":
            echo("Comandos: help, echo, date, time, ls, df, apps, clear, exit, calc")
        elif op == "echo":
            echo(" ".join(p[1:]))
        elif op == "date":
            echo(datetime.datetime.now().strftime("%d/%m/%Y"))
        elif op == "time":
            echo(datetime.datetime.now().strftime("%H:%M:%S"))
        elif op == "ls":
            for f in sorted(os.listdir(HOME_DIR)):
                echo("  " + f)
        elif op == "df":
            echo("Disco: %.1f/%d MB" % (disk_used_mb(), disk_total_mb()))
        elif op == "apps":
            for k in get_installed():
                echo("  " + k)
        elif op == "calc":
            try:
                expr = " ".join(p[1:])
                if all(c in "0123456789+-*/(). " for c in expr):
                    echo(str(eval(expr)))
                else:
                    echo("Invalido")
            except Exception as ex:
                echo("Erro: " + str(ex))
        elif op == "clear":
            out.config(state="normal")
            out.delete("1.0", "end")
            out.config(state="disabled")
        elif op == "exit":
            win.destroy()
        else:
            echo("Desconhecido: " + op)
    entry.bind("<Return>", go)
    return win

def app_browser(parent):
    win, body = new_win(parent, "MinstBrowser", ERROR, 780, 580)
    bar = tk.Frame(body, bg=BG_DARK)
    bar.pack(fill="x", pady=(0, 8))
    url_var = tk.StringVar(value="minstcave://home")
    e = tk.Entry(bar, textvariable=url_var, bg=BG_PANEL, fg=TEXT,
                 insertbackground="white", relief="flat", font=("Consolas", 11))
    e.pack(side="left", fill="x", expand=True, ipady=6)
    page = tk.Text(body, bg=BG_ROOT, fg=TEXT, font=("Segoe UI", 11),
                   relief="flat", wrap="word", padx=20, pady=20)
    page.pack(fill="both", expand=True)
    def show(url):
        page.config(state="normal")
        page.delete("1.0", "end")
        c = ""
        if url == "minstcave://home":
            c = "MINSTCAVE HOME\n" + "=" * 50 + "\n\nBem-vindo!\n\n"
            c += "Este navegador esta OFFLINE.\n\nPaginas:\n  home, about, help, readme\n"
        elif url == "minstcave://about":
            c = "SOBRE\n" + "=" * 50 + "\n\nminstcaveOS " + VERSION + "\nCodinome: " + CODENAME + "\n"
        elif url == "minstcave://help":
            c = "AJUDA\n" + "=" * 50 + "\n\nInternet real requer Python 3.7+\nUse as paginas locais.\n"
        elif url == "minstcave://readme":
            c = "LEIA-ME\n" + "=" * 50 + "\n\nESTE SISTEMA E PARA ESTUDANTES\n"
        else:
            c = "ERRO 404: " + url
        page.insert("1.0", c)
        page.config(state="disabled")
    def go(e=None):
        show(url_var.get())
    e.bind("<Return>", go)
    tk.Button(bar, text="Ir", bg=ERROR, fg="white", relief="flat",
              font=("Segoe UI", 10, "bold"), command=go).pack(side="left", padx=(5, 0), ipady=3)
    tk.Label(bar, text="OFFLINE", bg=ERROR, fg="white",
             font=("Segoe UI", 9, "bold"), padx=8, pady=3).pack(side="left", padx=5)
    nav = tk.Frame(body, bg=BG_DARK)
    nav.pack(fill="x", pady=(8, 0))
    for lbl, u in [("Home", "minstcave://home"), ("Sobre", "minstcave://about"),
                   ("Ajuda", "minstcave://help"), ("Readme", "minstcave://readme")]:
        def mk(x):
            def cmd():
                url_var.set(x)
                show(x)
            return cmd
        tk.Button(nav, text=lbl, bg=BG_PANEL, fg=TEXT, relief="flat",
                  font=("Segoe UI", 9), command=mk(u)).pack(side="left", padx=2, ipady=3)
    show("minstcave://home")
    return win

def app_creator(parent):
    win, body = new_win(parent, "Criador de Apps", PURPLE, 820, 620)
    top = tk.Frame(body, bg=BG_DARK)
    top.pack(fill="x", pady=5)
    tk.Label(top, text="Nome:", bg=BG_DARK, fg=TEXT, font=("Segoe UI", 9)).pack(side="left")
    ne = tk.Entry(top, bg=BG_PANEL, fg="white", insertbackground="white",
                  font=("Segoe UI", 10), relief="flat", width=25)
    ne.pack(side="left", padx=10, ipady=4)
    ne.insert(0, "meu_app")
    tk.Label(body, text="Codigo:", bg=BG_DARK, fg=TEXT,
             font=("Segoe UI", 9), anchor="w").pack(fill="x")
    ed = tk.Text(body, bg=BG_ROOT, fg=TEXT, insertbackground=ACCENT,
                 font=("Consolas", 10), relief="flat", padx=10, pady=10)
    ed.pack(fill="both", expand=True, pady=(0, 10))
    tpl = (
        "import tkinter as tk\n\n"
        "w = tk.Toplevel()\n"
        "w.title('Meu App')\n"
        "w.geometry('350x250')\n"
        "w.configure(bg='#1b263b')\n\n"
        "tk.Label(w, text='Ola!', bg='#1b263b', fg='#4dd0e1',\n"
        "         font=('Segoe UI', 14, 'bold')).pack(pady=30)\n\n"
        "tk.Button(w, text='Fechar', command=w.destroy,\n"
        "          bg='#ef5350', fg='white').pack(pady=10, ipadx=20, ipady=4)\n"
    )
    ed.insert("1.0", tpl)
    st = tk.Label(body, text="", bg=BG_DARK, fg=SUCCESS,
                  font=("Segoe UI", 9), anchor="w")
    st.pack(fill="x", pady=(0, 5))
    bar = tk.Frame(body, bg=BG_DARK)
    bar.pack(fill="x")
    def save():
        n = ne.get().strip()
        if not n:
            st.config(text="Nome vazio")
            return
        try:
            f = open(os.path.join(HOME_DIR, n + ".py"), "w")
            f.write(ed.get("1.0", "end-1c"))
            f.close()
            st.config(text="Salvo!")
        except Exception as ex:
            st.config(text="Erro: " + str(ex))
    def run():
        n = ne.get().strip()
        try:
            exec(compile(ed.get("1.0", "end-1c"), n, "exec"), {})
            st.config(text="Executado!")
        except Exception as ex:
            st.config(text="Erro: " + str(ex))
    tk.Button(bar, text="Salvar", bg=BG_PANEL, fg=TEXT, relief="flat",
              font=("Segoe UI", 9, "bold"),
              command=save).pack(side="right", padx=2, ipady=4)
    tk.Button(bar, text="Salvar + Rodar", bg=ACCENT, fg=BG_DARK, relief="flat",
              font=("Segoe UI", 9, "bold"),
              command=lambda: (save(), run())).pack(side="right", padx=2, ipady=4)
    return win

def app_about(parent):
    win, body = new_win(parent, "Sobre", ACCENT, 520, 440)
    tk.Label(body, text="minstcaveOS", bg=BG_DARK, fg=ACCENT,
             font=("Segoe UI", 26, "bold")).pack(pady=(20, 5))
    tk.Label(body, text="Versao " + VERSION + " - " + CODENAME, bg=BG_DARK, fg=TEXT,
             font=("Segoe UI", 12)).pack()
    tk.Label(body, text="").pack()
    for lbl, val in [("Kernel", "Python " + sys.version.split()[0]),
                     ("Plataforma", sys.platform),
                     ("Usuario", MAIN.user if MAIN else "?"),
                     ("Disco", "%.0f/%d MB" % (disk_used_mb(), disk_total_mb()))]:
        r = tk.Frame(body, bg=BG_DARK)
        r.pack(fill="x", padx=40, pady=4)
        tk.Label(r, text=lbl + ":", bg=BG_DARK, fg=TEXT_MUTED,
                 font=("Segoe UI", 9), width=12, anchor="w").pack(side="left")
        tk.Label(r, text=val, bg=BG_DARK, fg=TEXT,
                 font=("Consolas", 9), anchor="w").pack(side="left")
    tk.Label(body, text="ESTE SISTEMA E PARA ESTUDANTES", bg=BG_DARK, fg=WARNING,
             font=("Segoe UI", 11, "bold")).pack(pady=20)
    return win

def app_paint(parent):
    win, body = new_win(parent, "Paint", PINK, 720, 520)
    ch = {"c": ACCENT}
    cv = tk.Canvas(body, bg="white", highlightthickness=0)
    cv.pack(fill="both", expand=True)
    def paint(e):
        try:
            cv.create_oval(e.x - 2, e.y - 2, e.x + 2, e.y + 2,
                           fill=ch["c"], outline="")
        except:
            pass
    cv.bind("<B1-Motion>", paint)
    bar = tk.Frame(body, bg=BG_DARK)
    bar.pack(fill="x", pady=(5, 0))
    for c in [ACCENT, SUCCESS, WARNING, ERROR, PURPLE, PINK, INFO, "white", "black"]:
        def mk(col):
            def cmd():
                ch["c"] = col
            return cmd
        tk.Button(bar, bg=c, width=3, relief="flat",
                  command=mk(c)).pack(side="left", padx=2, pady=2)
    tk.Button(bar, text="Limpar", bg=ERROR, fg="white", relief="flat",
              font=("Segoe UI", 9),
              command=lambda: cv.delete("all")).pack(side="right", padx=5)
    return win

def app_snake(parent):
    win, body = new_win(parent, "Snake", SUCCESS, 480, 540)
    cv = tk.Canvas(body, bg=BG_ROOT, highlightthickness=0, width=440, height=440)
    cv.pack()
    st = {"s": [(10, 10)], "d": (1, 0), "f": (5, 5), "sc": 0, "alive": True}
    cell = 22
    def draw():
        cv.delete("all")
        for x, y in st["s"]:
            cv.create_rectangle(x*cell, y*cell, (x+1)*cell, (y+1)*cell,
                                fill=SUCCESS, outline="")
        fx, fy = st["f"]
        cv.create_rectangle(fx*cell, fy*cell, (fx+1)*cell, (fy+1)*cell,
                            fill=ERROR, outline="")
        cv.create_text(10, 10, anchor="nw", text="Score: %d" % st["sc"],
                       fill="white", font=("Consolas", 10))
    def step():
        try:
            if not win.winfo_exists() or not st["alive"]:
                return
            hx, hy = st["s"][0]
            dx, dy = st["d"]
            nx, ny = hx+dx, hy+dy
            if nx<0 or nx>=20 or ny<0 or ny>=20 or (nx,ny) in st["s"]:
                st["alive"] = False
                cv.create_text(220, 220, text="GAME OVER\n%d" % st["sc"],
                               fill=ERROR, font=("Segoe UI", 18, "bold"),
                               justify="center")
                return
            st["s"].insert(0, (nx, ny))
            if (nx, ny) == st["f"]:
                st["sc"] += 1
                while True:
                    nf = (random.randint(0,19), random.randint(0,19))
                    if nf not in st["s"]:
                        break
                st["f"] = nf
            else:
                st["s"].pop()
            draw()
            win.after(120, step)
        except:
            pass
    def key(e):
        k = e.keysym
        d = st["d"]
        if k == "Up" and d != (0,1):
            st["d"] = (0,-1)
        elif k == "Down" and d != (0,-1):
            st["d"] = (0,1)
        elif k == "Left" and d != (1,0):
            st["d"] = (-1,0)
        elif k == "Right" and d != (-1,0):
            st["d"] = (1,0)
    win.bind("<Key>", key)
    win.focus_set()
    step()
    return win

def app_tictactoe(parent):
    win, body = new_win(parent, "Jogo da Velha", WARNING, 420, 520)
    b = [""]*9
    p = ["X"]
    btns = []
    st = tk.Label(body, text="Vez de X", bg=BG_DARK, fg=TEXT,
                  font=("Segoe UI", 12, "bold"))
    st.pack(pady=10)
    g = tk.Frame(body, bg=BG_DARK)
    g.pack()
    def chk():
        wins = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
        for a,b_,c in wins:
            if b[a] and b[a]==b[b_]==b[c]:
                return b[a]
        if "" not in b:
            return "Empate"
        return None
    def click(i):
        if b[i] or chk():
            return
        b[i] = p[0]
        btns[i].config(text=p[0], fg=ACCENT if p[0]=="X" else WARNING)
        w = chk()
        if w:
            st.config(text=("Empate!" if w=="Empate" else "Vencedor: " + w))
            return
        p[0] = "O" if p[0]=="X" else "X"
        st.config(text="Vez de " + p[0])
    for i in range(9):
        btn = tk.Button(g, text="", bg=BG_PANEL, fg=TEXT,
                        font=("Segoe UI", 22, "bold"), width=4, height=2,
                        relief="flat", command=lambda i=i: click(i))
        btn.grid(row=i//3, column=i%3, padx=2, pady=2)
        btns.append(btn)
    def reset():
        for i in range(9):
            b[i] = ""
            btns[i].config(text="")
        p[0] = "X"
        st.config(text="Vez de X")
    tk.Button(body, text="Reiniciar", bg=WARNING, fg=BG_DARK, relief="flat",
              font=("Segoe UI", 10, "bold"),
              command=reset).pack(pady=10, ipadx=20, ipady=3)
    return win

def app_memory(parent):
    win, body = new_win(parent, "Memoria", PURPLE, 480, 560)
    sym = ["A","B","C","D","E","F","G","H"] * 2
    random.shuffle(sym)
    state = {"rev": [], "mat": set(), "btns": []}
    st = tk.Label(body, text="Encontre os pares", bg=BG_DARK, fg=TEXT,
                  font=("Segoe UI", 10))
    st.pack(pady=10)
    g = tk.Frame(body, bg=BG_DARK)
    g.pack()
    def unres():
        try:
            if not win.winfo_exists():
                return
            for i in state["rev"]:
                state["btns"][i].config(text="?", bg=BG_PANEL)
            state["rev"] = []
        except:
            pass
    def flip(i):
        if i in state["mat"] or i in state["rev"]:
            return
        state["rev"].append(i)
        state["btns"][i].config(text=sym[i], bg=PURPLE)
        if len(state["rev"]) == 2:
            a, b = state["rev"][0], state["rev"][1]
            if sym[a] == sym[b]:
                state["mat"].add(a)
                state["mat"].add(b)
                state["rev"] = []
                st.config(text="Par! %d/8" % (len(state["mat"])//2))
                if len(state["mat"]) == 16:
                    st.config(text="Vitoria!")
            else:
                win.after(600, unres)
    for i in range(16):
        btn = tk.Button(g, text="?", bg=BG_PANEL, fg="white",
                        font=("Segoe UI", 16, "bold"), width=4, height=2,
                        relief="flat", command=lambda i=i: flip(i))
        btn.grid(row=i//4, column=i%4, padx=2, pady=2)
        state["btns"].append(btn)
    return win

def app_todo(parent):
    win, body = new_win(parent, "Tarefas", WARNING, 520, 540)
    fp = os.path.join(HOME_DIR, "todo.txt")
    tasks = []
    if os.path.exists(fp):
        try:
            f = open(fp, "r")
            for l in f.readlines():
                s = l.strip()
                if s:
                    tasks.append(s)
            f.close()
        except:
            pass
    lb = tk.Listbox(body, bg=BG_ROOT, fg=TEXT, font=("Segoe UI", 11),
                    selectbackground=WARNING, selectforeground=BG_DARK,
                    relief="flat")
    lb.pack(fill="both", expand=True, pady=5)
    for t in tasks:
        lb.insert("end", "  " + t)
    def save():
        try:
            f = open(fp, "w")
            for t in tasks:
                f.write(t + "\n")
            f.close()
        except:
            pass
    def add():
        t = simpledialog.askstring("Nova", "Descricao:")
        if t:
            tasks.append(t)
            lb.insert("end", "  " + t)
            save()
    def rem():
        sel = lb.curselection()
        if sel and sel[0] < len(tasks):
            tasks.pop(sel[0])
            lb.delete(sel[0])
            save()
    bar = tk.Frame(body, bg=BG_DARK)
    bar.pack(fill="x")
    tk.Button(bar, text="+ Adicionar", bg=WARNING, fg=BG_DARK, relief="flat",
              font=("Segoe UI", 10, "bold"),
              command=add).pack(side="left", padx=2, ipady=3)
    tk.Button(bar, text="- Remover", bg=ERROR, fg="white", relief="flat",
              font=("Segoe UI", 10, "bold"),
              command=rem).pack(side="left", padx=2, ipady=3)
    return win

def app_notes(parent):
    win, body = new_win(parent, "Notas Rapidas", WARNING, 620, 500)
    text = tk.Text(body, bg=BG_ROOT, fg=TEXT, insertbackground=WARNING,
                   font=("Consolas", 10), relief="flat", wrap="word",
                   padx=10, pady=10)
    text.pack(fill="both", expand=True, pady=5)
    p = os.path.join(HOME_DIR, "notes.txt")
    if os.path.exists(p):
        try:
            f = open(p, "r")
            text.insert("1.0", f.read())
            f.close()
        except:
            pass
    st = tk.Label(body, text="", bg=BG_DARK, fg=SUCCESS, font=("Segoe UI", 9))
    st.pack()
    def save():
        try:
            f = open(p, "w")
            f.write(text.get("1.0", "end-1c"))
            f.close()
            st.config(text="Salvo!")
        except Exception as e:
            st.config(text="Erro: " + str(e))
    tk.Button(body, text="Salvar", bg=WARNING, fg=BG_DARK, relief="flat",
              font=("Segoe UI", 10, "bold"),
              command=save).pack(pady=5, ipadx=20, ipady=3)
    return win

def app_quotes(parent):
    win, body = new_win(parent, "Citacoes", WARNING, 560, 400)
    lbl = tk.Label(body, text="", bg=BG_DARK, fg=WARNING,
                   font=("Segoe UI", 14, "italic"), wraplength=500, pady=40)
    lbl.pack(fill="both", expand=True, padx=20)
    def show():
        lbl.config(text='"' + random.choice(QUOTES) + '"')
    show()
    tk.Button(body, text="Nova citacao", bg=WARNING, fg=BG_DARK, relief="flat",
              font=("Segoe UI", 11, "bold"),
              command=show).pack(pady=10, ipadx=20, ipady=4)
    return win

# ============================================================
# REGISTRO: (key, fn, size_mb, color, icon, desc, preinstalled, category)
# ============================================================
def register_all():
    APPS.append(("Configuracoes", app_config, 15, ACCENT, "G", "Configuracoes do sistema", True, "Sistema"))
    APPS.append(("LEIA-ME", app_readme, 2, ACCENT, "R", "Informacoes para estudantes", False, "Sistema"))
    APPS.append(("Arquivos", app_files, 8, ACCENT, "F", "Gerenciador com drag and drop", False, "Sistema"))
    APPS.append(("CaveStore", app_store, 12, SUCCESS, "S", "Loja de apps", False, "Sistema"))
    APPS.append(("Terminal", app_terminal, 3, SUCCESS, ">", "Terminal de comandos", False, "Sistema"))
    APPS.append(("Criador", app_creator, 4, PURPLE, "*", "Criar seus apps", False, "Sistema"))
    APPS.append(("Sobre", app_about, 1, ACCENT, "I", "Sobre o sistema", False, "Sistema"))
    APPS.append(("Notepad", app_notepad, 5, WARNING, "N", "Bloco de notas", False, "Produtividade"))
    APPS.append(("Notas", app_notes, 3, WARNING, "N", "Notas rapidas", False, "Produtividade"))
    APPS.append(("Tarefas", app_todo, 3, WARNING, "L", "Lista de tarefas", False, "Produtividade"))
    APPS.append(("Calculadora", app_calc, 3, PURPLE, "=", "Calculadora", False, "Utilidades"))
    APPS.append(("Relogio", app_clock, 2, ACCENT, "H", "Relogio digital", False, "Utilidades"))
    APPS.append(("Calendario", app_calendar, 4, SUCCESS, "C", "Calendario interativo", False, "Utilidades"))
    APPS.append(("Citacoes", app_quotes, 2, WARNING, '"', "Frases inspiradoras", False, "Utilidades"))
    APPS.append(("Browser", app_browser, 6, ERROR, "B", "Navegador offline", False, "Internet"))
    APPS.append(("Paint", app_paint, 5, PINK, "P", "Desenhar", False, "Grafico"))
    APPS.append(("Snake", app_snake, 3, SUCCESS, "S", "Jogo da cobrinha", False, "Jogos"))
    APPS.append(("JogoVelha", app_tictactoe, 2, WARNING, "X", "Jogo da velha", False, "Jogos"))
    APPS.append(("jogodaMemoria", app_memory, 3, PURPLE, "jdm", "Jogo da memoria", False, "Jogos"))

# ============================================================
# MAIN CLASS
# ============================================================
class MinstcaveOS(object):
    def __init__(self):
        global MAIN
        ensure_dirs()
        self.user = None
        self.running = []  # (key, toplevel)
        self._icons_area = None
        self._widgets_area = None
        self._clock_lbl = None
        self._tick_id = 0

        self.root = tk.Tk()
        self.root.title("minstcaveOS " + VERSION)
        self.root.configure(bg=BG_DARK)
        self.root.geometry("1150x740+40+20")
        self.root.minsize(900, 600)

        self.root.bind("<F5>", lambda e: self.show_desktop())
        self.root.bind("<Control-s>", lambda e: self.open_store())

        MAIN = self
        register_all()
        self.show_login()

    def clear_root(self):
        self._tick_id += 1
        for w in self.root.winfo_children():
            try:
                w.destroy()
            except:
                pass

    def show_login(self):
        self.clear_root()
        users = load_json(USERS_FILE, {})

        # Fundo
        bg = tk.Frame(self.root, bg=BG_ROOT)
        bg.pack(fill="both", expand=True)

        card = tk.Frame(bg, bg=BG_MID, padx=50, pady=40)
        card.place(relx=0.5, rely=0.5, anchor="center")

        # Avatar circle
        av = tk.Canvas(card, width=100, height=100, bg=BG_MID, highlightthickness=0)
        av.pack(pady=(0, 15))
        av.create_oval(4, 4, 96, 96, fill=ACCENT, outline="")
        av.create_text(50, 50, text="M", fill=BG_MID,
                       font=("Segoe UI", 40, "bold"))

        tk.Label(card, text="minstcaveOS", bg=BG_MID, fg=TEXT,
                 font=("Segoe UI", 24, "bold")).pack()
        tk.Label(card, text="Versao " + VERSION + " - " + CODENAME,
                 bg=BG_MID, fg=TEXT_DIM, font=("Segoe UI", 9)).pack(pady=(0, 3))
        tk.Label(card, text="ESTE SISTEMA E PARA ESTUDANTES",
                 bg=BG_MID, fg=WARNING, font=("Segoe UI", 9, "bold italic")).pack(pady=(0, 20))

        if not users:
            tk.Label(card, text="Criar conta", bg=BG_MID, fg=ACCENT,
                     font=("Segoe UI", 11, "bold")).pack(pady=(0, 12))
            tk.Label(card, text="Usuario:", bg=BG_MID, fg=TEXT_DIM,
                     font=("Segoe UI", 9), anchor="w").pack(fill="x")
            eu = tk.Entry(card, bg=BG_PANEL, fg="white", insertbackground="white",
                          relief="flat", font=("Segoe UI", 11))
            eu.pack(fill="x", pady=(3, 10), ipady=6)
            tk.Label(card, text="Senha:", bg=BG_MID, fg=TEXT_DIM,
                     font=("Segoe UI", 9), anchor="w").pack(fill="x")
            ep = tk.Entry(card, bg=BG_PANEL, fg="white", insertbackground="white",
                          show="*", relief="flat", font=("Segoe UI", 11))
            ep.pack(fill="x", pady=(3, 18), ipady=6)

            def setup():
                u = eu.get().strip()
                p = pw = ep.get()
                if not u or not p:
                    messagebox.showerror("Erro", "Preencha tudo")
                    return
                save_json(USERS_FILE, {u: hash_pw(p)})
                self.user = u
                self.show_desktop()

            tk.Button(card, text="Criar conta", bg=ACCENT, fg=BG_DARK,
                      relief="flat", font=("Segoe UI", 11, "bold"),
                      command=setup).pack(fill="x", ipady=8)
        else:
            tk.Label(card, text="Login", bg=BG_MID, fg=TEXT_DIM,
                     font=("Segoe UI", 10)).pack(pady=(0, 15))
            tk.Label(card, text="Usuario:", bg=BG_MID, fg=TEXT_DIM,
                     font=("Segoe UI", 9), anchor="w").pack(fill="x")
            eu = tk.Entry(card, bg=BG_PANEL, fg="white", insertbackground="white",
                          relief="flat", font=("Segoe UI", 11), width=25)
            eu.pack(fill="x", pady=(3, 10), ipady=6)
            eu.insert(0, list(users.keys())[0])
            tk.Label(card, text="Senha:", bg=BG_MID, fg=TEXT_DIM,
                     font=("Segoe UI", 9), anchor="w").pack(fill="x")
            ep = tk.Entry(card, bg=BG_PANEL, fg="white", insertbackground="white",
                          show="*", relief="flat", font=("Segoe UI", 11), width=25)
            ep.pack(fill="x", pady=(3, 8), ipady=6)
            err = tk.Label(card, text="", bg=BG_MID, fg=ERROR, font=("Segoe UI", 8))
            err.pack()

            def login(e=None):
                u = eu.get().strip()
                p = ep.get()
                if u in users and users[u] == hash_pw(p):
                    self.user = u
                    self.show_desktop()
                else:
                    err.config(text="Usuario ou senha incorretos")
                    ep.delete(0, "end")

            ep.bind("<Return>", login)
            tk.Button(card, text="Entrar", bg=ACCENT, fg=BG_DARK, relief="flat",
                      font=("Segoe UI", 11, "bold"),
                      command=login).pack(fill="x", pady=(10, 0), ipady=8)
            ep.focus_set()

        tk.Label(bg, text="(c) 2024-2026 minstcave Foundation",
                 bg=BG_ROOT, fg=TEXT_MUTED, font=("Segoe UI", 8)).pack(side="bottom", pady=20)

    def show_desktop(self):
        self.clear_root()
        my_id = self._tick_id

        cfg = load_json(CONFIG_FILE, {"wallpaper_idx": 0})
        wi = cfg.get("wallpaper_idx", 0)
        if wi < 0 or wi >= len(WALLPAPERS):
            wi = 0
        wp = WALLPAPERS[wi]

        # TOPBAR
        top = tk.Frame(self.root, bg=BG_MID, height=34)
        top.pack(fill="x")
        top.pack_propagate(False)
        tk.Label(top, text=" minstcaveOS ", bg=ACCENT, fg=BG_DARK,
                 font=("Segoe UI", 10, "bold")).pack(side="left", padx=(10, 5), pady=6)
        tk.Label(top, text="v" + VERSION, bg=BG_MID, fg=TEXT_DIM,
                 font=("Segoe UI", 8)).pack(side="left")

        tk.Label(top, text="OFFLINE", bg=ERROR, fg="white",
                 font=("Segoe UI", 8, "bold"), padx=8, pady=2).pack(side="left", padx=12)

        tk.Label(top, text="ESTE SISTEMA E PARA ESTUDANTES",
                 bg=BG_MID, fg=WARNING, font=("Segoe UI", 9, "bold italic")).pack(side="left", padx=10)

        self._clock_lbl = tk.Label(top, text="", bg=BG_MID, fg=TEXT,
                                     font=("Segoe UI", 9, "bold"))
        self._clock_lbl.pack(side="right", padx=15)

        tk.Label(top, text="Ola, " + self.user, bg=BG_MID, fg=TEXT,
                 font=("Segoe UI", 9)).pack(side="right", padx=10)

        # TASKBAR
        tb = tk.Frame(self.root, bg=BG_MID, height=58)
        tb.pack(fill="x", side="bottom")
        tb.pack_propagate(False)

        tk.Button(tb, text="Iniciar", bg=ACCENT, fg=BG_DARK,
                  font=("Segoe UI", 11, "bold"), relief="flat",
                  command=self.start_menu).pack(side="left", padx=8, pady=10, ipadx=15)

        # Botoes fixos
        for label, color, cmd in [
            ("LOJA", SUCCESS, self.open_store),
            ("Arquivos", ACCENT, lambda: self.launch("Arquivos")),
            ("Config", BG_LIGHT, lambda: self.launch("Configuracoes")),
        ]:
            fg = "white" if color in (SUCCESS, ACCENT) else TEXT
            tk.Button(tb, text=label, bg=color, fg=BG_DARK if color in (SUCCESS, ACCENT) else TEXT,
                      font=("Segoe UI", 10, "bold"), relief="flat",
                      command=cmd).pack(side="left", padx=4, pady=12, ipadx=10)

        # Running apps
        self._running_frame = tk.Frame(tb, bg=BG_MID)
        self._running_frame.pack(side="left", fill="both", expand=True, padx=10)

        # Systray
        tray = tk.Frame(tb, bg=BG_MID)
        tray.pack(side="right", padx=10)
        tk.Label(tray, text="%.0f MB" % disk_used_mb(), bg=BG_MID, fg=TEXT_MUTED,
                 font=("Segoe UI", 8)).pack()
        tk.Label(tray, text="Disco", bg=BG_MID, fg=TEXT_MUTED,
                 font=("Segoe UI", 7)).pack()

        # CENTER
        center = tk.Frame(self.root, bg=wp[1])
        center.pack(fill="both", expand=True)

        # Banner
        banner = tk.Frame(center, bg=ACCENT, height=40)
        banner.pack(fill="x", padx=30, pady=(15, 5))
        banner.pack_propagate(False)
        tk.Label(banner, text="ESTE SISTEMA OPERACIONAL E PARA ESTUDANTES",
                 bg=ACCENT, fg=BG_DARK, font=("Segoe UI", 12, "bold")).pack(expand=True)

        # Icons + widgets
        split = tk.Frame(center, bg=wp[1])
        split.pack(fill="both", expand=True, pady=15, padx=20)

        self._icons_area = tk.Frame(split, bg=wp[1])
        self._icons_area.pack(side="left", fill="both", expand=True)

        self._widgets_area = tk.Frame(split, bg=BG_PANEL, width=240)
        self._widgets_area.pack(side="right", fill="y", padx=(15, 0))
        self._widgets_area.pack_propagate(False)

        tk.Label(self._widgets_area, text="WIDGETS", bg=BG_PANEL, fg=TEXT_MUTED,
                 font=("Segoe UI", 9, "bold"), pady=8).pack(fill="x")

        self._render_widgets()
        self._render_icons()
        self._refresh_running()
        self._tick_clock(my_id)

        # Welcome toast
        try:
            self.root.after(500, lambda: self.toast("Bem-vindo", "Ola, " + self.user + "!", "info"))
        except:
            pass

    def toast(self, title, message, kind="info"):
        try:
            Toast(self.root, title, message, kind)
        except:
            pass

    def _tick_clock(self, my_id):
        try:
            if self._tick_id != my_id or not self._clock_lbl or not self._clock_lbl.winfo_exists():
                return
            self._clock_lbl.config(text=datetime.datetime.now().strftime("%d/%m/%Y  %H:%M"))
            self.root.after(1000, lambda: self._tick_clock(my_id))
        except:
            pass

    def _render_icons(self):
        if not self._icons_area or not self._icons_area.winfo_exists():
            return
        for w in self._icons_area.winfo_children():
            w.destroy()

        cfg = load_json(CONFIG_FILE, {"wallpaper_idx": 0})
        wi = cfg.get("wallpaper_idx", 0)
        if wi < 0 or wi >= len(WALLPAPERS):
            wi = 0
        wp_bg = WALLPAPERS[wi][1]

        installed = get_installed()
        entries = [e for e in APPS if e[0] in installed]

        if not entries:
            tk.Label(self._icons_area,
                     text="Nenhum app instalado.\n\nClique em LOJA para comecar.",
                     bg=wp_bg, fg=TEXT_MUTED, font=("Segoe UI", 12),
                     justify="center").pack(pady=60)
            return

        cols = 7
        for idx, entry in enumerate(entries):
            key = entry[0]
            color = entry[3]
            icon = entry[4]

            col = idx % cols
            row = idx // cols

            box = tk.Frame(self._icons_area, bg=wp_bg)
            box.grid(row=row, column=col, padx=8, pady=8)

            btn = tk.Button(box, text=icon, bg=color, fg="white",
                            font=("Segoe UI", 18, "bold"), width=4, height=2,
                            relief="flat", cursor="hand2",
                            command=lambda k=key: self.launch(k))
            btn.pack()
            tk.Label(box, text=key[:11], bg=wp_bg, fg=TEXT,
                     font=("Segoe UI", 8)).pack(pady=3)

    def refresh_icons(self):
        self._render_icons()
        self._refresh_running()

    def _render_widgets(self):
        if not self._widgets_area or not self._widgets_area.winfo_exists():
            return
        for w in self._widgets_area.winfo_children():
            w.destroy()

        tk.Label(self._widgets_area, text="WIDGETS", bg=BG_PANEL, fg=TEXT_MUTED,
                 font=("Segoe UI", 9, "bold"), pady=8).pack(fill="x")

        # Clock widget
        w1 = tk.Frame(self._widgets_area, bg=BG_MID)
        w1.pack(fill="x", padx=8, pady=6)
        tk.Label(w1, text="HORA", bg=BG_MID, fg=TEXT_MUTED,
                 font=("Segoe UI", 7, "bold")).pack(anchor="w", padx=8, pady=(6, 0))
        cl = tk.Label(w1, text="", bg=BG_MID, fg=ACCENT,
                      font=("Consolas", 18, "bold"))
        cl.pack(anchor="w", padx=8, pady=(0, 6))

        def tick_widget():
            try:
                if not cl.winfo_exists():
                    return
                cl.config(text=datetime.datetime.now().strftime("%H:%M"))
                cl.after(30000, tick_widget)
            except:
                pass
        tick_widget()

        # Date widget
        w2 = tk.Frame(self._widgets_area, bg=BG_MID)
        w2.pack(fill="x", padx=8, pady=6)
        tk.Label(w2, text="DATA", bg=BG_MID, fg=TEXT_MUTED,
                 font=("Segoe UI", 7, "bold")).pack(anchor="w", padx=8, pady=(6, 0))
        now = datetime.datetime.now()
        tk.Label(w2, text=now.strftime("%d/%m/%Y"), bg=BG_MID, fg=TEXT,
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=8)
        tk.Label(w2, text=now.strftime("%A"), bg=BG_MID, fg=TEXT_DIM,
                 font=("Segoe UI", 8)).pack(anchor="w", padx=8, pady=(0, 6))

        # Stats widget
        w3 = tk.Frame(self._widgets_area, bg=BG_MID)
        w3.pack(fill="x", padx=8, pady=6)
        tk.Label(w3, text="SISTEMA", bg=BG_MID, fg=TEXT_MUTED,
                 font=("Segoe UI", 7, "bold")).pack(anchor="w", padx=8, pady=(6, 2))
        tk.Label(w3, text="Disco: %.0f MB" % disk_used_mb(), bg=BG_MID, fg=TEXT,
                 font=("Segoe UI", 9)).pack(anchor="w", padx=8)
        tk.Label(w3, text="Apps: %d" % len(get_installed()), bg=BG_MID, fg=TEXT,
                 font=("Segoe UI", 9)).pack(anchor="w", padx=8, pady=(0, 6))

        # Quote widget
        w4 = tk.Frame(self._widgets_area, bg=BG_MID)
        w4.pack(fill="x", padx=8, pady=6)
        tk.Label(w4, text="CITACAO", bg=BG_MID, fg=TEXT_MUTED,
                 font=("Segoe UI", 7, "bold")).pack(anchor="w", padx=8, pady=(6, 2))
        tk.Label(w4, text=random.choice(QUOTES), bg=BG_MID, fg=WARNING,
                 font=("Segoe UI", 8, "italic"), wraplength=200,
                 justify="left").pack(anchor="w", padx=8, pady=(0, 6))

    def _refresh_running(self):
        if not hasattr(self, "_running_frame") or not self._running_frame.winfo_exists():
            return
        for w in self._running_frame.winfo_children():
            w.destroy()

        alive = []
        for item in self.running:
            key, t = item
            try:
                if t.winfo_exists():
                    alive.append((key, t))
                    entry = get_app_entry(key)
                    color = entry[3] if entry else ACCENT
                    icon = entry[4] if entry else "?"
                    tk.Button(self._running_frame, text=icon + " " + key[:8],
                              bg=BG_PANEL, fg=TEXT, relief="flat",
                              font=("Segoe UI", 8), padx=6,
                              command=lambda t=t: (t.lift(), t.focus_force())).pack(side="left", padx=2, pady=14)
            except:
                pass
        self.running = alive

    def start_menu(self):
        m = tk.Menu(self.root, tearoff=0, bg=BG_PANEL, fg=TEXT,
                    activebackground=ACCENT, activeforeground=BG_DARK,
                    font=("Segoe UI", 9))
        m.add_command(label="  Loja de Apps", command=self.open_store)
        m.add_command(label="  Configuracoes", command=lambda: self.launch("Configuracoes"))
        m.add_separator()
        for entry in APPS:
            if is_installed(entry[0]):
                m.add_command(label="  " + entry[0],
                              command=lambda k=entry[0]: self.launch(k))
        m.add_separator()
        m.add_command(label="  Reiniciar", command=self.restart)
        m.add_command(label="  Desligar", command=self.shutdown)
        try:
            m.tk_popup(self.root.winfo_pointerx(), self.root.winfo_pointery())
        except:
            pass

    def launch(self, key):
        entry = get_app_entry(key)
        if not entry:
            self.toast("Erro", "App desconhecido: " + key, "error")
            return
        if not is_installed(key):
            if messagebox.askyesno("Nao instalado",
                    key + " nao esta instalado.\nInstalar agora?"):
                install_app(key)
                self.refresh_icons()
                self._render_widgets()
            else:
                return
        try:
            w = entry[1](self.root)
            if w is not None:
                self.running.append((key, w))
                self.root.after(300, self._refresh_running)
        except Exception as ex:
            self.toast("Erro", "Falha em " + key, "error")
            messagebox.showerror("Erro", str(ex))

    def open_store(self):
        try:
            app_store(self.root)
        except Exception as e:
            self.toast("Erro", "Nao foi possivel abrir a loja", "error")

    def restart(self):
        if messagebox.askyesno("Reiniciar", "Reiniciar o sistema?"):
            self.show_login()

    def shutdown(self):
        if messagebox.askyesno("Desligar", "Desligar o sistema?"):
            try:
                self.root.destroy()
            except:
                pass

# ============================================================
# ENTRY
# ============================================================
if __name__ == "__main__":
    log_path = os.path.join(BASE, "erro.log")
    try:
        boot()
        app = MinstcaveOS()
        app.root.mainloop()
    except Exception as e:
        msg = "ERRO FATAL\n\n"
        msg += "Tipo: " + str(type(e).__name__) + "\n"
        msg += "Mensagem: " + str(e) + "\n\n"
        msg += "Rastreamento:\n" + traceback.format_exc()
        try:
            f = open(log_path, "w")
            f.write(msg)
            f.close()
        except:
            pass
        print("=" * 60)
        print(msg)
        print("=" * 60)
        print("")
        print("Salvo em: " + log_path)
        try:
            input("Pressione ENTER para sair...")
        except:
            pass
